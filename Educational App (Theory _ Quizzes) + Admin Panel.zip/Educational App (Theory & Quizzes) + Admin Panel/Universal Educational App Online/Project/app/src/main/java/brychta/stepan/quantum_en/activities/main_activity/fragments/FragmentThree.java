package brychta.stepan.quantum_en.activities.main_activity.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;

public class FragmentThree extends Fragment {

    public FragmentThree() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        int contributed = Globals.sharedPreferences.getInt("contributed",0);
        View v;
        if (contributed == 0) {
            v = inflater.inflate(R.layout.fragment_third, container, false);
        }
        else {
            v = inflater.inflate(R.layout.fragment_third_secret, container, false);
            ImageView tick = v.findViewById(R.id.tick);

            if(contributed == 1) tick.setImageResource(R.drawable.bronzetick);
            else if(contributed == 2) tick.setImageResource(R.drawable.silvertick);
            else if(contributed == 3) tick.setImageResource(R.drawable.goldtick);
        }
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        setFont();
    }

    private void setFont() {
       CustomText donate = getActivity().findViewById(R.id.maintext);
       CustomText donateheader = getActivity().findViewById(R.id.header);
       if(Globals.colorTheme == 1) donateheader.setTextColor(getResources().getColor(R.color.dark));
       else donateheader.setTextColor(getResources().getColor(R.color.white));
       Globals.changeTypefaceOfText(donate);
    }

}



