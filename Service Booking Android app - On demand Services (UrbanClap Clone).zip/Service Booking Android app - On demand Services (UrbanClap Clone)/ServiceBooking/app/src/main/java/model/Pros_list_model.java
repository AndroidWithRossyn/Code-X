package model;

/**
 * Created by Rajesh on 2017-09-28.
 */

public class Pros_list_model {

    private String id;
    private String pros_name;
    private String pros_email;
    private String pros_degree;
    private String pros_exp;
    private String pros_photo;
    private String pros_id_proof;
    private String is_qualified;
    private String working_hour_start;
    private String working_hour_end;
    private String pros_cats;


    public String getId() {
        return id;
    }

    public String getPros_name() {
        return pros_name;
    }

    public String getPros_email() {
        return pros_email;
    }

    public String getPros_degree() {
        return pros_degree;
    }

    public String getPros_exp() {
        return pros_exp;
    }

    public String getPros_photo() {
        return pros_photo;
    }

    public String getPros_id_proof() {
        return pros_id_proof;
    }

    public String getIs_qualified() {
        return is_qualified;
    }

    public String getWorking_hour_start() {
        return working_hour_start;
    }

    public String getWorking_hour_end() {
        return working_hour_end;
    }

    public String getPros_cats() {
        return pros_cats;
    }

}
