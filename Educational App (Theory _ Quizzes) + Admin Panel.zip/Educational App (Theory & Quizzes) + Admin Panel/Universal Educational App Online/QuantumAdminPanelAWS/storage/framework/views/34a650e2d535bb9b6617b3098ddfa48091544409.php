<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>SULU</title>
        <link rel="stylesheet" href="/style.css" />
        <script src="/js/jquery.js"></script>

        <script src="/js/jquery.nice-select.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-sortablejs@latest/jquery-sortable.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/js-beautify/1.11.0/beautify-html.min.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Lexend+Deca&display=swap" rel="stylesheet">

        <script src="/js/main.js"></script>

        <link rel="stylesheet" href="/nice-select.css">

        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body>
        <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\_\quantum-admin\resources\views/layouts/base.blade.php ENDPATH**/ ?>