package brychta.stepan.quantum_en.activities.chapters;

import android.animation.Animator;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewAnimationUtils;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import com.github.ksoichiro.android.observablescrollview.ObservableScrollView;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollViewCallbacks;
import com.github.ksoichiro.android.observablescrollview.ScrollState;
import com.github.ksoichiro.android.observablescrollview.ScrollUtils;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.util.DrawableManager;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ImageManager;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.BaseActivity;
import brychta.stepan.quantum_en.activities.main_activity.MainActivity;

public class About extends BaseActivity implements ObservableScrollViewCallbacks {
    private RelativeLayout introView;
    private int introImageHeight;
    private View root;
    private LinearLayout body;
    private LinearLayout imgBg;
    private LinearLayout innerBody;
    private View container;
    private Toolbar toolbar;

    private Spinner textAlignmentSpinner;
    private Spinner fontThicknessSpinner;
    private Spinner colorThemeSpinner;

    private TextView appName;
    private TextView by;
    private TextView authorName;
    private TextView years;

    private boolean iconsDark = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(getAboutThemeFromXML());

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_about);
        DrawableManager.getInstance(this).setColorOfDrawables(ThemeManager.getInstance().getPrimaryColor(this));

        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int width = displaymetrics.widthPixels;
        int height = displaymetrics.heightPixels;

        container = findViewById(R.id.container);
        body = findViewById(R.id.body);
        innerBody = findViewById(R.id.innerBody);
        root = findViewById(R.id.root);
        imgBg = findViewById(R.id.imgbg);
        toolbar = findViewById(R.id.toolbar);

        introView = findViewById(R.id.introView);
        introView.setLayoutParams(new RelativeLayout.LayoutParams((width), (height / 2)));
        findViewById(R.id.anchor).setLayoutParams(new RelativeLayout.LayoutParams((width), (height / 2)));

        appName = findViewById(R.id.appName);
        by = findViewById(R.id.by);
        authorName = findViewById(R.id.authorName);
        years = findViewById(R.id.years);

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));

        changeAlignmentOfTexts();
        changeTypefaceOfTexts(Globals.fontThickness);
        changeColorOfTexts(Globals.colorTheme);

        try {
            addTitleAndIconFromXML();
        }
        catch(Exception e) { Log.e("Failed to add app info", String.valueOf(e)); }


        fillWithContentFromXML(innerBody, null, null);

        if(Globals.colorTheme == 1) {
            root.setBackgroundColor(getResources().getColor(R.color.white));
            body.setBackgroundColor(getResources().getColor(R.color.white));
            container.setBackgroundColor(getResources().getColor(R.color.white));
            iconsDark = true;
        }

        setUpTextAlignmentSpinner();
        setUpFontThicknessSpinner();
        setUpColorThemeSpinner();
        setUpLanguageSpinner();

        setColorsAccordingToTheme();

        ObservableScrollView scrollView = findViewById(R.id.scroll);
        scrollView.setScrollViewCallbacks(this);

        introImageHeight = height * 40 / 100;

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        ImageView lineImageView = findViewById(R.id.line);
        lineImageView.setImageDrawable(DrawableManager.getInstance(this).getDashedLine());
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        if (hasFocus) {
            int centerX = (imgBg.getLeft() + imgBg.getRight()) / 2;
            int centerY = (imgBg.getTop() + imgBg.getBottom()) / 2;

            int startRadius = 0;
            int endRadius = Math.max(imgBg.getWidth(), imgBg.getHeight());

            Animator anim = ViewAnimationUtils.createCircularReveal(imgBg, centerX, centerY, startRadius, endRadius);
            imgBg.setVisibility(View.VISIBLE);
            anim.setDuration(800);
            anim.start();
        }
    }

    private void setColorsAccordingToTheme() {
        int primaryColor = ThemeManager.getInstance().getPrimaryColor(this);
        int primaryColorDark = ThemeManager.getInstance().getPrimaryColorDark(this);

        toolbar.setBackgroundColor(ScrollUtils.getColorWithAlpha(0, primaryColor));

        TextView chapterTop = findViewById(R.id.chapterTop);
        chapterTop.setTextColor(ScrollUtils.getColorWithAlpha(0, primaryColorDark));

        imgBg.setBackgroundColor(primaryColor);
    }

    @Override
    public void onScrollChanged(int scrollY, boolean firstScroll, boolean dragging) {
        int white = getResources().getColor(R.color.white);
        float alpha = Math.min(1, (float) scrollY / introImageHeight);

        toolbar.setBackgroundColor(ScrollUtils.getColorWithAlpha(alpha, ThemeManager.getInstance().getPrimaryColor(this)));
        introView.setTranslationY(scrollY / 2f);
        TextView header = findViewById(R.id.chapterTop);

        ImageView mHeaderImage = findViewById(R.id.headerImage);

        header.setTextColor(ScrollUtils.getColorWithAlpha(alpha, white));
        if (scrollY < introImageHeight + 10) {
            mHeaderImage.setAlpha(ScrollUtils.getFloat(1 - alpha, 1 - alpha, 1 - alpha));
        }
        else {
            mHeaderImage.setAlpha(ScrollUtils.getFloat(0, 0, 0));
        }
    }

    @Override
    public void onDownMotionEvent() {

    }

    @Override
    public void onUpOrCancelMotionEvent(ScrollState scrollState) {

    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.noanim, R.anim.slide_out);
    }

    public void changeLanguage (View view) {
        findViewById(R.id.languagespinner).performClick();
    }

    private void setUpFontThicknessSpinner() {
        fontThicknessSpinner = findViewById(R.id.fontThickness);

        ArrayAdapter adapter2;
        adapter2 = ArrayAdapter.createFromResource(this, R.array.fontThickness, R.layout.spinner_item);

        fontThicknessSpinner.getBackground().setColorFilter(getResources().getColor(android.R.color.black), PorterDuff.Mode.SRC_ATOP);

        adapter2.setDropDownViewResource(R.layout.spinner_dropdown_item);
        fontThicknessSpinner.setAdapter(adapter2);
        fontThicknessSpinner.setSelection(Globals.fontThickness,false);
        fontThicknessSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Globals.fontThickness = pos;
                changeTypefaceOfTexts(pos);
                Globals.sharedPreferencesEditor.putInt("fontThickness", Globals.fontThickness);
                Globals.sharedPreferencesEditor.commit();
            }
            public void onNothingSelected(AdapterView<?> arg0) { }
        });
    }

    private void setUpTextAlignmentSpinner() {
        textAlignmentSpinner = findViewById(R.id.textalignment);

        ArrayAdapter adapter;
        adapter = ArrayAdapter.createFromResource(this, R.array.textalignment, R.layout.spinner_item);

        textAlignmentSpinner.getBackground().setColorFilter(getResources().getColor(android.R.color.black), PorterDuff.Mode.SRC_ATOP);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        textAlignmentSpinner.setAdapter(adapter);
        textAlignmentSpinner.setSelection(Globals.textAlignment,false);
        textAlignmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Globals.textAlignment = pos;
                changeAlignmentOfTexts();
                Globals.sharedPreferencesEditor.putInt("textAlignment", Globals.textAlignment);
                Globals.sharedPreferencesEditor.commit();
            }
            public void onNothingSelected(AdapterView<?> arg0) { }
        });
    }

    private void setUpColorThemeSpinner() {
        colorThemeSpinner = findViewById(R.id.colorTheme);

        ArrayAdapter adapter;
        adapter = ArrayAdapter.createFromResource(this, R.array.colorTheme, R.layout.spinner_item);

        colorThemeSpinner.getBackground().setColorFilter(getResources().getColor(android.R.color.black), PorterDuff.Mode.SRC_ATOP);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        colorThemeSpinner.setAdapter(adapter);
        colorThemeSpinner.setSelection(Globals.colorTheme,false);
        colorThemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Globals.colorTheme = pos;
                changeColorOfTexts(pos);
                invertColorsOfIcons();
                Globals.sharedPreferencesEditor.putInt("colorTheme", Globals.colorTheme);
                Globals.sharedPreferencesEditor.commit();
            }
            public void onNothingSelected(AdapterView<?> arg0) { }
        });
    }

    private void setUpLanguageSpinner() {
        Spinner languageSpinner = findViewById(R.id.languagespinner);

        // Hide language switch button if only one language specified
        if(getResources().getStringArray(R.array.languages).length < 2) {
            findViewById(R.id.languageSwitchButton).setVisibility(View.GONE);
            return;
        }

        ArrayAdapter adapter;
        adapter = ArrayAdapter.createFromResource(this, R.array.languages, R.layout.spinner_dropdown_item_language);

        languageSpinner.setAdapter(adapter);
        languageSpinner.setSelection(Globals.languageCode, false);
        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if(pos == Globals.languageCode) return;

                Globals.sharedPreferencesEditor.putInt("setLanguage", pos);
                Globals.sharedPreferencesEditor.putString("firstTime","Language has been switched!");
                Globals.sharedPreferencesEditor.commit();
                Globals.changeLanguage = true;

                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
            public void onNothingSelected(AdapterView<?> arg0) { }
        });
    }

    public void openSpinner(View view) {
        textAlignmentSpinner.performClick();
    }

    public void openSpinner2(View view) {
        fontThicknessSpinner.performClick();
    }

    public void openSpinner3(View view) {
        colorThemeSpinner.performClick();
    }

    private void changeAlignmentOfTexts() {
        for(int i=0; i < innerBody.getChildCount(); i++) {
            View child = innerBody.getChildAt(i);
            if(child instanceof CustomText) {
                Globals.changeAlignmentOfText((CustomText)child);
                child.requestLayout();
            }
        }
    }

    private void changeTypefaceOfTexts(int thicknessCode) {
        Typeface typeface = Globals.thinLato;
        if (thicknessCode == 1) typeface =  Globals.regularLato;
        else if (thicknessCode == 2) typeface =  Globals.boldLato;

        for(int i=0; i < innerBody.getChildCount(); i++) {
            View child = innerBody.getChildAt(i);
            if(child instanceof CustomText) {
                ((CustomText) child).setTypeface(typeface);
                child.requestLayout();
            }
        }
    }

    private void changeColorOfTexts(int themeCode) {
        int color = getResources().getColor(R.color.white);
        int colorBG = getResources().getColor(R.color.dark);
        if (themeCode == 1) {
            color = getResources().getColor(R.color.dark);
            colorBG = getResources().getColor(R.color.white);
        }

        authorName.setTextColor(color);
        appName.setTextColor(color);
        by.setTextColor(color);
        years.setTextColor(color);

        for(int i=0; i < innerBody.getChildCount(); i++) {
            View child = innerBody.getChildAt(i);
            if(child instanceof CustomText) {
                ((CustomText) child).setTextColor(color);
                child.requestLayout();
            }
        }

        root.setBackgroundColor(colorBG);
        body.setBackgroundColor(colorBG);
        container.setBackgroundColor(colorBG);
        root.requestLayout();
        body.requestLayout();
        container.requestLayout();
    }

    private void invertColorsOfIcons() {
        if(iconsDark && Globals.colorTheme == 0 || !iconsDark && Globals.colorTheme == 1) {
            for(int i=0; i < innerBody.getChildCount(); i++) {
                View child = innerBody.getChildAt(i);
                if(child instanceof ImageView && child.getTag() != null && child.getTag().equals("invert")) {
                    invertIconColor((ImageView)child);
                }
            }
            iconsDark = !iconsDark;
        }
    }

    private void invertIconColor(ImageView currImage) {
        Drawable icon = currImage.getDrawable();

        if(icon!=null) {
            // Invert colors of image
            Bitmap fromDrawable = ((BitmapDrawable)icon).getBitmap();
            fromDrawable = fromDrawable.copy(Bitmap.Config.ARGB_8888 , true);
            Drawable newDrawable = new BitmapDrawable(getResources(), ImageManager.invertColorOfImage(fromDrawable));
            currImage.setImageDrawable(newDrawable);

            currImage.requestLayout();
        }
    }

    private int getAboutThemeFromXML() {
        File xmlAbout = FileManager.getInstance().getFileFromStorage("about.xml", this);
        if(xmlAbout == null) return ThemeManager.DEFAULT_THEME;

        try {
            FileInputStream fis = new FileInputStream(xmlAbout);

            XmlPullParser xpp = XmlPullParserFactory.newInstance().newPullParser();
            xpp.setInput(fis, null);
            while (xpp.getEventType() != XmlPullParser.END_DOCUMENT) {
                if (xpp.getEventType() == XmlPullParser.START_TAG) {
                    if (xpp.getName().equals("about")) {
                        String themeName =  xpp.getAttributeValue(null, "theme");
                        if(themeName != null) {
                            int theme = ThemeManager.getInstance().getThemeFromName(themeName, getResources());
                            if(theme != 0) return theme;
                        }
                    }
                }
                xpp.next();
            }
        }
        catch(Exception e) {
            Log.e("Cannot get about theme", e.toString());
        }

        return ThemeManager.DEFAULT_THEME;
    }

    private void addTitleAndIconFromXML() throws IOException, XmlPullParserException {
        File xmlAbout = FileManager.getInstance().getFileFromStorage("about.xml", this);
        if(xmlAbout == null) return;

        FileInputStream fis = new FileInputStream(xmlAbout);

        ContentParser parser = new ContentParser(getResources(), this,null,null);

        XmlPullParser xpp = XmlPullParserFactory.newInstance().newPullParser();
        xpp.setInput(fis, null);

        while (xpp.getEventType() != XmlPullParser.END_DOCUMENT) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                if (xpp.getName().equals("title")) {
                    String title = parser.getTextFromTag(xpp);
                    CustomText titleText = findViewById(R.id.appName);
                    titleText.setText(title);
                }
                else if (xpp.getName().equals("author")) {
                    String author = parser.getTextFromTag(xpp);
                    CustomText titleText = findViewById(R.id.authorName);
                    titleText.setText(author);
                }
                else if (xpp.getName().equals("icon")) {
                    parser.setImageFromURL((ImageView)findViewById(R.id.headerImage), xpp.getAttributeValue(null, "src"), null, null, this);
                }
            }
            if(xpp.getEventType() == XmlPullParser.END_TAG && xpp.getName().equals("content")) return;

            xpp.next();
        }
    }
}

