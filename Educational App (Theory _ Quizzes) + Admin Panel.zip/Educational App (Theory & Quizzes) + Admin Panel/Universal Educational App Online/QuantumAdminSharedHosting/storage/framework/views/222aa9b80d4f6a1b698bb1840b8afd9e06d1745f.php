<?php $__env->startSection('content'); ?>
<div class="main-content">
  <main class="main">
    <header class="header--2MTvIGNc3d">
      <div class="snackbar--3eko3atkJ5 error--1-4W5PV9sw" role="button">
        <span aria-label="su-exclamation-triangle" class="su-exclamation-triangle icon--3hL7E25P-t"></span>
        <div class="text--YXWqBt3seP"><strong>Error</strong> -</div>
        <span aria-label="su-times" class="su-times clickable--2-TzL1jn1k close-icon--2GVT-mVzOc" role="button" tabindex="0"></span>
      </div>
      <div class="snackbar--3eko3atkJ5 warning--1t9Esjcwiz" role="button">
        <span aria-label="su-bell" class="su-bell icon--3hL7E25P-t"></span>
        <div class="text--YXWqBt3seP"><strong>Warning</strong> -</div>
      </div>
      <nav class="toolbar--2aA3VIsptd light--oIqXlbEbXx">
        <div class="controls--2YAMXys21b grow--2KB1wtNeK3">
          <div class="items-container--3v79arC6i5">
            <ul class="items--2UaqaDVVnV light--ZAKOwIF2HH">
              <li>
                <!-- ONE LEVEL CHAPTER -->
                <a href="#" style="text-decoration: none" id="new-chapter-button">
                  <button class="button--Fry28Tt4id light--3tjxVCiYyF add-1-Chapter">
                      <span aria-label="su-plus-circle" class="su-plus-circle icon--2BbYiI_UQ5"></span>
                      <span class="label--36XumMAKrW">Add one level chapter</span>
                  </button>
                </a>
              </li>

              <li>
                <!-- TWO LEVEL CHAPTER -->
                  <button class="button--Fry28Tt4id light--3tjxVCiYyF add-2-Chapter">
                      <span aria-label="su-plus-circle" class="su-plus-circle icon--2BbYiI_UQ5"></span>
                      <span class="label--36XumMAKrW">Add two level chapter</span>
                  </button>
              </li>

              <li>
                <button id="deleteChapter" class="button--Fry28Tt4id light--3tjxVCiYyF" disabled=""><span aria-label="su-trash-alt" class="su-trash-alt icon--2BbYiI_UQ5"></span><span class="label--36XumMAKrW">Delete</span></button>
              </li>
              <li>
                <button class="button--Fry28Tt4id light--3tjxVCiYyF"><span aria-label="su-download" class="su-download icon--2BbYiI_UQ5"></span><span class="label--36XumMAKrW">Export</span></button>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <div class="view-container-3">
      <div class="list-container--1KaAm9Rrfq">
        <div class="list--24qxBVT_IF">
          <section>
            <div class="dark--3w5GzWBb9F">
              <table class="table--3OVMF8dOBt">
                <thead class="header--18fHWvcEtu">
                  <tr>
                    <th class="header-button-cell--2jMdDWPow1 header-cell--1qOOcy4Q47">
                      <span><span aria-label="su-pen" class="su-pen"></span></span>
                    </th>
                    <!-- SELECT ALL -->
                    <th class="header-cell--1qOOcy4Q47">
                      <span>
                        <label class="label--22nuJrNdMC">
                          <span class="switch--52fMu6kGAZ checkbox--2Z3YMYLqUa light--29kb21gbll"><input id="selectAll" type="checkbox" value="" /><span></span></span>
                        </label>
                      </span>
                    </th>

                    <th class="header-cell--1qOOcy4Q47 clickable--lc4pQQLkgC">
                      <p>Chapter Name</p>
                    </th>
                    <th class="header-cell--1qOOcy4Q47 clickable--lc4pQQLkgC"><p>Chapter type</p></th>
                  </tr>
                </thead>
                <tbody id="chapters-table-body">

                  <!-- CHAPTER TEMPLATE -->
                  <tr class="row--16jZlysVSE chapter" id="chapter-template-0" style="display:none;">
                    <td class="button-cell--15ZsRHax0E cell--3QhdjYDo1X">
                      <div class="cell-content--2c7QOZz1IK">
                        <a href=# class="edit-chapter-link">
                          <button><span aria-label="su-pen" class="su-pen"></span></button>
                        </a>
                      </div>
                    </td>
                    <td class="cell--3QhdjYDo1X small--1KOK57-GZT">
                      <div class="cell-content--2c7QOZz1IK">
                        <label class="label--22nuJrNdMC">
                          <span class="switch--52fMu6kGAZ checkbox--2Z3YMYLqUa dark--1gdZ2dJMIJ"><input type="checkbox" class="select-chapter" value="e7c752ce-0da6-4eb5-9f29-80009c5154f5" /><span></span></span>
                        </label>
                      </div>
                    </td>
                    <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK chapter-title"></div></td>
                    <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK chapter-type"></div></td>
                  </tr>

                </tbody>
              </table>
            </div>
          </section>
        </div>
      </div>
    </div>
  </main>
</div>

<!-- MODAL -->
<div id="modal" style="display:none;">
  <div class="backdrop--1NPZgaTLwy visible--2Ns3EfQy8A fixed--2GqQpeyTUu" role="button"></div>
  <div class="dialog-container--3iqPqgpIht open--1ztEKgXgPI">
    <div class="dialog--RUeFRUqJ7i">
      <section class="content--1lT7Ozsit1">
        <header></header>
        <article></article>
        <footer>
          <button id="ok" class="button--319u6U1AIl primary--1wekDI7P-q" type="button"><span class="text--3HNWf-tIc7">Ok</span></button>
          <button id="cancel" class="button--319u6U1AIl secondary--1n10BKfoP3" type="button"><span class="text--3HNWf-tIc7">Cancel</span></button>
        </footer>
      </section>
    </div>
  </div>
</div>

<script>
  // ADD & DELETE CHAPTER
  let chapter_counter = 0;
  let numberOfClicked = 0;

  $(document).ready(function(e){

    $(".add-1-Chapter").click(function(e){

    });

    $(".add-2-Chapter").click(function(e){

    });
  });


  function createChapter(title, type, chapterNumber) {
    chapter_counter++;
    let new_chapter = $("#chapter-template-0").clone();
    // modify the id
    new_chapter.css("display","table-row");
    new_chapter.attr("id","chapter-"+chapter_counter);
    new_chapter.addClass("empty");

    new_chapter.find(".chapter-title").text(title);
    new_chapter.find('.chapter-type').text(type);
    new_chapter.find(".edit-chapter-link").attr("href","edit-chapter/" + chapterNumber);

    // add to the table
    new_chapter.appendTo("#chapters-table-body");

    new_chapter.find(".select-chapter").on('click',(function(e){
      checkboxClicked($(this));
    }));
  }

  function checkboxClicked(button) {
    let parentChapter = button.closest(".chapter");

    if(parentChapter.hasClass("clicked")){
        parentChapter.removeClass("clicked");
        parentChapter.addClass("empty"); //new
        numberOfClicked-=1;
        if(numberOfClicked < 1){
          $("#deleteChapter").attr('disabled',true);
        }
    }
    else {
        parentChapter.addClass("clicked");
        parentChapter.removeClass("empty"); // new
        numberOfClicked+=1;
        $("#deleteChapter").attr('disabled',false);
    }
  }

      $('#selectAll').click(function(e){

        $('.empty').each(function(e){
          $(this).addClass("clicked").removeClass("empty");
          numberOfClicked+=1;
          $("#deleteChapter").attr('disabled',false);
        })
      })

</script>


<script>
  // MODAL
  $("#deleteChapter").click(function(e){
    // show modal
    showModal(
    "Delete?"
    ,
    "This operation will delete selected chapters and cannot be undone. \nDo you wish to proceed?"
    );
  });

  $('#cancel').click(function(e){
    // close modal
    $("#modal").css("display","none");
  });

  $('#ok').click(function(e){
    // delete chapters
    $('.clicked').each(function(e){
      $(this).remove();
      numberOfClicked-=1;
    });
    if(numberOfClicked < 1){
      $("#deleteChapter").attr('disabled',true);
    }
    // close modal
    $("#modal").fadeOut("slow").css("display","none");
  });

  function showModal(modalHeading, modalText) {
    $("#modal").find("header").text(modalHeading);
    $("#modal").find("article").text(modalText);
    // show modal
    $("#modal").fadeIn().css("display","block");
  }
</script>


<script>
let xhr = new XMLHttpRequest();
xhr.open('GET', 'xml/chapters.xml', false);
xhr.onreadystatechange = function () {
  if(xhr.readyState === 4 && (xhr.status === 200 || xhr.status == 0)) parseChapterTitles(xhr.responseText);
};
xhr.send();

function parseChapterTitles(xml) {
  let parser = new DOMParser();
  let xmlChapters = parser.parseFromString(xml,"text/xml");


  
  let chapters = xmlChapters.getElementsByTagName("chapter");
  let i;
  for (i = 0; i < chapters.length; i++) {
    let chapterTitle = chapters[i].getElementsByTagName("title")[0].childNodes[0].nodeValue;
    createChapter(chapterTitle, "One Level Chapter", i + 1);
  }
  i++;
  $("#new-chapter-button").attr("href","/edit-chapter/" + i);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vomad\quantum-admin\resources\views/chapters.blade.php ENDPATH**/ ?>