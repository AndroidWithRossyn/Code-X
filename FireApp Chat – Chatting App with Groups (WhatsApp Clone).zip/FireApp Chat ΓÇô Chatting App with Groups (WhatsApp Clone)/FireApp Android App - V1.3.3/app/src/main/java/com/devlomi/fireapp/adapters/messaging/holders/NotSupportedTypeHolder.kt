package com.devlomi.fireapp.adapters.messaging.holders

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.devlomi.fireapp.adapters.messaging.holders.base.BaseReceivedHolder

 class NotSupportedTypeHolder(context: Context, itemView: View) : BaseReceivedHolder(context,itemView)
