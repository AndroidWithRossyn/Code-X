package com.devlomi.fireapp.adapters.messaging.holders

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.devlomi.fireapp.R

class TimestampHolder(itemView: View) : RecyclerView.ViewHolder(itemView)


