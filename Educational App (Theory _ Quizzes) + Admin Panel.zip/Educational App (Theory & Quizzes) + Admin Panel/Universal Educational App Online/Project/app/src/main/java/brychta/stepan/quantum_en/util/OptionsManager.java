package brychta.stepan.quantum_en.util;

import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class OptionsManager {
    private boolean enableAds = false;
    private int timeBetweenAds = 5 * 60 * 1000;

    private String themeName = "Menu15";
    private String appName = "Quantum Online";
    private boolean enableTheory = true;
    private boolean enableTests = false;
    private boolean enableSupport = false;
    private boolean enableTabs = false;
    private boolean enableAppName = false;
    private static OptionsManager INSTANCE;

    private Context context;

    private boolean changesRequireAppRestart;


    public OptionsManager(Context context) {
        INSTANCE = this;
        this.context = context;
        try { loadConfigurationFromStorage(true); }
        catch(Exception e) { Log.e("Failed to load config", e.toString()); }
    }

    public static OptionsManager getInstance(Context context) {
        if(INSTANCE != null) return INSTANCE;
        else return new OptionsManager(context);
    }

    public void update() {
        try { loadConfigurationFromStorage(false); }
        catch(Exception e) { Log.e("Failed to update config", e.toString()); }
    }

    public void loadConfigurationFromStorage(boolean callingAtAppLaunch) throws XmlPullParserException, IOException {
        File xmlOptions = FileManager.getInstance().getFileFromStorage("options.xml", context);

        if(!xmlOptions.exists() || xmlOptions.length() == 0) return;

        XmlPullParser xpp = XmlPullParserFactory.newInstance().newPullParser();
        xpp.setInput(new FileInputStream(xmlOptions), null);

        changesRequireAppRestart = false;

        while (xpp.getEventType() != XmlPullParser.END_DOCUMENT) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                String tagName = xpp.getName();
                String tagText;
                switch(tagName)
                {
                    case "app-name":
                        appName = xpp.nextText();
                        break;
                    case "enable-theory":
                        tagText = xpp.nextText();
                        if(!callingAtAppLaunch && enableTheory != tagText.equals("true")) changesRequireAppRestart = true;

                        enableTheory = tagText.equals("true");
                        break;
                    case "enable-tests":
                        tagText = xpp.nextText();

                        if(!callingAtAppLaunch && enableTests != tagText.equals("true")) changesRequireAppRestart = true;

                        enableTests = tagText.equals("true");
                        break;
                    case "enable-support":
                        tagText = xpp.nextText();

                        if(!callingAtAppLaunch && enableSupport != tagText.equals("true")) changesRequireAppRestart = true;

                        enableSupport = tagText.equals("true");
                        break;
                    case "enable-ads":
                        enableAds = xpp.nextText().equals("true");
                        break;
                    case "enable-tabs":
                        enableTabs = xpp.nextText().equals("true");
                        break;
                    case "enable-appname":
                        enableAppName = xpp.nextText().equals("true");
                        break;
                    case "theme":
                        tagText = xpp.nextText();

                        if(!callingAtAppLaunch && !themeName.equals(tagText)) changesRequireAppRestart = true;

                        themeName = tagText;
                        break;
                    case "time-between-ads":
                        String timeBetweenAdsString = xpp.nextText();
                        if(TextUtils.isDigitsOnly(timeBetweenAdsString))
                            timeBetweenAds = Integer.parseInt(timeBetweenAdsString) * 60 * 1000;
                        break;
                }
            }
            xpp.next();
        }
    }

    public boolean appRestartRequired() {
        return changesRequireAppRestart;
    }

    public boolean theoryEnabled() {
        return enableTheory;
    }

    public boolean testsEnabled() {
        return enableTests;
    }

    public boolean supportEnabled() {
        return enableSupport;
    }

    public boolean adsEnabled() {
        return enableAds;
    }

    public int getTimeBetweenAds() {
        return timeBetweenAds;
    }

    public boolean appNameEnabled() {
        return enableAppName;
    }

    public boolean tabsEnabled() {
        return enableTabs;
    }

    public String getAppName() {
        return appName;
    }

    public String getMenuThemeName() {
        return themeName;
    }

}
