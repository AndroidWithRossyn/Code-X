package brychta.stepan.quantum_en.activities.tests.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import brychta.stepan.quantum_en.R;

public class Circle extends View {

    private static final int START_ANGLE_POINT = 90;
    private final Paint paint;
    private final RectF rect;
    private float angle;

    public Circle(Context context, AttributeSet attrs) {
        super(context, attrs);

        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics()));

        rect = new RectF(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics()), TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics()), TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 260, getResources().getDisplayMetrics()), TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 260, getResources().getDisplayMetrics()));

        angle = 0;
    }

    public void setColor(float percantageCorrect) {
        if(percantageCorrect < 34) {
            paint.setColor(getResources().getColor(R.color.bad));
        }
        else if(percantageCorrect < 67) {
            paint.setColor(getResources().getColor(R.color.average));
        }
        else {
            paint.setColor(getResources().getColor(R.color.good));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawArc(rect, START_ANGLE_POINT, angle, false, paint);
    }

    public float getAngle() {
        return angle;
    }
    public void setAngle(float angle) {
        this.angle = angle;
    }
}