package com.app.androidnewsapp.models;

import java.io.Serializable;

public class User implements Serializable {

    public String token;
    public String user_unique_id;

    public String id;
    public String name;
    public String email;
    public String password;
    public String image;
    public String status;
    public String response;

}
