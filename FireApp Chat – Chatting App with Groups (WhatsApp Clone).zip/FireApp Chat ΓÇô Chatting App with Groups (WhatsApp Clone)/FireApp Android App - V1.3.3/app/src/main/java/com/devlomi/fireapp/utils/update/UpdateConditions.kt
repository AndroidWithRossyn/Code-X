package com.devlomi.fireapp.utils.update

object UpdateConditions {
    val ONLY = "ONLY"
    val AND_ABOVE = "AND_ABOVE"
    val AND_BELOW = "AND_BELOW"
    val NONE = "NONE"
}