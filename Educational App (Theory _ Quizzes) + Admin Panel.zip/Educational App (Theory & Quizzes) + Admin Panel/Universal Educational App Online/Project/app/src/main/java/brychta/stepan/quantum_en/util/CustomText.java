package brychta.stepan.quantum_en.util;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;

import brychta.stepan.quantum_en.R;

public class CustomText extends androidx.appcompat.widget.AppCompatTextView {
    private final static int CHAMPAGNE = 0;
    private final static int LATO = 1;
    private final static int ITAL = 2;
    private final static int REGULAR = 3;

    public CustomText(Context context) {
        super(context);
    }

    public CustomText(Context context, AttributeSet attrs) {
        super(context, attrs);
        parseAttributes(context, attrs);
    }

    public CustomText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        parseAttributes(context, attrs);
    }

    private void parseAttributes(Context context, AttributeSet attrs) {
        TypedArray values = context.obtainStyledAttributes(attrs, R.styleable.CustomText);

        int typeface = values.getInt(R.styleable.CustomText_typeface, 0);

        switch(typeface) {
            case CHAMPAGNE: default:
                  Typeface champagne= Typeface.createFromAsset(context.getAssets(), "fonts/Abel-Regular.ttf");

                setTypeface(champagne);
                break;
            case LATO:
                Typeface lato= Typeface.createFromAsset(context.getAssets(), "fonts/Lato-Thin.ttf");
                setTypeface(lato);
                break;
            case ITAL:
                Typeface ital= Typeface.createFromAsset(context.getAssets(), "fonts/Lato-ThinItalic.ttf");
                setTypeface(ital);
                break;
            case REGULAR:
                Typeface regular= Typeface.createFromAsset(context.getAssets(), "fonts/Lato-Regular.ttf");
                setTypeface(regular);
                break;
        }
        values.recycle();
    }
}