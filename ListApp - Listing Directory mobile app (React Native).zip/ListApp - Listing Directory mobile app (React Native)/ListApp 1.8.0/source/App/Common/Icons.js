export default {
  iconRating: 'md-star',
  iconRatingSize: 15,
  iconRatingColor: 'rgb(27, 229, 141)',
  iconRatingBG: 'transparent',

  //icon ReadMore
  iconReadMore: 'md-arrow-round-forward',
  iconReadMoreSize: 16,
  iconReadMoreColor: 'rgb(255, 255, 255)',
  iconReadMoreBG: 'transparent',

  //config icon for ListingScreen
  iconRatingSizeListing: 14,
}
