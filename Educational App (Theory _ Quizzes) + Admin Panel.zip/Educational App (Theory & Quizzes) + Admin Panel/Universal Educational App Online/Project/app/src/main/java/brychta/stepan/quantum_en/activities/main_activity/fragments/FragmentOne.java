package brychta.stepan.quantum_en.activities.main_activity.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;

import com.github.aakira.expandablelayout.ExpandableLayout;
import com.github.aakira.expandablelayout.ExpandableLayoutListener;
import com.github.aakira.expandablelayout.ExpandableRelativeLayout;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import brychta.stepan.quantum_en.activities.chapters.About;
import brychta.stepan.quantum_en.activities.chapters.ContentParser;
import brychta.stepan.quantum_en.util.Animator;
import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ImageManager;
import brychta.stepan.quantum_en.util.OptionsManager;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.main_activity.MainActivity;

import static brychta.stepan.quantum_en.util.Globals.justLaunched;
import static java.lang.Thread.sleep;

public class FragmentOne extends BaseFragment {
    public static boolean searching = false;

    private CardView continueReading;
    private ImageView continueReadingImage;
    private List<CardView> chapterCards;
    private ImageView iconSearchNothingFound;

    // Each entry contains the code of the parent chapter and a list of all its subchapter cards
    private HashMap<String, List<CardView>> subChapterCards;
    private List<TextView> chapterNames;
    private List<TextView> chapterDescriptions;
    private HashMap<String,ExpandableLayout> expandableChapters;

    // Chapter texts belonging to chapter or subchapter as a single long string. Used for search.
    private HashMap<String, String> chapterTexts;


    public FragmentOne() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_first, container, false);

        this.inflater = inflater;

        continueReading = v.findViewById(R.id.continuereading);
        continueReadingImage = v.findViewById(R.id.continueReadingImage);
        continueReading.setVisibility(View.GONE);
        body = v.findViewById(R.id.body);

        waitingAnimationWrapper = v.findViewById(R.id.waitingAnimationWrapper);
        noInternetWrapper = v.findViewById(R.id.noInternetWrapper);

        scrollView = v.findViewById(R.id.scrollView);
        iconSearchNothingFound = v.findViewById(R.id.icon_search_nothing);

        ((ProgressBar)waitingAnimationWrapper.findViewById(R.id.waitingAnimation)).setIndeterminateTintList(ColorStateList.valueOf(ThemeManager.getInstance().getPrimaryColor(getContext())));

        GradientDrawable circleBackground = new GradientDrawable();
        circleBackground.setShape(GradientDrawable.OVAL);
        circleBackground.setColor(ThemeManager.getInstance().getPrimaryColor(getContext()));
        continueReadingImage.setBackground(circleBackground);

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        continueReading.setVisibility(View.GONE);

        updateLayout();

        downloadFile(FileManager.FileType.CHAPTERS);

        if (Globals.sharedPreferences.getBoolean("bookmarkTrue", false)){
            continueReading.setVisibility(View.VISIBLE);
        }
    }

    void updateLayout() {
        int color = getResources().getColor(R.color.white);
        int colorBG = getResources().getColor(R.color.dark2);
        int colorBG2 = getResources().getColor(R.color.dark3);

        if (Globals.colorTheme == 1) {
            color = getResources().getColor(R.color.dark);
            colorBG = getResources().getColor(R.color.white);
            colorBG2 = getResources().getColor(R.color.light);
        }

        // Content not added yet, nothing to update
        if(chapterCards == null) return;

        for(CardView card : chapterCards) {
            card.setCardBackgroundColor(colorBG);
        }
        for (Map.Entry<String, List<CardView>> entry : subChapterCards.entrySet()) {
            List<CardView> cards = entry.getValue();
            for(CardView card : cards) {
                card.setCardBackgroundColor(colorBG2);
            }
        }
        for(TextView text : chapterNames) {
            text.setTextColor(color);
        }
        for (Map.Entry<String, ExpandableLayout> entry : expandableChapters.entrySet()) {
            ExpandableLayout layout = entry.getValue();
            ((View)layout).setBackgroundColor(colorBG2);
        }
        for(TextView text : chapterDescriptions) {
            Globals.changeTypefaceOfText(text);
        }
    }

    boolean addContent(File xmlChapters) throws XmlPullParserException, IOException {
        Globals.chapterData = new HashMap<>();
        Globals.chapterOrder = new ArrayList<>();

        chapterCards = new ArrayList<>();
        subChapterCards = new HashMap<>();
        chapterTexts = new HashMap<>();
        chapterNames = new ArrayList<>();
        chapterDescriptions = new ArrayList<>();
        expandableChapters = new HashMap<>();

        XmlPullParser xpp;

        if(xmlChapters == null || xmlChapters.length() == 0)  return false;

        xpp = XmlPullParserFactory.newInstance().newPullParser();
        xpp.setInput(new FileInputStream(xmlChapters), null);


        ContentParser parser = new ContentParser(getResources(),getContext(),null,null);

        // Store values of the current chapter button in the following order: title, description and name of icon
        String[] currCardValues = new String[3];
        String[] currSubCardValues = new String[3];

        String chapterTheme = null;

        boolean currChapterHasSubchapters = false;
        boolean parsingSubChapter = false;

        int cardNum = 1;
        int subCardNum = 1;

        ExpandableLayout currSubChapterHolder = null;

        boolean skipCurrentPremiumChapter = false;

        while (xpp.getEventType() != XmlPullParser.END_DOCUMENT) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                if(!skipCurrentPremiumChapter) {
                    if (parser.hidePremiumChapter(xpp)) {
                        skipCurrentPremiumChapter = true;
                        continue;
                    }

                    if (xpp.getName().equals(("chapter"))) {
                        chapterTheme = xpp.getAttributeValue(null, "theme");
                        if (chapterTheme != null)
                            ThemeManager.getInstance().addChapterTheme(String.valueOf(cardNum), chapterTheme, getResources());
                    } else if (xpp.getName().equals(("subchapter"))) {
                        String subChapterTheme = xpp.getAttributeValue(null, "theme");
                        if (subChapterTheme != null)
                            ThemeManager.getInstance().addChapterTheme(cardNum + "_" + subCardNum, subChapterTheme, getResources());

                        // Inherit theme from parent chapter
                        else if (chapterTheme != null)
                            ThemeManager.getInstance().addChapterTheme(cardNum + "_" + subCardNum, chapterTheme, getResources());
                    } else if (xpp.getName().equals("title")) {
                        String chapterTitle = parser.getTextFromTag(xpp);

                        if (!parsingSubChapter) currCardValues[0] = chapterTitle;
                        else currSubCardValues[0] = chapterTitle;
                    } else if (xpp.getName().equals("description")) {
                        String chapterDescription = parser.getTextFromTag(xpp);

                        if (!parsingSubChapter) currCardValues[1] = chapterDescription;
                        else currSubCardValues[1] = chapterDescription;
                    } else if (xpp.getName().equals("icon")) {
                        String iconName = xpp.getAttributeValue(null, "src");
                        if (iconName == null) iconName = "defaulticon";

                        if (!parsingSubChapter) currCardValues[2] = iconName;
                        else currSubCardValues[2] = iconName;
                    } else if (xpp.getName().equals("p") || xpp.getName().equals("h") || xpp.getName().equals("h1")) {
                        String pText = parser.getTextFromTag(xpp);
                        String chapterCode = String.valueOf(cardNum);

                        if (parsingSubChapter) chapterCode += "_" + subCardNum;

                        if (chapterTexts.containsKey(chapterCode))
                            chapterTexts.put(chapterCode, chapterTexts.get(chapterCode) + " " + pText);
                        else chapterTexts.put(chapterCode, pText);
                    } else if (xpp.getName().equals("subchapters")) {
                        // Create container for all subchapters of this chapter
                        currSubChapterHolder = createSubChapterHolder(cardNum);

                        currChapterHasSubchapters = true;
                        parsingSubChapter = true;
                    }
                }
            }
            if (xpp.getEventType() == XmlPullParser.END_TAG) {
                if(xpp.getName().equals("chapter")) {
                    if(skipCurrentPremiumChapter) {
                        skipCurrentPremiumChapter = false;
                        xpp.next();
                        continue;
                    }

                    // End of chapter tag reached, add the corresponding chapter card
                    createNewChapterCard(currCardValues, cardNum, 0, currChapterHasSubchapters, null);

                    currCardValues[0] = "";
                    currCardValues[1] = "";
                    currCardValues[2] = "";

                    subCardNum = 1;
                    cardNum +=1;

                    if(currChapterHasSubchapters) body.addView((View) currSubChapterHolder);
                    
                    currChapterHasSubchapters = false;
                }
                else if(xpp.getName().equals("subchapter") && !skipCurrentPremiumChapter) {
                    createNewChapterCard(currSubCardValues, cardNum, subCardNum, false, currSubChapterHolder);

                    currSubCardValues[0] = "";
                    currSubCardValues[1] = "";
                    currSubCardValues[2] = "";

                    subCardNum +=1;
                }
                else if(xpp.getName().equals("subchapters")) {
                    parsingSubChapter = false;
                }
            }
            xpp.next();
        }
        return true;
    }

    private void createNewChapterCard(String[] chapterCardValues, int chapterNum, int subChapterNum, boolean chapterHasSubchapters, ExpandableLayout subChapterHolder) {
        CardView currChapterButton;
        ImageView chapterOpenImage;

        String chapterCode = String.valueOf(chapterNum);

        // Parent or one-level chapter
        if(subChapterHolder == null) {
            currChapterButton = (CardView) inflater.inflate(R.layout.chaptercard, body,false);
            chapterCards.add(currChapterButton);
        }
        // Two-level chapter
        else {
            currChapterButton = (CardView) inflater.inflate(R.layout.subchaptercard, body,false);

            if(subChapterCards.containsKey(chapterCode)) subChapterCards.get(chapterCode).add(currChapterButton);
            else {
                List<CardView> subChapterCardList = new ArrayList<>();
                subChapterCardList.add(currChapterButton);
                subChapterCards.put(chapterCode, subChapterCardList);
            }

            chapterCode += "_" + subChapterNum;
        }

        Globals.chapterData.put(chapterCode, Arrays.copyOf(chapterCardValues,chapterCardValues.length));
        if(!chapterHasSubchapters) Globals.chapterOrder.add(chapterCode);

        // Set tag of card icon to match chapter code
        chapterOpenImage = currChapterButton.findViewById(R.id.chapteropenimage);
        chapterOpenImage.setTag(chapterCode);

        setIconOfCard(chapterOpenImage, chapterCardValues[2]);
        addTextsToCard(currChapterButton, chapterCardValues[0], chapterCardValues[1]);

        if(chapterHasSubchapters) {
            // Expand subchapters on click
            chapterOpenImage.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ((MainActivity)getActivity()).expandableChapter(v);
                }
            });
        }

        // Add card to body
        if(subChapterHolder == null) body.addView(currChapterButton);
        else {
            LinearLayout subchapterholder = ((View) subChapterHolder).findViewById(R.id.subchapterholder);
            subchapterholder.addView(currChapterButton);
        }
    }

    private void setIconOfCard(final ImageView iconView, final String iconURL) {
        // Default icon
        iconView.setImageResource(R.drawable.testnone);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap bitmap = ImageManager.loadImage(iconURL, getActivity().getBaseContext());
                    ImageManager.updateImageViewFromBitmap(iconView, bitmap, getActivity(), getResources(),true);
                }
                catch(Exception e) {
                    Log.e("Error", "Fragment not attached to activity");
                }
            }
        });
        thread.start();
    }

    private void addTextsToCard(CardView chapterButton, String cardTitle, String cardDesciption) {
        TextView chapterOpenText = chapterButton.findViewById(R.id.cardname);
        TextView chapterOpenSubText = chapterButton.findViewById(R.id.cardsubname);
        chapterNames.add(chapterOpenText);
        chapterDescriptions.add(chapterOpenSubText);

        chapterOpenText.setText(cardTitle);
        chapterOpenSubText.setText(cardDesciption);
    }

    private ExpandableLayout createSubChapterHolder(int chapterNumber) {
        ExpandableLayout expandableChapter = (ExpandableLayout) inflater.inflate(R.layout.expandablelayout, body,false);
        setOnExpandListener((ExpandableRelativeLayout) expandableChapter);
        ((View)expandableChapter).setTag("chapterExpanded" + chapterNumber);
        expandableChapter.collapse();
        expandableChapters.put(String.valueOf(chapterNumber), expandableChapter);

        return expandableChapter;
    }

    private void setOnExpandListener(final ExpandableRelativeLayout expandableLayout) {
        expandableLayout.setListener(new ExpandableLayoutListener() {
            @Override
            public void onAnimationStart() { }

            @Override
            public void onAnimationEnd() { }

            @Override
            public void onPreOpen() {
            }

            @Override
            public void onPreClose() { }

            @Override
            public void onOpened() {
                expandableLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }

            @Override
            public void onClosed() { }
        });
    }

    public void search(String searchTerm) {
        searchTerm = searchTerm.trim().toLowerCase();
        if(searchTerm.equals("")) {
            cancelSearch(true);
            return;
        }

        if(chapterCards == null) return;

        searching = true;
        continueReading.setVisibility(View.GONE);

        boolean atLeastOneCardVisible = false;

        for (int i=0; i < chapterCards.size(); i++) {
            CardView card = chapterCards.get(i);
            String chapterCode = String.valueOf(i+1);

            boolean keepCard = false;

            // Chapter has subchapters
            if(subChapterCards.containsKey(chapterCode)) {
                List<CardView> cards = subChapterCards.get(chapterCode);
                if(cards == null) continue;
                boolean atLeastOneSubchapterVisible = false;

                for (int j=0; j < cards.size(); j++) {
                    CardView subChapterCard = cards.get(j);
                    String subChapterCode = String.valueOf(j+1);

                    boolean keepSubchapterCard = searchChapterContent(chapterCode + "_" + subChapterCode,searchTerm,subChapterCard, 40);

                    if(keepSubchapterCard) {
                        atLeastOneSubchapterVisible = true;
                        subChapterCard.setVisibility(View.VISIBLE);
                    }
                    else subChapterCard.setVisibility(View.GONE);
                }
                if(atLeastOneSubchapterVisible) keepCard = true;
            }
            else keepCard = searchChapterContent(chapterCode, searchTerm, card, 80);

            if(keepCard) atLeastOneCardVisible = true;

            int visibility = keepCard ? View.VISIBLE : View.GONE;
            changeCardVisibility(card, visibility, chapterCode);
        }
        if(atLeastOneCardVisible) iconSearchNothingFound.setVisibility(View.GONE);
        else iconSearchNothingFound.setVisibility(View.VISIBLE);
    }

    private void changeCardVisibility(CardView card, int visibility, String chapterCode) {
        if(visibility != View.GONE && visibility != View.VISIBLE) return;

        card.setVisibility(visibility);
        if(expandableChapters.containsKey(chapterCode)) {
            ExpandableLayout layout = expandableChapters.get(chapterCode);
            if(layout != null) {
                ((View)layout).setVisibility(visibility);
                if(visibility == View.VISIBLE) layout.expand(1,null);
            }
        }
    }

    private boolean searchChapterContent(String chapterCode, String searchTerm, CardView card, int maxCharacters) {
        boolean keepCard = false;

        if(chapterTexts.containsKey(chapterCode)) {
            String text = chapterTexts.get(chapterCode);

            if(text != null) {
                String lowerCaseText = text.toLowerCase();
                if(lowerCaseText.contains(searchTerm)) {
                    CustomText chapterSubText = card.findViewById(R.id.cardsubname);

                    int startIndex = lowerCaseText.indexOf(searchTerm);
                    if(startIndex > 1) startIndex -= 2;
                    int prevWordStartIndex = Math.max(0, lowerCaseText.substring(0, startIndex).lastIndexOf(" "));

                    if(startIndex - prevWordStartIndex > 20) {
                        prevWordStartIndex = Math.max(0, startIndex - 20);
                    }

                    String prepend = "";
                    String append = "...";
                    if(prevWordStartIndex > 0) prepend = "...";
                    if(lowerCaseText.length() - prevWordStartIndex > maxCharacters) append = "...";

                    String newText = prepend + text.substring(prevWordStartIndex, prevWordStartIndex + Math.min(maxCharacters,text.length() - prevWordStartIndex)).trim() + append;

                    int highlightColor = Color.argb(180,85,128,165);
                    int textHighlightColor = Color.rgb(255,255,255);

                    if(Globals.colorTheme == 1) {
                        highlightColor = Color.argb(128,245,232,38);
                        textHighlightColor = Color.rgb(0,0,0);
                    }
                    SpannableString highlightedText = colorString(highlightColor,textHighlightColor, newText,searchTerm);



                    if(text.length() - prevWordStartIndex > maxCharacters) chapterSubText.setText(highlightedText);
                    else chapterSubText.setText(highlightedText);

                    keepCard = true;
                }
            }
        }
        return keepCard;
    }


    private static SpannableString colorString(int color, int textColor, String text, String textToColor) {
        SpannableString coloredString = new SpannableString(text);

        int startColorIndex = text.toLowerCase().indexOf(textToColor);
        if(startColorIndex < 0) return new SpannableString(text);

        int endColorIndex = startColorIndex + textToColor.length();

        coloredString.setSpan(new BackgroundColorSpan(color), startColorIndex, endColorIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        coloredString.setSpan(new ForegroundColorSpan(textColor), startColorIndex, endColorIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        return coloredString;
    }

    public void cancelSearch(boolean collapseExpandableViews) {
        searching = false;
        iconSearchNothingFound.setVisibility(View.GONE);

        if (Globals.sharedPreferences.getBoolean("bookmarkTrue", false)){
            continueReading.setVisibility(View.VISIBLE);
        }

        // Content not added yet
        if(chapterCards == null) return;

        for (int i=0; i < chapterCards.size(); i++) {
            CardView card = chapterCards.get(i);
            String chapterCode = String.valueOf(i+1);

            // Set card to visible and reset text to original chapter description
            resetCard(card,chapterCode);

            if (subChapterCards.containsKey(chapterCode)) {
                List<CardView> cards = subChapterCards.get(chapterCode);
                if(cards == null) continue;

                for (int j=0; j < cards.size(); j++) {
                    CardView subChapterCard = cards.get(j);
                    String subChapterCode = String.valueOf(j+1);

                    resetCard(subChapterCard,chapterCode + "_" + subChapterCode);
                }
            }
        }

        for (Map.Entry<String, ExpandableLayout> entry : expandableChapters.entrySet()) {
            ExpandableLayout layout = entry.getValue();
            ((View)layout).setVisibility(View.VISIBLE);
            if(collapseExpandableViews) layout.setExpanded(false);
        }
    }

    private void resetCard(CardView card, String chapterCode) {
        card.setVisibility(View.VISIBLE);
        if (Globals.chapterData.containsKey(chapterCode)) {
            CustomText cardSubText = card.findViewById(R.id.cardsubname);
            if(Globals.chapterData.containsKey(chapterCode)) {
                String originalText = Globals.chapterData.get(chapterCode)[1];
                cardSubText.setText(originalText);
            }
        }
    }

    void startFileDownload() {
        downloadFile(FileManager.FileType.CHAPTERS);
    }
}
