import Constants from './Constants'

// more explaination here
// support Editor's pick like Apple news - swipe

export default [
  Constants.Layout.threeColumn,
  Constants.Layout.threeColumn,
  Constants.Layout.threeColumn,

  Constants.Layout.list,
  Constants.Layout.list,
  Constants.Layout.list,
  Constants.Layout.list,

  Constants.Layout.card,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.twoColumn,
  Constants.Layout.simple,
  Constants.Layout.simple,
  Constants.Layout.simple,
  Constants.Layout.simple,
  Constants.Layout.card,
]
