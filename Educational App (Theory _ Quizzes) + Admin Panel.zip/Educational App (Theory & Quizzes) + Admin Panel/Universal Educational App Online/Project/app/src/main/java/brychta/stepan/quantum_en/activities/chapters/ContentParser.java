package brychta.stepan.quantum_en.activities.chapters;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;

import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import brychta.stepan.quantum_en.util.Animator;
import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.util.DrawableManager;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ImageManager;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.BaseActivity;

import static android.text.Html.FROM_HTML_SEPARATOR_LINE_BREAK_HEADING;
import static android.text.Html.FROM_HTML_SEPARATOR_LINE_BREAK_LIST;
import static androidx.core.text.HtmlCompat.FROM_HTML_SEPARATOR_LINE_BREAK_LIST_ITEM;
import static androidx.core.text.HtmlCompat.FROM_HTML_SEPARATOR_LINE_BREAK_PARAGRAPH;

public class ContentParser {
    private Resources resources;
    private LayoutInflater inflater;
    private LinearLayout parentView;
    private Context context;

    private int chapterNum;
    private int subChapterNum = 0;

    public ContentParser(Resources resources, Context context, LayoutInflater inflater, LinearLayout parent) {
        this.resources = resources;
        this.inflater = inflater;
        this.parentView = parent;
        this.context = context;
    }

    public void processChapterContent(String chapterCode, String nextChapterCode, Activity chapterActivity) throws XmlPullParserException, IOException {
        XmlPullParser xpp = XmlPullParserFactory.newInstance().newPullParser();

        if(chapterCode != null) {
            File xmlChapters = FileManager.getInstance().getXMLChapters();

            if(xmlChapters == null) return;

            FileInputStream fis = new FileInputStream(xmlChapters);
            xpp.setInput(fis, null);

            chapterNum = Integer.parseInt(chapterCode.split("_")[0]);
            if(chapterCode.contains("_")) subChapterNum = Integer.parseInt(chapterCode.split("_")[1]);

            reachChapter(xpp, chapterNum, subChapterNum);
        }
        // About section
        else {
            File xmlAbout = FileManager.getInstance().getFileFromStorage("about.xml", context);

            if(xmlAbout == null) return;

            FileInputStream fis = new FileInputStream(xmlAbout);
            xpp.setInput(fis, null);
        }

        while (xpp.getEventType() != XmlPullParser.END_DOCUMENT) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                if (xpp.getName().equals("p")) {
                    String type = xpp.getAttributeValue(null, "type");
                    String text = getTextFromTag(xpp);

                    if (type != null && type.equals("quote")) addQuoteToChapter(text);
                    else addTextToChapter(text);
                }
                else if (xpp.getName().equals("img") || xpp.getName().equals("image")) {
                    addImageToChapter(xpp.getAttributeValue(null, "src"), xpp.getAttributeValue(null, "width"),
                                      xpp.getAttributeValue(null, "invert"), xpp.getAttributeValue(null, "local"), chapterActivity);
                }
                else if (xpp.getName().equals("h") || xpp.getName().equals("h1")) {
                    String text = getTextFromTag(xpp);
                    addHeadingToChapter(text);
                }
                else if (xpp.getName().equals("button")) {
                    String sourceStringName = xpp.getAttributeValue(null, "fromString");
                    String link = xpp.getAttributeValue(null, "link");
                    String openTest = xpp.getAttributeValue(null, "open-quiz");
                    String email = xpp.getAttributeValue(null, "email");
                    String theme = xpp.getAttributeValue(null, "theme");
                    String text = xpp.nextText();

                    addButtonToChapter(text, sourceStringName, theme, openTest, nextChapterCode, link, email);
                }
                else if (xpp.getName().equals("hr")) {
                    addLineToChapter();
                }
            }
            if(xpp.getEventType() == XmlPullParser.END_TAG && xpp.getName().equals("content")) return;

            xpp.next();
        }
    }

    private void reachChapter(XmlPullParser xpp, int chapterNum, int subChapterNum) throws XmlPullParserException, IOException {
        int chapterCounter = 0;
        int subChapterCounter = 0;

        boolean parsingCorrectParentChapter = false;

        while ((xpp.getEventType() != XmlPullParser.END_DOCUMENT) && chapterCounter <= chapterNum && (subChapterNum == 0 || subChapterCounter <= subChapterNum)) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                if (xpp.getName().equals("chapter"))  {
                    if(hidePremiumChapter(xpp)) {
                        xpp.next();
                        continue;
                    }
                    chapterCounter += 1;
                }
                else if (xpp.getName().equals("subchapter") && parsingCorrectParentChapter)  subChapterCounter += 1;

                // Contents of requested chapter/subchapter reached, return to content parsing function
                else if (xpp.getName().equals("content") && chapterCounter == chapterNum && (subChapterNum == 0)) return;
                else if (xpp.getName().equals("content") && chapterCounter == chapterNum && parsingCorrectParentChapter && subChapterCounter == subChapterNum)return;

                else if (xpp.getName().equals("subchapters") && chapterCounter == chapterNum) parsingCorrectParentChapter = true;
            }
            xpp.next();
        }
    }

    private void addHeadingToChapter(String text) {
        CustomText heading = (CustomText) inflater.inflate(R.layout.heading, parentView,false);

        heading.setText(text);
        parentView.addView(heading);

        if(Globals.colorTheme == 1) heading.setTextColor(resources.getColor(R.color.dark));
    }

    public static void loadTextFromHTML(TextView textView, String text) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            textView.setText(Html.fromHtml(text, FROM_HTML_SEPARATOR_LINE_BREAK_HEADING | FROM_HTML_SEPARATOR_LINE_BREAK_LIST_ITEM | FROM_HTML_SEPARATOR_LINE_BREAK_PARAGRAPH | FROM_HTML_SEPARATOR_LINE_BREAK_LIST));
        } else {
            textView.setText(Html.fromHtml(text));
        }
    }

    private void addTextToChapter(String text) {
        CustomText currText = (CustomText) inflater.inflate(R.layout.documentview, parentView,false);
        loadTextFromHTML(currText, text);
        
        parentView.addView(currText);
        Globals.changeAlignmentOfText(currText);
        Globals.changeTypefaceOfText(currText);
        if(Globals.colorTheme == 1) currText.setTextColor(resources.getColor(R.color.dark));
    }

    public String getTextFromTag(XmlPullParser xpp) throws XmlPullParserException, IOException {
        String sourceStringName = xpp.getAttributeValue(null, "fromString");
        String text = xpp.nextText();

        if(sourceStringName != null && text.equals("")) text = getTextFromStringName(sourceStringName);
        else text = text.replace("\\n", "\n");

        return text;
    }

    private void addQuoteToChapter(String text) {
        TextView currText = (TextView) inflater.inflate(R.layout.quote, parentView,false);

        currText.setText(text);
        parentView.addView(currText);

        Globals.changeTypefaceOfTextItalics(currText);
        if(Globals.colorTheme == 1) currText.setTextColor(resources.getColor(R.color.dark));
    }

    private void addImageToChapter(String src, String imageWidth, String invert, String local, Activity activity) {
        if(local != null && local.equals("true")) addLocalImageToChapter(src,imageWidth,invert,activity);
        else addImageToChapterFromURL(src,imageWidth, invert, activity);
    }


    private void addLocalImageToChapter(String imageName, String imageWidth, String invert, Activity activity) {
        ImageView imageView = (ImageView) inflater.inflate(R.layout.chapter_image, parentView,false);

        int imageID = resources.getIdentifier(imageName,"drawable",Globals.PACKAGE_NAME);

        // Image not found
        if(imageID == 0) return;

        Bitmap fromDrawable = BitmapFactory.decodeResource(context.getResources(),imageID);
        Drawable imageAsDrawable = ImageManager.invertImage(fromDrawable, invert, resources);
        if(invert != null && invert.equals("true")) imageView.setTag("invert");

        ImageManager.updateImageView(imageView, imageAsDrawable, activity, true);
        ImageManager.setWidthOfImage(imageView, imageWidth, resources);
        parentView.addView(imageView);
    }

    private void addImageToChapterFromURL(final String imageURL, final String imageWidth, final String invert, final Activity activity) {
        final ImageView imageView = (ImageView) inflater.inflate(R.layout.chapter_image, parentView,false);

        // Default image
        imageView.setImageResource(R.drawable.placeholder);
        parentView.addView(imageView);

        setImageFromURL(imageView, imageURL, imageWidth, invert, activity);
    }

    public void setImageFromURL(final ImageView imageView, final String imageURL, final String imageWidth, final String invert, final Activity activity) {
        ImageManager.setWidthOfImage(imageView, imageWidth, resources);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = ImageManager.loadImage(imageURL,context);
                if(bitmap != null) {
                    final Drawable imageAsDrawable = ImageManager.invertImage(bitmap, invert, resources);
                    if(invert != null && invert.equals("true")) imageView.setTag("invert");

                    ImageManager.updateImageView(imageView, imageAsDrawable, activity, true);
                }
            }});
        t.start();
    }

    private void addButtonToChapter(String text, String sourceStringName,String buttonTheme, String openTestName, final String nextChapterCode, final String linkURI, final String emailAddress) {
        CardView currText;

        if(buttonTheme != null && buttonTheme.equals("light")) currText = (CardView) inflater.inflate(R.layout.button_light, parentView,false);
        else currText = (CardView) inflater.inflate(R.layout.button, parentView,false);

        CustomText buttonText = (CustomText) currText.getChildAt(0);

        if(buttonTheme == null || !buttonTheme.equals("light")) {
            int primaryColor = ThemeManager.getInstance().getPrimaryColor(context);
            currText.setCardBackgroundColor(primaryColor);
        }

        if(sourceStringName != null && text.equals("")) text = getTextFromStringName(sourceStringName);

        buttonText.setText(text);

        if(openTestName != null && !openTestName.equals("")) {
            currText.setTag(openTestName);
            currText.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ((BaseActivity)context).openTest(v, nextChapterCode);
                }
            });
        }
        else if(linkURI != null && !linkURI.equals("")) {
            currText.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ((BaseActivity)context).openWebsite(linkURI);
                }
            });
        }
        else if(emailAddress != null && !emailAddress.equals("")) {
            currText.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ((BaseActivity)context).sendEmailTo(emailAddress);
                }
            });
        }
        parentView.addView(currText);
    }

    private void addLineToChapter() {
        ImageView lineImageView = (ImageView) inflater.inflate(R.layout.line_image, parentView,false);

        DrawableManager drawableManager = DrawableManager.getInstance();
        if(drawableManager != null) lineImageView.setImageDrawable(drawableManager.getDashedLine());
        parentView.addView(lineImageView);
    }

    private String getTextFromStringName(String sourceStringName) {
        int textID = resources.getIdentifier(sourceStringName,"string",Globals.PACKAGE_NAME);
        if(textID != 0) return resources.getString(textID);
        else return "";
    }

    public boolean hidePremiumChapter(XmlPullParser xpp) {
        String premium = xpp.getAttributeValue(null, "premium");
        return premium != null && premium.equals("true") && Globals.sharedPreferences.getInt("contributed",0) == 0;
    }
}