const fbConfig = require('./firebase_config.js');


//Firebase configuration
exports.configApp = fbConfig.config;
