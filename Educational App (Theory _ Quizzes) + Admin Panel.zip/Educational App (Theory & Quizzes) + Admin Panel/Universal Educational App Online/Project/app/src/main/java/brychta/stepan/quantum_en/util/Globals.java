package brychta.stepan.quantum_en.util;

import android.app.Application;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.text.LineBreaker;
import android.os.Build;
import android.view.Gravity;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

import static android.graphics.text.LineBreaker.JUSTIFICATION_MODE_INTER_WORD;

public class Globals extends Application{
    public static int currQuestionNumber;
    public static int currTestPoints;
    public static int currTestNum;
    public static boolean fromBookmark = false;
    public static boolean testFromChapter = false;

    public static String nextChapterCode;
    public static boolean changeLanguage;
    public static int textAlignment;
    public static int fontThickness;
    public static int colorTheme;

    public static String PACKAGE_NAME;

    public static Typeface thinLato;
    public static Typeface regularLato;
    public static Typeface boldLato;
    public static Typeface thinLatoI;
    public static Typeface regularLatoI;
    public static Typeface boldLatoI;
    public static SharedPreferences sharedPreferences;
    public static SharedPreferences.Editor sharedPreferencesEditor;

    public static int languageCode;
    public static String language;

    public static HashMap<String,String[]> chapterData;
    public static List<String> chapterOrder;

    public static boolean justLaunched = true;

    public static void changeTypefaceOfTextItalics (TextView text) {
        Typeface typeface = thinLatoI;
        if (fontThickness == 1) typeface =  regularLatoI;
        else if (fontThickness == 2) typeface =  boldLatoI;

        text.setTypeface(typeface);
    }

    public static void changeAlignmentOfText(CustomText text) {
        int alignment = Gravity.START;
        if (textAlignment == 2) alignment = Gravity.END;

        if (Build.VERSION.SDK_INT >= 26) {
            if(textAlignment == 0) text.setJustificationMode(JUSTIFICATION_MODE_INTER_WORD);
            else text.setJustificationMode(LineBreaker.JUSTIFICATION_MODE_NONE);
        }

        text.setGravity(alignment);
        text.setTextAlignment(alignment);
    }

    public static void changeTypefaceOfText (TextView text) {
        Typeface typeface = thinLato;
        if (fontThickness == 1) typeface =  regularLato;
        else if (fontThickness == 2) typeface =  boldLato;

        text.setTypeface(typeface);
    }

    public static void changeTypefaceOfText(CustomText text) {
        Typeface typeface = thinLato;
        if (fontThickness == 1) typeface =  regularLato;
        else if (fontThickness == 2) typeface =  boldLato;

        text.setTypeface(typeface);
    }
}