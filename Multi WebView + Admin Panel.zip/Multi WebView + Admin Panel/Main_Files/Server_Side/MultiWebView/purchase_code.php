<?php
$purchase_code = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"; //Insert your purchase code from Envato
//Where is my purchase code? https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code