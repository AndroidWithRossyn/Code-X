<?php
require 'include/dbconfig.php';
echo $fetch_main['data'];
?>