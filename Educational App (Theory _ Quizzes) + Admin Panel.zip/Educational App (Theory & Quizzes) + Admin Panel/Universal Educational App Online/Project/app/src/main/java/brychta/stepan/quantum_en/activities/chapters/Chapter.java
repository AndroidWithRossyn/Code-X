package brychta.stepan.quantum_en.activities.chapters;

import android.animation.Animator;
import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.transition.TransitionInflater;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.github.ksoichiro.android.observablescrollview.ObservableScrollView;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollViewCallbacks;
import com.github.ksoichiro.android.observablescrollview.ScrollState;
import com.github.ksoichiro.android.observablescrollview.ScrollUtils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.nineoldandroids.view.ViewHelper;

import brychta.stepan.quantum_en.util.DrawableManager;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ImageManager;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.BaseActivity;

public class Chapter extends BaseActivity implements ObservableScrollViewCallbacks, ActivitySwipeDetector.SwipeInterface {
    private RelativeLayout introView;
    private Toolbar toolbar;
    private ObservableScrollView scrollView;
    private int introImageHeight;
    private TextView chapterTop;
    private FloatingActionButton fab;
    private String chapterNumber;
    private ImageView headerImage;
    private LinearLayout imgBg;

    private String nextChapterNumber = null;
    private String prevChapterNumber = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setSharedElementEnterTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared));

        chapterNumber = getIntent().getStringExtra("chapter");
        setPrevAndNextChapterNumbers();

        setTheme(ThemeManager.getInstance().getChapterTheme(chapterNumber));
        DrawableManager.getInstance(this).setColorOfDrawables(ThemeManager.getInstance().getPrimaryColor(this));

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chapter);

        toolbar = findViewById(R.id.toolbar);
        chapterTop = findViewById(R.id.chapterTop);
        headerImage = findViewById(R.id.headerImage);
        imgBg = findViewById(R.id.imgbg);
        fab = findViewById(R.id.fab);
        introView = findViewById(R.id.introView);
        LinearLayout body = findViewById(R.id.body);

        // Get width and height of screen
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int width = displaymetrics.widthPixels;
        int height = displaymetrics.heightPixels;

        introView.setLayoutParams(new RelativeLayout.LayoutParams((width), (height / 2)));
        findViewById(R.id.anchor).setLayoutParams(new RelativeLayout.LayoutParams((width), (height / 2)));

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));

        setColorsAccordingToTheme();

        chapterTop.setText(getResources().getString(R.string.chapter) + " " + chapterNumber.replace("_","."));

        setIconOfChapter();

        scrollView = findViewById(R.id.scroll);
        scrollView.setScrollViewCallbacks(this);

        introImageHeight = height * 40 / 100;
        
        if(Globals.colorTheme == 1) {
            findViewById(R.id.root).setBackgroundColor(getResources().getColor(R.color.white));
            body.setBackgroundColor(getResources().getColor(R.color.white));
        }

        fillWithContentFromXML(body, chapterNumber, nextChapterNumber);

        setUpBookmarkButton();

        setUpPrevAndNextChapterButtons();
        
        if(Globals.fromBookmark) scrollToBookmarkedPosition();

        body.setOnTouchListener(new ActivitySwipeDetector(this, this));
        for (int index = 0; index < body.getChildCount(); ++index) {
            View nextChild = body.getChildAt(index);
            if(!(nextChild instanceof CardView)) nextChild.setOnTouchListener(new ActivitySwipeDetector(this, this));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.chapter_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        if (hasFocus) {
            int centerX = (imgBg.getLeft() + imgBg.getRight()) / 2;
            int centerY = (imgBg.getTop() + imgBg.getBottom()) / 2;

            int startRadius = 0;
            int endRadius = Math.max(imgBg.getWidth(), imgBg.getHeight());

            Animator anim = ViewAnimationUtils.createCircularReveal(imgBg, centerX, centerY, startRadius, endRadius);
            imgBg.setVisibility(View.VISIBLE);
            anim.setDuration(800);
            anim.start();
        }
    }

    @Override
    public void onScrollChanged(int scrollY, boolean firstScroll, boolean dragging) {
        int white = getResources().getColor(R.color.white);
        float alpha = Math.min(1, (float) scrollY / introImageHeight);

        toolbar.setBackgroundColor(ScrollUtils.getColorWithAlpha(alpha, ThemeManager.getInstance().getPrimaryColor(this)));
        ViewHelper.setTranslationY(introView, scrollY / 2);

        chapterTop.setTextColor(ScrollUtils.getColorWithAlpha(alpha, white));
        if (scrollY < introImageHeight + 10) {
            headerImage.setAlpha(ScrollUtils.getFloat(1 - alpha, 1 - alpha, 1 - alpha));
        }
        else {
            headerImage.setAlpha(ScrollUtils.getFloat(0, 0, 0));
        }
    }

    @Override
    public void onDownMotionEvent() {
        fab.hide();
    }

    @Override
    public void onUpOrCancelMotionEvent(ScrollState scrollState) {
        if (scrollState == ScrollState.DOWN) fab.show();
        if (scrollState == ScrollState.UP) fab.hide();
    }

    @Override
    public void onLeftToRight(View v) {
        openPrevChapter();
    }

    @Override
    public void onRightToLeft(View v) {
        openNextChapter();
    }

    private void setPrevAndNextChapterNumbers() {
        int positionOfCurrChapter = Globals.chapterOrder.indexOf(chapterNumber);

        if(positionOfCurrChapter < Globals.chapterOrder.size() - 1) nextChapterNumber = Globals.chapterOrder.get(positionOfCurrChapter + 1);
        if(positionOfCurrChapter > 0) prevChapterNumber = Globals.chapterOrder.get(positionOfCurrChapter - 1);
    }

    private void openNextChapter() {
        if(nextChapterNumber != null) {
            finish();
            Intent intent = new Intent(getApplicationContext(), Chapter.class);
            intent.putExtra("chapter",nextChapterNumber);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_left);
        }
        else {
            Intent intent = new Intent(getApplicationContext(), About.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_left);
            finish();
        }
    }

    private void openPrevChapter() {
        if(prevChapterNumber != null) {
            finish();
            Intent intent = new Intent(getApplicationContext(), Chapter.class);
            intent.putExtra("chapter",prevChapterNumber);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_from_left, R.anim.slide_out_right);
        }
    }

    private void setColorsAccordingToTheme() {
        int primaryColor = ThemeManager.getInstance().getPrimaryColor(this);
        int primaryColorDark = ThemeManager.getInstance().getPrimaryColorDark(this);

        imgBg.setBackgroundColor(primaryColor);
        toolbar.setBackgroundColor(ScrollUtils.getColorWithAlpha(0, primaryColorDark));
        chapterTop.setTextColor(ScrollUtils.getColorWithAlpha(0, primaryColorDark));
        fab.setBackgroundTintList(ColorStateList.valueOf(primaryColorDark));
    }

    private void setUpBookmarkButton() {
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar sb = Snackbar.make(findViewById(R.id.fab), R.string.chapterbookmarked, Snackbar.LENGTH_LONG)
                        .setAction("OK", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                            }
                        });

                TextView tv = sb.getView().findViewById(R.id.snackbar_text);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(22);
                tv.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/Raleway-Light.ttf"));
                sb.show();
                Globals.sharedPreferencesEditor.putBoolean("bookmarkTrue", true);
                Globals.sharedPreferencesEditor.putInt("ScrollPosition", scrollView.getScrollY());
                Globals.sharedPreferencesEditor.putString("ChapterName", chapterNumber);
                Globals.sharedPreferencesEditor.commit();
            }
        });
    }

    private void scrollToBookmarkedPosition() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                scrollView.smoothScrollTo(0, Globals.sharedPreferences.getInt("ScrollPosition", 0));
                Globals.fromBookmark = false;
            }
        }, 1000);
    }

    private void setUpPrevAndNextChapterButtons() {
        // Add previous chapter arrow if this is not the first chapter
        if(prevChapterNumber != null) toolbar.setNavigationIcon(R.drawable.prevbutton);

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.next) openNextChapter();
                return false;
            }
        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPrevChapter();
            }
        });
    }

    private void setIconOfChapter() {
        final String[] chapterData = Globals.chapterData.get(chapterNumber);
        if(chapterData == null || chapterData[2] == null)  return;

        headerImage.setImageResource(R.drawable.testnone);

        final Activity activity = this;
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = ImageManager.loadImage(chapterData[2], getBaseContext());
                ImageManager.updateImageViewFromBitmap(headerImage, bitmap, activity, getResources(), false);
            }
        });
        thread.start();
    }
}

