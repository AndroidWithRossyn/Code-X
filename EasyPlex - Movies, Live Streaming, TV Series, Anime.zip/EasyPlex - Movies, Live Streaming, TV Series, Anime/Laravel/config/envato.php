<?php

return [
    'client_id' => '',

    'client_secret' => '',

    'redirect_uri' => '',

    'use_personal_token' => true,

    'personal_token' => 'GxoNdPhOrskWYZfSw2d9hgeXToSlUBal',

    /*
     * you can set any name for this purpose.
     * */
    'app_name' => 'easyplex',
];
