
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <main class="main">
      <div class="view-container-3">
      <div class="collection-section--1__DHQagG0">
          <button class="item--3ZMpOg-5QU" disabled="">Change password</button>
      </div>
      <br>
      <form method="POST" action="<?php echo e(route('change-password')); ?>" class="form--1pNyeHZ_J6" id="change-password-form">
         <fieldset>
            <?php echo csrf_field(); ?>
            <div class="field">
                <label class="section-label" for="app-name-input">Old Password *</label>
                <label class="input left--3McDXiCrys headline"><input type="password" value="" name="old-password" required></label>
            </div>
            <?php $__errorArgs = ['old-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <br>

            <div class="field">
                <label class="section-label" for="app-name-input">New Password *</label>
                <label class="input left--3McDXiCrys headline"><input type="password" value="" name="new-password" required></label>
            </div>
            <br>
            <br>

            <div class="field">
                <label class="section-label" for="app-name-input">Confirm New Password *</label>
                <label class="input left--3McDXiCrys headline"><input type="password" value="" name="new-password_confirmation" required></label>
            </div>
            <br>
            <?php $__errorArgs = ['new-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <br>
            <br>
            <button class="button--319u6U1AIl primary--1wekDI7P-q" type="submit" style="margin-top: 0"><span class="text--3HNWf-tIc7">Change Password</span></button>
         </fieldset>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vomad\quantum-admin\Quantum-Admin\resources\views/options.blade.php ENDPATH**/ ?>