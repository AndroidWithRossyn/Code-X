package brychta.stepan.quantum_en.activities.tests;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import brychta.stepan.quantum_en.activities.chapters.ContentParser;
import brychta.stepan.quantum_en.activities.tests.util.Option;
import brychta.stepan.quantum_en.activities.tests.util.Question;
import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.util.DrawableManager;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ImageManager;
import brychta.stepan.quantum_en.util.ThemeManager;

public class Test extends AppCompatActivity {
    private long lastPressTime = 0;
    private LinearLayout body;
    private View root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTheme(ThemeManager.getInstance().getTestTheme(String.valueOf(Globals.currTestNum)));

        setContentView(R.layout.activity_testquestion);

        if(Globals.currQuestionNumber == 1) {
            try { Question.setQuestions(getQuestions()); }
            catch(Exception e) { Log.e("Failed to add questions", String.valueOf(e)); }
        }

        int colorDarkID = ThemeManager.getInstance().getPrimaryColorDark(this);
        int colorID = ThemeManager.getInstance().getPrimaryColor(this);

        DrawableManager.getInstance(this).setColorOfDrawables(colorDarkID);
        DrawableManager.getInstance(this).setColorOfBackground(DrawableManager.getInstance(this).getCircleBackground(),colorID);

        body = findViewById(R.id.body);
        root = findViewById(R.id.root);

        TextView questionNumber = findViewById(R.id.number1);
        questionNumber.setBackground(DrawableManager.getInstance(this).getRoundedSquareBackground());
        questionNumber.setText(String.valueOf(Globals.currQuestionNumber));

        addTextToQuestion();
    }

    private void addTextToQuestion() {
        CustomText question = findViewById(R.id.question);
        Globals.changeTypefaceOfText(question);

        if(Question.getQuestions().size() == 0) {
            question.setText("No questions found in this quiz.");
            return;
        }

        Random random = new Random();
        LayoutInflater inflater = getLayoutInflater();

        Question currQuestion = Question.getQuestions().get(Globals.currQuestionNumber -1);

        if(currQuestion.getTestImageURL() != null) addImageToQuestion(currQuestion);

        ContentParser.loadTextFromHTML(question, currQuestion.getQuestion());

        for (Map.Entry<String, Option> stringOptionEntry : currQuestion.getOptions().entrySet()) {
            String optionText = (String) ((Map.Entry) stringOptionEntry).getKey();
            Option optionCorrect = (Option) ((Map.Entry) stringOptionEntry).getValue();

            CardView currOption = (CardView) inflater.inflate(R.layout.testoption, body, false);

            currOption.setTag(optionCorrect);

            TextView currText = (TextView) currOption.getChildAt(0);
            ContentParser.loadTextFromHTML(currText, optionText);

            Globals.changeTypefaceOfText(currText);

            // Randomize order of options
            if (body.getChildCount() == 1) body.addView(currOption, 1);
            else body.addView(currOption, random.nextInt(body.getChildCount()) + 1);

            if (Globals.colorTheme == 1) {
                currOption.setCardBackgroundColor(getResources().getColor(R.color.light));
                currText.setTextColor(getResources().getColor(R.color.dark));
            }
        }

        if(Globals.colorTheme == 1) {
            root.setBackgroundColor(getResources().getColor(R.color.white));
            question.setTextColor(getResources().getColor(R.color.dark));
        }
    }

    private void addImageToQuestion(final Question question) {
        LinearLayout imageContainer = findViewById(R.id.imageContainer);
        final ImageView questionImage = (ImageView) getLayoutInflater().inflate(R.layout.chapter_image,imageContainer, false);

        // Set default image
        questionImage.setImageResource(R.drawable.placeholder);
        imageContainer.addView(questionImage, 0);
        ImageManager.setWidthOfImage(questionImage, question.getImageWidth(), getResources());

        final Activity activity = this;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = ImageManager.loadImage(question.getTestImageURL(),getBaseContext());
                if(bitmap != null) {
                    final Drawable imageAsDrawable = ImageManager.invertImage(bitmap, question.getInvertImage(), getResources());

                    ImageManager.updateImageView(questionImage, imageAsDrawable, activity, true);
                }
            }});
        t.start();
    }

    public void answerClick (View view) {
        if (SystemClock.elapsedRealtime() - lastPressTime < 500) return;
        lastPressTime = SystemClock.elapsedRealtime();
        Intent intent;
        if(view.getTag() == Option.CORRECT) {
            intent = new Intent(this, TestAnswer.class);
            intent.putExtra("correct",true);
        }
        else {
            intent = new Intent(this, TestAnswer.class);
        }
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.noanim, R.anim.slide_out);
    }

    private List<Question> getQuestions() throws XmlPullParserException, IOException {
        List<Question> questions = new ArrayList<>();

        File xmlQuizzes = FileManager.getInstance().getXMLQuizzes();

        if(xmlQuizzes == null || xmlQuizzes.length() == 0) return questions;

        XmlPullParser xpp = XmlPullParserFactory.newInstance().newPullParser();
        xpp.setInput(new FileInputStream(xmlQuizzes), null);

        ContentParser parser = new ContentParser(getResources(), getBaseContext(),null,null);

        int quizCounter = 0;

        Question currQuestion = null;

        boolean parsingContentsOfActiveQuiz = false;

        while ((xpp.getEventType() != XmlPullParser.END_DOCUMENT) && quizCounter <= Globals.currTestNum) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                if (xpp.getName().equals("quiz")) {
                    if(parser.hidePremiumChapter(xpp)) {
                        xpp.next();
                        continue;
                    }
                    quizCounter += 1;
                }
                else if(parsingContentsOfActiveQuiz) {
                    if (xpp.getName().equals("question-body")) {
                        // Create a new Question
                        questions.add(new Question());
                        currQuestion = questions.get(questions.size() -1);
                    }
                    else if(xpp.getName().equals("question")) {
                        currQuestion.setQuestion(getTextFromTag(xpp));
                    }
                    else if (xpp.getName().equals("img") || xpp.getName().equals("image")) {
                        currQuestion.addImage(xpp.getAttributeValue(null, "src"), xpp.getAttributeValue(null, "width"), xpp.getAttributeValue(null, "invert"), getResources());
                    }
                    else if(xpp.getName().equals("answer")) {
                        currQuestion.setAnswer(getTextFromTag(xpp));
                    }
                    else if(xpp.getName().equals("option")) {
                        String correct = xpp.getAttributeValue(null, "correct");
                        Option isCorrect = Option.WRONG;

                        if(correct != null && correct.equals("true")) isCorrect = Option.CORRECT;
                        currQuestion.addOption(getTextFromTag(xpp),isCorrect);
                    }
                }
                else if (xpp.getName().equals("questions") && quizCounter == Globals.currTestNum) {
                    parsingContentsOfActiveQuiz = true;

                    String shuffleQuestions = xpp.getAttributeValue(null, "shuffle");
                    Question.shuffleQuestions = (shuffleQuestions != null && shuffleQuestions.equals("true"));
                }
            }
            xpp.next();
        }
        return questions;
    }

    private String getTextFromTag(XmlPullParser xpp) throws IOException, XmlPullParserException {
        String sourceStringName = xpp.getAttributeValue(null, "fromString");

        String textInsideTag = xpp.nextText();

        int textID = 0;
        String text;

        if(sourceStringName != null && textInsideTag.equals("")) textID = getResources().getIdentifier(sourceStringName,"string",getPackageName());

        if(textID != 0) text = getString(textID);
        else text = textInsideTag;

        return text;
    }
}
