package com.devlomi.fireapp.model.constants;

public class PendingGroupTypes {
    public static final int CREATION_EVENT = 1;
    public static final int CHANGE_EVENT = 2;
}
