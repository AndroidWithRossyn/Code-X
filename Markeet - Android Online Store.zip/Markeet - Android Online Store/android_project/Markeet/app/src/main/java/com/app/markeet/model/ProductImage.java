package com.app.markeet.model;

import java.io.Serializable;

public class ProductImage implements Serializable {

    public Long product_id;
    public String name;

}
