<?php $__env->startSection('mediapicker'); ?>
  <!-- ICON MODAL -->
  <div id="icon-modal" style="display:none;">
     <div class="backdrop--1NPZgaTLwy visible--2Ns3EfQy8A fixed--2GqQpeyTUu" role="button"></div>
     <div class="dialog-container open--1ztEKgXgPI" >
        <div class="dialog--RUeFRUqJ7i"
           style="width:70vw;
           min-width: 600px;
           height: 90vh;
           overflow: auto;
           white-space: nowrap;">
           <section class="content--1lT7Ozsit1" style="padding: 20px 30px;">
              <div style="display: flex;
                 flex-direction: column;
                 flex-grow: 1;">
                 <div tabindex="0" class="dropzone--KZJx-aaeEy">
                    <div>
                       <div class="collection-section--1__DHQagG0" style="border-bottom: 1px solid #ccc; margin-bottom: 15px">
                          <div class="left--3pbjiZ6m4G">
                             <ul class="breadcrumb--3AnAv6bJcz">
                                <li><button class="item--3ZMpOg-5QU" disabled="">All media</button></li>
                             </ul>
                          </div>
                          <div class="right--2KDxSCdQMZ">
                             <span aria-label="fas fa-times" class="fas fa-times clickable--2-TzL1jn1k icon--3x5ECMVMng" role="button" tabindex="0"></span>
                          </div>
                       </div>
                    </div>
                    <div>
                       <div class="chapter-list-container">
                          <!-- TOOLBAR -->
                          <div class="media-toolbar">
                             <div class="button-group--3ZXJDYPX-3">
                                <button id="image-view-button" class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" type="button">
                                <span class="text--3HNWf-tIc7"><i class="fas fa-th-large"></i></span></span>
                                </button>
                                <button id="list-view-button" class="button--319u6U1AIl icon--2SWnwI7jSC active--2PPd5kFWvV button--30g09RbEvQ" type="button">
                                <span class="text--3HNWf-tIc7"><i class="fas fa-bars"></i></span>
                                </button>
                             </div>
                          </div>
                          <div id="media-list-view" class="list--24qxBVT_IF">
                             <section>
                                <div class="dark--3w5GzWBb9F">
                                   <table class="table--3OVMF8dOBt">
                                      <thead class="header--18fHWvcEtu">
                                         <tr>
                                            <th class="header-cell"><span>Thumbnail</span></th>
                                            <th class="header-cell "><span>Name</span></th>
                                            <th class="header-cell "><span></span></th>
                                            <th class="header-cell "><span>Filesize</span></th>
                                            <th class="header-cell "><span></span></th>
                                            <th class="header-cell "><span></span></th>
                                         </tr>
                                      </thead>
                                      <tbody id="media-table-body">
                                         <!-- LOOP IMAGES IN LIST VIEW -->
                                         <?php if (! (empty($thumbnails))): ?>
                                         <?php $__currentLoopData = $thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr class="row--16jZlysVSE media-listView" style="cursor:pointer">
                                            <td class="cell--3QhdjYDo1X">
                                               <div class="cell-content"><img class="media-thumbnail" src="<?php echo e(url('/thumbnail-uploader/'.$image[0].'')); ?>" /></div>
                                            </td>
                                            <td class="cell--3QhdjYDo1X">
                                               <div class="cell-content image-name" ><?php echo e($image[0]); ?></div>
                                            </td>
                                            <td class="cell--3QhdjYDo1X">
                                               <div class="cell-content"></div>
                                            </td>
                                            <td class="cell--3QhdjYDo1X">
                                               <div class="cell-content"><?php echo e($image[1]); ?></div>
                                            </td>
                                            <td class="cell--3QhdjYDo1X">
                                               <div class="cell-content"></div>
                                            </td>
                                            <td class="cell--3QhdjYDo1X">
                                               <div class="cell-content"></div>
                                            </td>
                                         </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                      </tbody>
                                   </table>
                                </div>
                                <nav class="pagination--1eeM3Kvldi">
                                   <span class="display--2vbfghRVvn">Items per page:</span>
                                   <span>
                                      <select class="itemsPerPage-select">
                                         <option value="10">10</option>
                                         <option value="20">20</option>
                                         <option value="50">50</option>
                                      </select>
                                   </span>
                                   <div class="loader--d5Z5tZSNVf"></div>
                                   <div class="button-group--3ZXJDYPX-3">
                                      <button id="backward-button" class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" disabled="" type="button"><i class="fas fa-angle-left button-icon--2zwDFL5-yo"></i></button>
                                      <button id="forward-button" class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" type="button"><i class="fas fa-angle-right button-icon--2zwDFL5-yo"></i></button>
                                   </div>
                                </nav>
                             </section>
                          </div>
                          <!-- LOOP IMAGE IN IMAGE VIEW -->
                          <div id="media-image-view" class="list--24qxBVT_IF">
                             <div class="item--3RIViIi05o grid-item colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL" style="display: flex; flex-wrap: wrap;">
                                <table class="table--3OVMF8dOBt">
                                <tbody>
                                   <?php if (! (empty($thumbnails))): ?>
                                   <?php $__currentLoopData = $thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div class="iconModal-imageView">
                                      <div class="media-card--3zwVt4x9IY">
                                         <div class="media-image-view-header">
                                            <div class="description--KIscyejKfD" role="button">
                                               <div class="title--2BoVb9Cwl9">
                                                  <div>
                                                     <div class="title-text--1DQCap-AbL">
                                                        <div aria-label="roadtrip.jpg" class="cropped-text--kjpmxHAsTL" title="roadtrip.jpg">
                                                           <div aria-hidden="true" class="front--3wwBW91aMg image-name" ><?php echo e($image[0]); ?></div>
                                                        </div>
                                                     </div>
                                                  </div>
                                                  </label>
                                               </div>
                                               <div class="meta--Lq76ippoF_">
                                                  <div aria-label="image/jpeg 76.09 KB" class="cropped-text--kjpmxHAsTL" title="image/jpeg 76.09 KB">
                                                     <div aria-hidden="true" class="back--2lOqwyu_8t"><span><?php echo e($image[1]); ?></span></div>
                                                  </div>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="media--1-OiFQVLjc" role="button">
                                            <img src="<?php echo e(url('/thumbnail-uploader/'.$image[0].'')); ?>" />
                                         </div>
                                      </div>
                                   </div>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php endif; ?>
                             </div>
                          </div>
                       </div>
                    </div>
           </section>
           </div>
           </div>
        </div>
     </div>
  </div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\vomad\quantum-admin\Quantum-Admin\resources\views/mediapicker.blade.php ENDPATH**/ ?>