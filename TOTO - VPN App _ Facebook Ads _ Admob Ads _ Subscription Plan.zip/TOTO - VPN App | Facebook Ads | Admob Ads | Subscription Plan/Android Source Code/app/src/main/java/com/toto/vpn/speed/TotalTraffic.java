package com.toto.vpn.speed;

/**
 * Created by Deokumar on 2020.
 */

public class TotalTraffic {

    public static final String TRAFFIC_ACTION = "traffic_action";
    public static final String TIMER_ACTION = "timer_action";

    public static final String DOWNLOAD_ALL = "download_all";
    public static final String DOWNLOAD_SESSION = "download_session";
    public static final String UPLOAD_ALL = "upload_all";
    public static final String UPLOAD_SESSION = "upload_session";
    public static final String TOTAL = "upload_session";

    public static final String UPDATEDTIME_SESSION = "updatedtime_session";

    public static long inTotal;
    public static long outTotal;

}
