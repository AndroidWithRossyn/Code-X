package brychta.stepan.quantum_en.util;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.ImageView;


public class ImageManager {
    public static Bitmap loadImage(String imageURL, Context context) {
        String fileName = imageURL.substring(imageURL.lastIndexOf('/') + 1);

        return FileManager.getInstance().getBitmap(imageURL, fileName, context);
    }

    public static void updateImageView(final ImageView imageView, final Drawable image, Activity activity, final boolean animate) {
        if(activity == null) return;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                imageView.setImageDrawable(image);
                if(animate) Animator.fadeIn(imageView,200);
            }
        });
    }

    public static void updateImageViewFromBitmap(final ImageView imageView, final Bitmap bitmap, Activity activity, Resources resources, boolean animate) {
        if(ImageManager.isBitmapEmpty(bitmap)) return;
        final Drawable image = new BitmapDrawable(resources, bitmap);

        updateImageView(imageView, image, activity, animate);
    }

    public static Drawable invertImage(Bitmap bitmap, String invert, Resources resources) {
        // Invert colors of image
        if(Globals.colorTheme == 1 && invert != null && invert.equals("true")) {
            bitmap = bitmap.copy(Bitmap.Config.ARGB_8888 , true);
            Drawable newDrawable = new BitmapDrawable(resources, invertColorOfImage(bitmap));
            return newDrawable;
        }
        return new BitmapDrawable(resources, bitmap);
    }

    public static void setWidthOfImage(ImageView imageView, String imageWidth,Resources resources) {
        if(imageWidth != null && TextUtils.isDigitsOnly(imageWidth)) {
            int imgWidthInPixels = Integer.parseInt(imageWidth);
            float widthInPixels = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, imgWidthInPixels, resources.getDisplayMetrics());
            imageView.getLayoutParams().width = (int)widthInPixels;
        }
    }

    public static Bitmap invertColorOfImage(Bitmap image) {
        image = image.copy(Bitmap.Config.ARGB_8888 , true);

        int length = image.getWidth()*image.getHeight();
        int[] array = new int[length];
        image.getPixels(array,0,image.getWidth(),0,0,image.getWidth(),image.getHeight());
        for (int k=0;k<length;k++){
            array[k] = (0xffffff - (array[k] & 0x00ffffff)) + (array[k] & 0xff000000);
        }
        image.setPixels(array,0,image.getWidth(),0,0,image.getWidth(),image.getHeight());
        return image;
    }

    public static boolean isBitmapEmpty(Bitmap bitmap) {
        if(bitmap == null) return true;

        Bitmap emptyBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        return bitmap.sameAs(emptyBitmap);
    }
}
