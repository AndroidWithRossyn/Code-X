package com.devlomi.fireapp.adapters.messaging.holders.base

import android.content.Context
import android.view.View

 class ReceivedDeletedMessageHolder(context: Context, itemView: View) : BaseReceivedHolder(context,itemView)