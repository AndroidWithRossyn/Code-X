package com.cjt2325.cameralibrary.listener;

/**
 * =====================================
 * 作    者: 陈嘉桐
 * 版    本：1.1.4
 * 创建日期：2017/9/8
 * 描    述：
 * =====================================
 */
public interface ResultListener {
    void callback();
}
