package brychta.stepan.quantum_en.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

import brychta.stepan.quantum_en.R;

import static java.lang.Thread.sleep;

public class FileManager {
    public enum FileType {
        CHAPTERS,
        QUIZZES,
        OPTIONS,
        ABOUT
    }

    public class FileChangedPair {
        public File file;
        public boolean changed;

        public FileChangedPair(File file, boolean changed) {
            this.file = file;
            this.changed = changed;
        }
    }

    private static FileManager INSTANCE = null;
    private static File xmlChapters = null;
    private static File xmlQuizzes = null;
    private static File xmlOptions = null;

    public FileManager() {
        INSTANCE = this;
    }

    public static FileManager getInstance() {
        if(INSTANCE == null) INSTANCE = new FileManager();
        return(INSTANCE);
    }

    private String[] getFileNamesFromType(FileType fileType) {
        if(fileType == FileType.CHAPTERS) return new String[] {"chapters.xml","chapterstimestamp.txt"};
        if(fileType == FileType.QUIZZES) return new String[] {"quizzes.xml","quizzestimestamp.txt"};
        if(fileType == FileType.ABOUT) return new String[] {"about.xml","abouttimestamp.txt"};
        return new String[] {"options.xml","optionstimestamp.txt"};
    }

    @NonNull
    public FileChangedPair loadXMLFile(String hostName, FileType fileType, Context context) {
        String[] fileNames = getFileNamesFromType(fileType);
        String fileName = fileNames[0];
        String timeStampFileName = fileNames[1];

        if(hostName.substring(hostName.length() - 1).equals("/")) hostName = hostName.substring(0, hostName.length() - 1);

        String url = hostName + "/xml/" + fileName;
        String timeStampURL = hostName + "/xml/" + timeStampFileName;
        File xmlFile = null;

        boolean fileRefreshed = false;

        File previousTimeStampFile = getFileFromStorage(timeStampFileName, context);

        // Content files were not downloaded, need internet connection to proceed
        if(!previousTimeStampFile.exists()) {
            File timestampFile = createFileFromURL(timeStampURL, timeStampFileName, 1, context);

            if(timestampFile != null) xmlFile = createFileFromURL(url, fileName, 1, context);
            if(xmlFile != null) fileRefreshed = true;
        }
        else if(xmlFileUpdatedSinceLastRefresh(previousTimeStampFile, timeStampFileName, timeStampURL, context)) {
            xmlFile = createFileFromURL(url, fileName, 0, context);
            if(xmlFile != null) fileRefreshed = true;
            else xmlFile = getFileFromStorage(fileName, context);
        }
        else xmlFile = getFileFromStorage(fileName, context);

        // Failed to download file
        if(xmlFile == null || !xmlFile.exists()) {
            return new FileChangedPair(null, false);
        }

        if(fileType == FileType.CHAPTERS) xmlChapters = xmlFile;
        else if(fileType == FileType.QUIZZES) xmlQuizzes = xmlFile;
        else xmlOptions = xmlFile;

        return new FileChangedPair(xmlFile, fileRefreshed);
    }

    public File getFileFromStorage(String fileName, Context context) {
        String filePath = context.getFilesDir() + File.separator + fileName;
        return new File(filePath);
    }

    private File createFileFromURL(String url, String fileName, int numberOfConnectionAttempts, Context context) {
        try {

            int i = 0;
            while(!haveNetworkConnection(context) || !isServerReachable(url, 2000, context)) {
                if(i >= numberOfConnectionAttempts) return null;
                i+=1;
                Log.e("AAAA", "Attempting to download " + fileName);
                Thread.sleep(2000);
            }

            InputStream in = new URL(url).openStream();
            return createFileFromInputStream(in, fileName, context);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private boolean haveNetworkConnection(Context context) {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }

    private boolean isServerReachable(String url, int timeout, Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            try {
                HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(timeout);
                connection.connect();
                return connection.getResponseCode() == 200;
            }
            catch (Exception e) { e.printStackTrace(); }
        }
        return false;
    }

    private File createFileFromInputStream(InputStream inputStream, String fileName, Context context) {
        try {
            String filePath = context.getFilesDir() + File.separator + fileName;

            File f = new File(filePath);
            f.setWritable(true);
            OutputStream outputStream = new FileOutputStream(f);
            byte[] buffer = new byte[1024];
            int length;

            while((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer,0, length);
            }

            outputStream.close();
            inputStream.close();

            return f;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private Date getDateFromTimeStampFile(File timeStampFile) {
        Scanner myScanner = null;
        String timeStampText;
        try
        {
            myScanner = new Scanner(timeStampFile);
            timeStampText = myScanner.nextLine();
            return getDateFromString(timeStampText);
        }
        catch(Exception e) { e.printStackTrace(); }
        finally { if(myScanner != null) myScanner.close(); }

        return null;
    }

    private Date getDateFromString(String dateText) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.parse(dateText);
    }

    public boolean xmlFileUpdatedSinceLastRefresh(File timeStampFile, String timeStampFileName, String timeStampURL, Context context) {
        try {
            Date oldTimeStamp = getDateFromTimeStampFile(timeStampFile);

            timeStampFile = createFileFromURL(timeStampURL, timeStampFileName, 0, context);

            // Cannot reach server, load old content
            if(timeStampFile == null) return false;

            Date newTimeStamp = getDateFromTimeStampFile(timeStampFile);

            if(newTimeStamp.after(oldTimeStamp)) return true;
        }
        catch (Exception e) { e.printStackTrace(); }

        return false;
    }

    public Bitmap getBitmap(String url, String fileName, Context context) {
        Bitmap bitmap;

        String filePath = context.getFilesDir() + File.separator + fileName;

        File file = new File(filePath);
        if(file.exists()) {
            bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        else {
            bitmap = getBitmapFromURL(url);
            if (bitmap == null) return null;

            try (FileOutputStream out = new FileOutputStream(filePath)) {
                 bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return bitmap;
    }

    private Bitmap getBitmapFromURL(String src) {
        try {
            java.net.URL url = new java.net.URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public File getXMLChapters() {
        return xmlChapters;
    }

    public File getXMLQuizzes() {
        return xmlQuizzes;
    }

    public File getXMLOptions() {
        return xmlOptions;
    }

}
