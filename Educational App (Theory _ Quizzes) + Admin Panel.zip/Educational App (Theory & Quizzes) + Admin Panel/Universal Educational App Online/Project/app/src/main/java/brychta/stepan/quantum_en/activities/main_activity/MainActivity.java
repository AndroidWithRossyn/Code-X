package brychta.stepan.quantum_en.activities.main_activity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityOptionsCompat;
import androidx.viewpager.widget.ViewPager;

import android.transition.TransitionInflater;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;

import com.github.aakira.expandablelayout.ExpandableLayout;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.activities.chapters.About;
import brychta.stepan.quantum_en.activities.chapters.Chapter;
import brychta.stepan.quantum_en.activities.main_activity.fragments.FragmentOne;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.OptionsManager;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.main_activity.adapters.ViewPagerAdapter;
import brychta.stepan.quantum_en.activities.tests.Test;
import brychta.stepan.quantum_en.util.billing.IabHelper;
import brychta.stepan.quantum_en.util.billing.IabResult;
import brychta.stepan.quantum_en.util.billing.Inventory;
import brychta.stepan.quantum_en.util.billing.Purchase;

public class MainActivity extends AppCompatActivity {
    ViewPager mPager;
    TabLayout mTabs;
    Locale myLocale;
    private View root;
    private FloatingActionButton fab;

    SearchView search = null;

    ViewPagerAdapter viewPagerAdapter;
    private IabHelper billingHelper;

    // Replace by your AdMob application ID
    private final static String ADMOB_APPLICATION_ID = "ca-app-pub-3940256099942544~3347511713";

    // Replace by your interstitial ad unit ID
    private final static String AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";

    // Insert your app's public key from the Google Play Store to enable in-app purchases
    private final static String BASE64_PUBLIC_KEY =  "";

    // Replace by your Google Play managed products IDs
    static final String ITEM_BRONZE = "quantum.bronze";
    static final String ITEM_SILVER = "quantum.silver";
    static final String ITEM_GOLD = "quantum.gold";


    private static InterstitialAd mInterstitialAd;
    private static boolean showNextAd = true;
    private static boolean adsEnabledForUser;

    IabHelper.OnIabPurchaseFinishedListener mPurchaseFinishedListener = new IabHelper.OnIabPurchaseFinishedListener() {
        public void onIabPurchaseFinished(IabResult result, Purchase purchase) {
            if (!result.isFailure()) {
                if (purchase.getSku().equals(ITEM_GOLD)) secretFragment(3);
                else if (purchase.getSku().equals(ITEM_SILVER)) secretFragment(2);
                else if (purchase.getSku().equals(ITEM_BRONZE)) secretFragment(1);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Globals.thinLato = Typeface.createFromAsset(getAssets(), "fonts/Lato-Thin.ttf");
        Globals.regularLato = Typeface.createFromAsset(getAssets(), "fonts/Lato-Regular.ttf");
        Globals.boldLato = Typeface.createFromAsset(getAssets(), "fonts/Lato-Bold.ttf");
        Globals.thinLatoI = Typeface.createFromAsset(getAssets(), "fonts/Lato-ThinItalic.ttf");
        Globals.regularLatoI = Typeface.createFromAsset(getAssets(), "fonts/Lato-Italic.ttf");
        Globals.boldLatoI = Typeface.createFromAsset(getAssets(), "fonts/Lato-BoldItalic.ttf");

        Globals.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        Globals.sharedPreferencesEditor = Globals.sharedPreferences.edit();
        Globals.textAlignment = Globals.sharedPreferences.getInt("textAlignment", 0);
        Globals.fontThickness = Globals.sharedPreferences.getInt("fontThickness", 1);
        Globals.colorTheme = Globals.sharedPreferences.getInt("colorTheme", 0);
        Globals.languageCode = Globals.sharedPreferences.getInt("setLanguage", 0);

        Globals.PACKAGE_NAME = getApplicationContext().getPackageName();

        getWindow().setSharedElementExitTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared));
        setUpAds();
        setUpBillingHelper();
        setLanguage();

        setTheme(ThemeManager.getInstance().getThemeFromName(OptionsManager.getInstance(this).getMenuThemeName(),getResources()));

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        mPager = findViewById(R.id.pager);
        mTabs = findViewById(R.id.tabs);

        updateAppConfiguration();

        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), getResources(), getBaseContext());
        mPager.setAdapter(viewPagerAdapter);
        mTabs.setupWithViewPager(mPager);
        mPager.setOffscreenPageLimit(3);
        mTabs.setSelectedTabIndicatorColor(Color.WHITE);

        setUpAboutSectionFab();

        int fromContribution = (Globals.sharedPreferences.getInt("fromcontribution", 0));
        if (fromContribution == 1) {
            mPager.setCurrentItem(2);
            Globals.sharedPreferencesEditor.putInt("fromcontribution", 0);
            Globals.sharedPreferencesEditor.commit();
        }
    }

    private void setUpAboutSectionFab() {
        fab = findViewById(R.id.fab);

        fab.setBackgroundTintList(ColorStateList.valueOf((ThemeManager.getInstance().getPrimaryColor(this))));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, About.class));
                overridePendingTransition(R.anim.slide_in, R.anim.noanim);
                if(viewPagerAdapter.getFragmentOne() != null) viewPagerAdapter.getFragmentOne().cancelSearch(false);
                if(search != null) search.setIconified(true);
            }
        });

        File aboutSectionXML = FileManager.getInstance().getFileFromStorage("about.xml",this);
        if(aboutSectionXML == null || !aboutSectionXML.exists()) fab.setVisibility(View.GONE);
    }

    private void updateAppConfiguration() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                OptionsManager.getInstance(getBaseContext()).update();

                if(OptionsManager.getInstance(getBaseContext()).appRestartRequired()) {
                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in, R.anim.noanim);
                }
                setAndCustomizeToolbar();
            }
        });
    }


    private void setLanguage() {
        String firstTime = Globals.sharedPreferences.getString("firstTime", null);
        int languagePos = (Globals.sharedPreferences.getInt("setLanguage", 0));
        String[] languageCodesArray = getResources().getStringArray(R.array.language_codes);

        if (firstTime != null && languagePos < languageCodesArray.length) {
            String languageCode = languageCodesArray[languagePos];

            setLocale(languageCode);
            Globals.language = languageCode;
        }
        else {
            Globals.language = Locale.getDefault().getLanguage();

            List<String> languageCodes = Arrays.asList(getResources().getStringArray(R.array.language_codes));
            if(languageCodes.contains(Globals.language)) Globals.languageCode = languageCodes.indexOf(Globals.language);
        }
    }

    public void setLocale(String lang) {
        myLocale = new Locale(lang);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);
    }

    public void expandableChapter (View view) {
        if(FragmentOne.searching) return;
        
        String expandedChapterId = (String)view.getTag();
        ExpandableLayout chapterExpanded = root.findViewWithTag("chapterExpanded"+expandedChapterId);
        if(chapterExpanded != null) chapterExpanded.toggle();
    }

    public void simulateOpenChapter(View view) {
        ImageView image = (ImageView)((ViewGroup) view).getChildAt(0);
        image.performClick();
    }

    public void openChapter(View view) {
        if(adsEnabledForUser && mInterstitialAd.isLoaded() && showNextAd) {
            showAdBeforeChapter(view);
        }
        else openChapterFromAd(view);
    }

    private void showAdBeforeChapter(final View view) {
        mInterstitialAd.show();
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                openChapterFromAd(view);
            }

            @Override
            public void onAdClosed() {
                startCountDownBetweenAds();
                // Load new ad
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
                openChapterFromAd(view);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        MenuItem item = menu.findItem(R.id.action_search);

        if(viewPagerAdapter.getFragmentOne() == null) item.setVisible(false);
        else {
            // Select THEORY tab when search icon clicked
            item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    TabLayout tabLayout = findViewById(R.id.tabs);
                    TabLayout.Tab tab = tabLayout.getTabAt(0);
                    tab.select();
                    return false;
                }
            });

            // Set up search bar
            search = (SearchView) item.getActionView();
            search.setLayoutParams(new ActionBar.LayoutParams(Gravity.CENTER));
            search.setMaxWidth( Integer.MAX_VALUE );
            search.setOnQueryTextListener(new SearchView.OnQueryTextListener(){

                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    TabLayout tabLayout = findViewById(R.id.tabs);
                    TabLayout.Tab tab = tabLayout.getTabAt(0);
                    tab.select();
                    ((FragmentOne)viewPagerAdapter.getFragmentOne()).search(newText);
                    return false;
                }
            });
        }

        return super.onCreateOptionsMenu(menu);
    }

    private void showAd() {
        if(adsEnabledForUser && mInterstitialAd.isLoaded() && showNextAd) {
            mInterstitialAd.show();
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    startCountDownBetweenAds();
                    // Load new ad
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }
            });
        }
    }

    public void openChapterFromAd(View view) {
        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(this, view, view.getTransitionName());
        Intent intent = new Intent(this, Chapter.class);
        intent.putExtra("chapter",(String) view.getTag());
        startActivity(intent, optionsCompat.toBundle());
    }

    public void openTest (View view)  {
        Globals.currQuestionNumber = 1;
        Globals.currTestPoints = 0;
        Globals.testFromChapter = false;
        Globals.currTestNum = Integer.parseInt((String)view.getTag());

        Intent intent = new Intent(this, Test.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in, R.anim.noanim);
    }

    public void bookmark(View view) {
        if (Globals.sharedPreferences.getString("ChapterName", null) != null) {
                Globals.fromBookmark = true;
                Intent intent = new Intent(this, Chapter.class);
                intent.putExtra("chapter",Globals.sharedPreferences.getString("ChapterName",null));
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in, R.anim.noanim);
        }
    }

    public void bronzeClick(View view) {
        try {
            billingHelper.launchPurchaseFlow(this, ITEM_BRONZE, 1, mPurchaseFinishedListener, "token");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void silverClick(View view) {
        try {
            billingHelper.launchPurchaseFlow(this, ITEM_SILVER, 2, mPurchaseFinishedListener, "token");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goldClick(View view) {
        try {
            billingHelper.launchPurchaseFlow(this, ITEM_GOLD, 3, mPurchaseFinishedListener, "token");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (!billingHelper.handleActivityResult(requestCode,
                resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void secretFragment(int itemCode) {
        Globals.sharedPreferencesEditor.putInt("contributed", itemCode);
        Intent intent = getIntent();
        finish();
        startActivity(intent);
        Globals.sharedPreferencesEditor.putInt("fromcontribution", itemCode);
        Globals.sharedPreferencesEditor.commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (billingHelper != null) {
            try{
                billingHelper.dispose();
            }
            catch (Exception e) { Log.e("Error","Failed to dispose of billingHelper.");
            }
        }
        billingHelper = null;
    }

    public void fragmentContentUpdated(){
        this.onResume();
    }

    @Override
    protected void onResume() {
        super.onResume();

        showAd();

        if (Globals.changeLanguage) {
            Intent intent = getIntent();
            finish();
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in, R.anim.noanim);
            Globals.changeLanguage = false;
        }
        if(Globals.colorTheme == 1) {
            mPager.setBackgroundColor(getResources().getColor(R.color.white));
        }
        else {
            mPager.setBackgroundColor(getResources().getColor(R.color.dark2));
        }

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                downloadOptionsFile();
            }});
        t1.start();

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                updateAboutSection();
            }});
        t2.start();
    }

    private void setAndCustomizeToolbar() {

        Toolbar toolbar = findViewById(R.id.app_bar);
        toolbar.setBackgroundColor(ThemeManager.getInstance().getPrimaryColor(this));
        mTabs.setBackgroundColor(ThemeManager.getInstance().getPrimaryColor(this));

        CustomText appName = toolbar.findViewById(R.id.main_title);
        appName.setText(OptionsManager.getInstance(this).getAppName());

        toolbar.setVisibility(OptionsManager.getInstance(getBaseContext()).appNameEnabled() ? View.VISIBLE : View.GONE);
        mTabs.setVisibility(OptionsManager.getInstance(getBaseContext()).tabsEnabled() ? View.VISIBLE : View.GONE);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

   private void replaceFirstFragment() {
       runOnUiThread(new Runnable() {
           @Override
           public void run() {
       //        viewPagerAdapter.replaceFragment(0, new FragmentOne());
               viewPagerAdapter.notifyDataSetChanged(); // MyFragmentAdapter

               mPager.setAdapter(viewPagerAdapter);
               mPager.setOffscreenPageLimit(3);
               mTabs.setupWithViewPager(mPager);
               mTabs.setSelectedTabIndicatorColor(Color.WHITE);
           }

       });
   }

   private void setUpBillingHelper() {
        // Check if user previously donated
       final IabHelper.QueryInventoryFinishedListener mGotInventoryListener = new IabHelper.QueryInventoryFinishedListener() {
           public void onQueryInventoryFinished(IabResult result, Inventory inventory) {
               if (result.isFailure())  return;

               if(inventory.hasPurchase(ITEM_BRONZE)) {
                   secretFragment(1);
               }
               else if(inventory.hasPurchase(ITEM_SILVER)) {
                   secretFragment(2);
               }
               else if(inventory.hasPurchase(ITEM_GOLD)) {
                   secretFragment(3);
               }
           }
       };

       billingHelper = new IabHelper(this, BASE64_PUBLIC_KEY);
       billingHelper.startSetup(new IabHelper.OnIabSetupFinishedListener() {
           public void onIabSetupFinished(IabResult result) {
               if (result.isSuccess())  {
                   if(Globals.sharedPreferences.getInt("contributed",0) != 0) return;

                   List<String> purchases = new ArrayList<>();
                   billingHelper.queryInventoryAsync(false,purchases,mGotInventoryListener);
               }
           }
       });
   }

   private void setUpAds() {
       adsEnabledForUser = OptionsManager.getInstance(getBaseContext()).adsEnabled();
       if(!adsEnabledForUser) return;

       // Disable ads if user contributed (donated)
       adsEnabledForUser = Globals.sharedPreferences.getInt("contributed",0) == 0;
       if(!adsEnabledForUser) return;

       MobileAds.initialize(this, ADMOB_APPLICATION_ID);

       mInterstitialAd = new InterstitialAd(this);
       mInterstitialAd.setAdUnitId(AD_UNIT_ID);
       mInterstitialAd.loadAd(new AdRequest.Builder().build());
   }

   private void startCountDownBetweenAds() {
       showNextAd = false;
       new CountDownTimer(OptionsManager.getInstance(getBaseContext()).getTimeBetweenAds(), OptionsManager.getInstance(getBaseContext()).getTimeBetweenAds()) {
           public void onTick(long millisUntilFinished) { }

           public void onFinish() {
               showNextAd = true;
           }
       }.start();
   }


   private void downloadOptionsFile() {
       Thread t = new Thread(new Runnable() {
           @Override
           public void run() {
                   FileManager.FileChangedPair fileChangedPair = FileManager.getInstance().loadXMLFile(getString(R.string.hostname), FileManager.FileType.OPTIONS, getBaseContext());
                   if(fileChangedPair.changed) updateAppConfiguration();
           }});
       t.start();
   }

    private void updateAboutSection() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                final FileManager.FileChangedPair fileChangedPair = FileManager.getInstance().loadXMLFile(getString(R.string.hostname), FileManager.FileType.ABOUT, getBaseContext());
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        if(fileChangedPair.file != null) fab.setVisibility(View.VISIBLE);
                    }
                });
            }});
        t.start();
    }
}
