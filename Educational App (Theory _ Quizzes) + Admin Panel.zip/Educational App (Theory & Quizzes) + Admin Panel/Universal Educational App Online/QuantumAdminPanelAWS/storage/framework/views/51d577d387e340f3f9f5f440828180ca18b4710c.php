<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>SULU</title>
        <link rel="stylesheet" href="/style.css" />
        <script src="/js/jquery.js"></script>

        <script src="/js/jquery.nice-select.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-sortablejs@latest/jquery-sortable.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/js-beautify/1.11.0/beautify-html.min.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Lexend+Deca&display=swap" rel="stylesheet">

        <script src="/js/main.js"></script>

        <link rel="stylesheet" href="/nice-select.css">

        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body>
<div id="application">
            <div class="root visible--2-6zspTYQo navigation-visible--2Y0-ThvmLG">
              <nav class="navigation">
                    <div class="navigation--1TPKGVcdtJ">
                        <div class="header--1yYASq55gP">
                            <div style="padding: 15px 40px; display: flex"><img src="/profile.png" height="30"><span class="panel-header">Quantum Admin</span></div>
                        </div>
                        <div class="user--1yh8_EoOW4">
                            <div class="user-content--1HWDvaZ5qI">
                                <button class="no-user-image--2r0uxVSaEY"><span aria-label="fa-user" class="fa fa-user"></span></button>
                                <div class="user-profile--3h8wK9aFMr">
                                    <button class="username--1iD-BWgeXO"><?php echo e(Auth::user()->name ?? ""); ?></button><br>
                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <button class="logout-button"><span aria-label="su-exit" class="su-exit"></span>Log out</button>
                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="items--23JrT1L7Qn">
                            <div class="item--2MP4_Vp3Oe <?php if(Route::current()->getName() == 'home'): ?> active--2cQkrWKevT <?php endif; ?>">
                              <a href="/home" style="text-decoration: none">
                                <div class="sidebar-title" role="button" style="color: white"><span aria-label="su-search" class="su-search"></span>Home</div>
                              </a>
                            </div>
                            <div class="item--2MP4_Vp3Oe <?php if(Route::current()->getName() == 'chapters'): ?> active--2cQkrWKevT <?php endif; ?>">
                                <a href="/chapters" style="text-decoration: none">
                                <div class="sidebar-title" role="button" style="color: white"><span aria-label="su-newspaper" class="su-newspaper"></span>Chapters</div>
                                </a>
                            </div>

                            <div class="item--2MP4_Vp3Oe <?php if(Route::current()->getName() == 'quizzes'): ?> active--2cQkrWKevT <?php endif; ?>">
                                <a href="/quizzes" style="text-decoration: none">
                                    <div class="sidebar-title" role="button" style="color: white"><span aria-label="su-image" class="su-image"></span>Quizzes</div>
                                </a>
                            </div>
                            <div class="item--2MP4_Vp3Oe <?php if(Route::current()->getName() == 'media.show'): ?> active--2cQkrWKevT <?php endif; ?>">
                            <a href="/media" style="text-decoration: none">
                                <div class="sidebar-title" role="button" style="color: white"><span aria-label="su-image" class="su-image"></span>Media</div>
                            </a>
                            </div>
                            <div class="item--2MP4_Vp3Oe">
                                <div class="sidebar-title" role="button"><span aria-label="su-cog" class="su-cog"></span>Settings</div>
                                <span aria-label="su-angle-right" class="su-angle-right clickable children-indicator--1u36bqdpDU" role="button" tabindex="0"></span>
                            </div>
                        </div>

                    </div>
                </nav>
                <?php echo $__env->yieldContent('content'); ?>

            </div>
    </div>
   <!-- MODAL -->
    <div id="modal" style="display:none;">
    <div class="backdrop--1NPZgaTLwy visible--2Ns3EfQy8A fixed--2GqQpeyTUu" role="button"></div>
    <div class="dialog-container--3iqPqgpIht open--1ztEKgXgPI">
        <div class="dialog--RUeFRUqJ7i">
        <section class="content--1lT7Ozsit1">
            <header></header>
            <article></article>
            <footer>
            <button id="ok" class="button--319u6U1AIl primary--1wekDI7P-q" type="button"><span class="text--3HNWf-tIc7">Ok</span></button>
            <button id="cancel" class="button--319u6U1AIl add-button" type="button"><span class="text--3HNWf-tIc7">Cancel</span></button>
            </footer>
        </section>
        </div>
    </div>
    </div>
</body>
</html>
<?php /**PATH C:\_\quantum-admin\resources\views/layouts/app.blade.php ENDPATH**/ ?>