package brychta.stepan.quantum_en.activities.tests.util;
import android.content.res.Resources;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import brychta.stepan.quantum_en.util.Globals;

public class Question {
    private static List<Question> currTestQuestions = null;
    public static boolean shuffleQuestions = false;

    private static String noQuestion = "Question not specified";
    private static String noAnswer = "Answer not specified";

    private String question;
    private String answer;
    private HashMap<String,Option> options;

    private String testImageURL = null;
    private String testImageWidth = null;
    private String invertImage = null;

    public Question() {
        options = new HashMap<>();

        question = noQuestion;
        answer = noAnswer;
    }

    public void setAnswer(String answer) {
        if(answer != null && !answer.equals("")) this.answer = answer;
    }

    public void setQuestion(String question) {
        if(question != null && !question.equals("")) this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getQuestion() {
        return question;
    }

    public HashMap<String, Option> getOptions() {
        return options;
    }

    public void addOption(String option, Option correctOrWrong) {
        options.put(option, correctOrWrong);
    }

    public void addImage(String imageURL, String imageWidth, String invertImage, Resources resources) {
        testImageURL = imageURL;
        testImageWidth = imageWidth;
        invertImage = invertImage;
    }

    public String getTestImageURL() {
        return testImageURL;
    }

    public String getInvertImage() {
        return invertImage;
    }

    public String getImageWidth() {
        return testImageWidth;
    }

    public static List<Question> getQuestions() {
       return currTestQuestions;
    }

    public static void setQuestions(List<Question> questions) {
        currTestQuestions = questions;
        if(shuffleQuestions) shuffleQuestions();
    }

    private static void shuffleQuestions() {
        Collections.shuffle(currTestQuestions);
    }

}
