package brychta.stepan.quantum_en.activities.tests;

import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import brychta.stepan.quantum_en.activities.tests.util.Circle;
import brychta.stepan.quantum_en.activities.tests.util.CircleAngleAnimation;
import brychta.stepan.quantum_en.util.DrawableManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.chapters.Chapter;
import brychta.stepan.quantum_en.activities.main_activity.MainActivity;

public class TestFinished extends AppCompatActivity {
    private static final float BAD_RESULT_THRESHOLD = 34;
    private static final float AVERAGE_RESULT_THRESHOLD = 67;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTheme(ThemeManager.getInstance().getTestTheme(String.valueOf(Globals.currTestNum)));
        setContentView(R.layout.activity_testfinished);

        View root = findViewById(R.id.root);
        TextView testResultComment = findViewById(R.id.what);
        TextView grade = findViewById(R.id.grade);

        Globals.changeTypefaceOfText(testResultComment);

        grade.setBackground(DrawableManager.getInstance(this).getCircleBackground());
        grade.setTextColor(ThemeManager.getInstance().getPrimaryColorDark(this));

        if(Globals.colorTheme == 1) {
            root.setBackgroundColor(getResources().getColor(R.color.white));
            testResultComment.setTextColor(getResources().getColor(R.color.dark));
        }

        saveTestResult();

        setColorsAccordingToTheme();

        float percentageCorrect = (float) Globals.currTestPoints / Globals.currQuestionNumber * 100;
        setGrade(grade, percentageCorrect);
        setTestResultComment(testResultComment, percentageCorrect);
        animatePointsCircle(percentageCorrect);
        animatePoints(percentageCorrect);
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.noanim, R.anim.slide_out);
    }

    public void Repeat (View view) {
        Globals.currQuestionNumber = 1;
        Globals.currTestPoints = 0;

        Intent intent = new Intent(this, Test.class);

        startActivity(intent);
        overridePendingTransition(R.anim.slide_in, R.anim.noanim);
        finish();
    }

    public void goBack(View view) {
        if(Globals.testFromChapter && Globals.nextChapterCode != null) {
            Globals.testFromChapter = false;
            Intent intent = new Intent(this, Chapter.class);
            intent.putExtra("chapter",Globals.nextChapterCode);
            startActivity(intent);
            overridePendingTransition(R.anim.noanim, R.anim.slide_out);
            finish();
        }
        else {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.noanim, R.anim.slide_out);
            finish();
        }
    }

    private void setGrade(TextView grade, float percentageCorrect) {
        if(percentageCorrect > 94) {
            grade.setText("A+");
        }
        else if(percentageCorrect > 88) {
            grade.setText("A");
        }
        else if(percentageCorrect > 82) {
            grade.setText("A-");
        }
        else if(percentageCorrect > 76) {
            grade.setText("B+");
        }
        else if(percentageCorrect > 70) {
            grade.setText("B");
        }
        else if(percentageCorrect > 64) {
            grade.setText("B-");
        }
        else if(percentageCorrect > 58) {
            grade.setText("C+");
        }
        else if(percentageCorrect > 52) {
            grade.setText("C");
        }
        else if(percentageCorrect > 46) {
            grade.setText("C-");
        }
        else if(percentageCorrect > 39) {
            grade.setText("D+");
        }
        else if(percentageCorrect > 33) {
            grade.setText("D");
        }
        else if(percentageCorrect > 26) {
            grade.setText("D-");
        }
        else {
            grade.setText("F");
        }
    }

    private void setTestResultComment(TextView comment, float percentageCorrect) {
        if(percentageCorrect < BAD_RESULT_THRESHOLD) comment.setText(getResources().getString(R.string.badtest));
        else if(percentageCorrect < AVERAGE_RESULT_THRESHOLD) comment.setText(getResources().getString(R.string.averagetest));
        else {
            if(Globals.testFromChapter && Globals.nextChapterCode != null) {
                String nextChapter = Globals.nextChapterCode;
                if(Globals.nextChapterCode.contains("_"))  nextChapter = nextChapter.split("_")[0];
                comment.setText(String.format(getResources().getString(R.string.goodtest_chapter),nextChapter));
            }
            else comment.setText(getResources().getString(R.string.goodtest));
        }
    }

    private void animatePoints(final float percentageCorrect) {
        ValueAnimator animator = new ValueAnimator();
        animator.setObjectValues(0, Globals.currTestPoints);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                TextView view = findViewById(R.id.points);
                view.setText(animation.getAnimatedValue() +" " + getResources().getString(R.string.points));

                // Set color of text based on result
                if(percentageCorrect < BAD_RESULT_THRESHOLD) view.setTextColor(getResources().getColor(R.color.bad));
                else if(percentageCorrect < AVERAGE_RESULT_THRESHOLD) view.setTextColor(getResources().getColor(R.color.average));
                else view.setTextColor(getResources().getColor(R.color.good));
            }
        });
        animator.setEvaluator(new TypeEvaluator<Integer>() {
            public Integer evaluate(float fraction, Integer startValue, Integer endValue) {
                return Math.round(startValue + (endValue - startValue) * fraction);
            }
        });
        animator.setDuration(2000);
        animator.start();
    }

    private void animatePointsCircle(float percentageCorrect) {
        Circle circle = findViewById(R.id.circleanim);
        circle.setColor(percentageCorrect);
        CircleAngleAnimation animation = new CircleAngleAnimation(circle, 360*Globals.currTestPoints /Globals.currQuestionNumber);
        animation.setDuration(2000);
        circle.startAnimation(animation);
    }

    private void setColorsAccordingToTheme() {
        ImageView lineTop = findViewById(R.id.linetop);
        ImageView lineBottom = findViewById(R.id.linebottom);
        ImageView nextButton = findViewById(R.id.nextbutton);
        ImageView repeatButton = findViewById(R.id.repeatbutton);

        repeatButton.setBackground(DrawableManager.getInstance(this).getRipple());
        nextButton.setBackground(DrawableManager.getInstance(this).getRipple());
        lineTop.setImageDrawable(DrawableManager.getInstance(this).getDashedLine());
        lineBottom.setImageDrawable(DrawableManager.getInstance(this).getDashedLine());
    }

    private void saveTestResult() {
        int testResult = (Globals.sharedPreferences.getInt("testResults"+ Globals.currTestNum, 0));
        Globals.sharedPreferencesEditor.putInt("testCount"+ Globals.currTestNum,1);
        if(testResult < Globals.currTestPoints) {
            Globals.sharedPreferencesEditor.putInt("testResults"+ Globals.currTestNum,Globals.currTestPoints);
            Globals.sharedPreferencesEditor.commit();
        }
    }
}

