package com.devlomi.fireapp.exceptions;

public class BackupFileMismatchedException extends Exception {

}
