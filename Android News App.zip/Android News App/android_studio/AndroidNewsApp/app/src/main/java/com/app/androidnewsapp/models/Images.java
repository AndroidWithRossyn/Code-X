package com.app.androidnewsapp.models;

public class Images {

    public long nid = -1;
    public String image_name = "";
    public String content_type = "";
    public String video_id = "";
    public String video_url = "";

}
