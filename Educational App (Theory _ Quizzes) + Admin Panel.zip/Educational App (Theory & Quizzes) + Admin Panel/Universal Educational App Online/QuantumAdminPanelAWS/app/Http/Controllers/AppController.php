<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AppController extends Controller
{
    public function index()
  {
    $files = Storage::disk('media-uploads')->files();
    return view('app')->with("files", $files);
  }
}
