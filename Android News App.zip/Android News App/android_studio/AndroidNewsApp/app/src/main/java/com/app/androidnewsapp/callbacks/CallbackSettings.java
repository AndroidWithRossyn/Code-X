package com.app.androidnewsapp.callbacks;

import com.app.androidnewsapp.models.Setting;

import java.io.Serializable;

public class CallbackSettings implements Serializable {

    public String status = "";
    public Setting post = null;

}