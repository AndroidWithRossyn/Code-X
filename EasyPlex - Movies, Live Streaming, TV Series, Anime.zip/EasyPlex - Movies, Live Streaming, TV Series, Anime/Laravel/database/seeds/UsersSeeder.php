<?php

use App\User;
use Illuminate\Database\Seeder;

class UsersSeeder extends Seeder
{
    /**
     * Run Users database seeds.
     *
     * @return void
     */

    public function run()
    {


        DB::table('users')->insert([

            [
                'name' => 'Cosmicracker',
                'role' => 'admin',
                'premuim' => true,
                'email' => 'admin@Cosmicracker.com',
                'password' => bcrypt('Cosmicracker'),

            ],
            [
                'name' => 'user',
                'role' => 'user',
                'premuim' => false,
                'email' => 'user@easyplex.com',
                'password' => bcrypt('123456')

            ]

        ]);

    }
}
