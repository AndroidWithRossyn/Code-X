

<?php $__env->startSection('content'); ?>
<div class="main-content">
                    <div class="backdrop--1NPZgaTLwy" role="button"></div>
                    <main class="main">
                        <header class="header--2MTvIGNc3d">
                            <div class="snackbar--3eko3atkJ5 error--1-4W5PV9sw" role="button">
                                <span aria-label="su-exclamation-triangle" class="su-exclamation-triangle icon--3hL7E25P-t"></span>
                                <div class="text--YXWqBt3seP"><strong>Error</strong> -</div>
                                <span aria-label="su-times" class="su-times clickable close-icon--2GVT-mVzOc" role="button" tabindex="0"></span>
                            </div>
                            <div class="snackbar--3eko3atkJ5 warning--1t9Esjcwiz" role="button">
                                <span aria-label="su-bell" class="su-bell icon--3hL7E25P-t"></span>
                                <div class="text--YXWqBt3seP"><strong>Warning</strong> -</div>
                            </div>
                            <nav class="toolbar--2aA3VIsptd light--oIqXlbEbXx">
                                <div class="controls--2YAMXys21b grow--2KB1wtNeK3">
                                    <div class="items-container--3v79arC6i5">
                                        <ul class="items--2UaqaDVVnV light--ZAKOwIF2HH">
                                            <li>
                                                <div class="dropdown">
                                                    <button class="button--Fry28Tt4id light--3tjxVCiYyF" id="save-button">
                                                        <span aria-label="su-save" class="su-save icon--2BbYiI_UQ5"></span><span class="top-button-label">Save</span>
                                                    </button>
                                                </div>
                                              </li>
                                            <!-- DELETE -->
                                            <li>
                                              <button id="deleteItem" class="button--Fry28Tt4id light--3tjxVCiYyF">
                                                <span aria-label="su-trash-alt" class="su-trash-alt icon--2BbYiI_UQ5"></span>
                                                <span class="top-button-label">Delete</span>
                                              </button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </header>
                        <div class="view-container-3">

                            <div class="new-chapter-form">
                                <div class="grid--370cPalb_8 grid--3IQZeqSYws">

                                  <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                    <label class="label--2S0ZduPoBW" for="themes">Chapter Theme *</label>
                                    <div class="field themes" id="themes">
                                      <input style="background-color: #6fb181" id="Theme1" name="theme" type="radio" value="" >
                                      <input style="background-color: #ca494a" id="Theme2" name="theme" type="radio" value="">
                                      <input style="background-color: #b17861" id="Theme3" name="theme" type="radio" value="">
                                      <input style="background-color: #b9b64d" id="Theme4" name="theme" type="radio" value="">
                                      <input style="background-color: #887396" id="Theme5" name="theme" type="radio" value="">
                                      <input style="background-color: #6e2f3e" id="Theme6" name="theme" type="radio" value="">
                                      <input style="background-color: #36a193" id="Theme7" name="theme" type="radio" value="">
                                      <input style="background-color: #88b483" id="Theme8" name="theme" type="radio" value="">
                                      <input style="background-color: #d29f45" id="Theme9" name="theme" type="radio" value="">
                                      <input style="background-color: #6a91ba" id="Theme10" name="theme" type="radio" value="">
                                      <input style="background-color: #4b468e" id="Theme11" name="theme" type="radio" value="">
                                      <input style="background-color: #76517c" id="Theme12" name="theme" type="radio" value="">
                                      <input style="background-color: #567c64" id="Theme13" name="theme" type="radio" value="">
                                      <input style="background-color: #87616f" id="Theme14" name="theme" type="radio" value="">
                                      <input style="background-color: #964a4e" id="Theme15" name="theme" type="radio" value="">
                                      <input style="background-color: #81c6af" id="Theme16" name="theme" type="radio" value="">
                                      <input style="background-color: #61a1ae" id="Theme17" name="theme" type="radio" value="">
                                      <input style="background-color: #455683" id="Theme18" name="theme" type="radio" value="">
                                    </div>
                                    <label class="error-label" id="theme-error-label"></label>

                                  </div>

                                  <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">

                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="title-input">Chapter Title *</label>
                                                <div class="field">
                                                    <label class="input left--3McDXiCrys headline"><input id="title-input" type="text" value="" /></label>
                                                </div>
                                            <label class="error-label" id="title-error-label"></label>
                                        </div>
                                      </div>

                                    <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="description-input">Chapter Description *</label>
                                            <div class="field-container">
                                                <div class="field">
                                                  <label class="input left--3McDXiCrys headline"><input id="description-input" type="text" value="" style="font-size: 15px"/></label>
                                                </div>
                                            </div>
                                            <label class="error-label" id="description-error-label"></label>
                                        </div>
                                    </div>
                                    <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="icon-input">Chapter Icon Link *</label>
                                            <div class="field-container" id="icon-input-container">
                                                <div class="field">
                                                  <label class="input left--3McDXiCrys headline">
                                                  <button class="button--fW1pgmzp5J left--1FyHE23CXB" type="button"><span aria-label="su-image" class="su-image icon--zG2a3XJIeF"></span></button>
                                                  <input id="icon-input" type="text" value="" style="font-size: 15px">
                                                  </label>
                                                </div>
                                            </div>
                                            <div id="chapter-icon-container" class="chapter-image-container" style="display: none; margin-bottom: 10px;">
                                              <div class="item-container--1oXQM4YWNF">
                                                <div class="item--91fU1JyQEP">
                                                  <div class="media-item--39GrC_T1V3">
                                                  <img class="thumbnail-image" src="" id="icon-image">
                                                  <div class="thumbnail-image-title" id="icon-image-text"></div>
                                                </div>
                                              </div>
                                              <span class="su-trash-alt clickable" role="button" tabindex="0" style="margin-right: 8px" id="delete-chapter-icon"></span>
                                            </div>
                                          </div>
                                            <label class="error-label" id="icon-error-label"></label>
                                        </div>
                                    </div>
                                    <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="/blocks">Content</label>

                                            <div class="field-container">
                                                <div class="field" id="block-container">
                                                </div>
                                                <button id="add-block" class="button--319u6U1AIl add-button" type="button"><span aria-label="su-plus" class="su-plus button-icon--2zwDFL5-yo"></span><span class="text--3HNWf-tIc7">Add Element</span></button></section>
                                            </div>
                                            <label class="error-label"></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>

                <li id="block-template" style="display: none">
                <div class="block expanded" >
                  <div class="handle"><span aria-label="su-more" class="su-more sortableHandle--1ONRfVhCqo"></span></div>
                    <div class="content--Q--ddExW3x" >
                      <header class="selector-container">
                        <div class="types--3BMYLuVPAf"><div class="select--2Y_GcUrdzb">
                          <select class="ignore select-block" id="select-block-1">
                            <option value="Heading">Heading</option>
                            <option value="Paragraph">Paragraph</option>
                            <option value="Quote">Quote</option>
                            <option value="Image">Image</option>
                            <option value="Button">Button</option>
                            <option value="Separator">Separator</option>
                         </select>
                        </div></div>
                        <div class="icons--3gZEnEY5xT">
                          <span class="su-trash-alt clickable delete-block" role="button" tabindex="0"></span>
                          <span aria-label="su-angle-down" class="su-angle-up clickable"></span>
                        </div>
                      </header>
                        <br>
                        <div class="block-input">

                            <div class="block-input-heading">
                              <label for="chapter-heading" class="label--2S0ZduPoBW" style="display: block">Text</label>
                              <div class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-heading" class="heading-input" type="text" value="" /></div>
                            </div>

                            <div class="field block-input-text" style="display: none; margin-bottom: 15px">
                              <label for="button-radio-group" class="label--2S0ZduPoBW">Text</label>
                                <div class="ck ck-reset ck-editor ck-rounded-corners" role="application" dir="ltr" lang="en" aria-labelledby="ck-editor__aria-label_ecef60e79a8e492826fcde840adaa8a28">
                                    <textarea class="ck ck-content ck-editor__editable ck-rounded-corners ck-editor__editable_inline ck-blurred" style="font-family: Lato; width: 100%; resize: none"></textarea>
                                </div>
                           </div>

                           <div class="block-input-image" style="display: none; margin-bottom: 15px">
                             <label for="chapter-image" class="label--2S0ZduPoBW" style="display: block">Image Link</label>
                             <div class="image-link-input-container">
                               <div class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-image" type="text" class="image-link-input" value="" style="font-size: 15px"/></div>
                             </div>
                             <div class="chapter-image-container" style="display: none; margin-bottom: 15px">
                               <div class="item-container--1oXQM4YWNF">
                                 <div class="item--91fU1JyQEP">
                                   <div class="media-item--39GrC_T1V3">
                                     <img class="thumbnail-image" src="" id="icon-image">
                                     <div class="thumbnail-image-title chapter-image-title"></div>
                                   </div>
                                 </div>
                                 <span class="su-trash-alt clickable delete-chapter-image" role="button" tabindex="0" style="margin-right: 8px"></span>
                               </div>
                             </div>
                               <label for="chapter-image-width" class="label--2S0ZduPoBW" style="display: block">Image Width</label>
                             <div class="input left--3McDXiCrys" style="margin-bottom: 15px; align-items: center; width: 80px; height: 40px"><input id="chapter-image-width" class="image-width-input" type="number" value="" min="0"/></div>
                           </div>

                           <div class="block-input-button" style="display: none; margin-bottom: 15px">
                             <span class="button-radio-container">
                               <label for="button-radio-group" class="label--2S0ZduPoBW">Choose action</label>
                               <div>
                               <div class="radio-group" id="button-radio-group">
                                 <input type="radio" name="button-action" id="radio-open-link" checked="" value="Open Link"><label id="radio-open-link-label" for="radio-open-link" class="label">Open Link</label>
                                 <input type="radio" name="button-action" id="radio-open-quiz" value="Open Quiz"><label id="radio-open-quiz-label" for="radio-open-quiz" class="label">Open Quiz</label>
                                 <input type="radio" name="button-action" id="radio-email" value="Email"><label id="radio-email-label" for="radio-email" class="label">Email</label>
                               </div>
                               </div>
                             </span>
                             <label class="button-action-label label--2S0ZduPoBW" for="chapter-image" style="display: block">Link</label>
                             <div id="chapter-image" class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-button-action" class="button-action-input" type="text" value="" style="font-size: 15px"/></div>
                             <label for="chapter-image-width" class="label--2S0ZduPoBW" style="display: block">Button Text</label>
                             <div id="chapter-image-width" class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-button-text" class="button-text-input" type="text" value="" style="font-size: 15px"/></div>
                           </div>

                       </div>
                    </div>
                </div>
              </li>
</div>
</div>

<div class="select-image-overlay">
   <section class="content--uDzbc_yR5N">
      <header>
         <h2>Select Image</h2>
         <span aria-label="su-times" class="su-times clickable--2-TzL1jn1k icon--3x5ECMVMng" role="button" tabindex="0"></span>
      </header>
      <article>
         <div class="overlay--37y_7yO44D">
            <div tabindex="0" class="dropzone--KZJx-aaeEy">
               <div>
                  <div class="collection-section--1__DHQagG0">
                     <div class="left--3pbjiZ6m4G">
                        <ul class="breadcrumb--3AnAv6bJcz">
                           <li><button class="item--3ZMpOg-5QU" disabled="">All media</button></li>
                        </ul>
                     </div>
                     <div class="right--2KDxSCdQMZ">
                        <div class="button-group--3ZXJDYPX-3"><button class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" type="button"><span aria-label="su-plus" class="su-plus button-icon--2zwDFL5-yo"></span></button></div>
                     </div>
                  </div>
                  <div class="list-container--1KaAm9Rrfq">
                     <div class="list--24qxBVT_IF">
                        <section>
                           <ul class="folder-list--2fXha71yIi">
                              <li>
                                 <div class="folder--2C_Lv1ahGq" role="button" tabindex="0">
                                    <div class="icon-container--3tpvXmGMe7"><span aria-label="su-folder" class="su-folder"></span></div>
                                    <div class="description--366tzMqMDd">
                                       <h5 class="title--fGKpkf9Y4Y">Content</h5>
                                       <div class="info--3eh7fLXezU">12 Objects</div>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="folder--2C_Lv1ahGq" role="button" tabindex="0">
                                    <div class="icon-container--3tpvXmGMe7"><span aria-label="su-folder" class="su-folder"></span></div>
                                    <div class="description--366tzMqMDd">
                                       <h5 class="title--fGKpkf9Y4Y">System</h5>
                                       <div class="info--3eh7fLXezU">2 Objects</div>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                           <nav class="pagination--1eeM3Kvldi">
                              <span class="display--2vbfghRVvn">Items per page:</span>
                              <span>
                                 <div class="select--2Y_GcUrdzb">
                                    <button class="displayValue--2O6vhDMKzo dark--kOMfdHyQbH" type="button">
                                       <div aria-label="10" class="cropped-text--kjpmxHAsTL" title="10">
                                          <div aria-hidden="true" class="front--3wwBW91aMg">1</div>
                                          <div aria-hidden="true" class="back--2lOqwyu_8t"><span>0</span></div>
                                          <div class="whole--3GXEeu7Wnq">10</div>
                                       </div>
                                       <span aria-label="su-angle-down" class="su-angle-down toggle--3gWiwmRHGz"></span>
                                    </button>
                                 </div>
                              </span>
                              <div class="loader--d5Z5tZSNVf"></div>
                              <span>Page:</span><span class="inputContainer--2d4HxkJBK-"><label class="input-container dark--tc2vktcDJ7 center--JXk60IDjWJ"><input inputmode="numeric" type="text" value="1"></label></span><span class="display--2vbfghRVvn">of 1</span>
                              <div class="button-group--3ZXJDYPX-3"><button class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" disabled="" type="button"><span aria-label="su-angle-left" class="su-angle-left button-icon--2zwDFL5-yo"></span></button><button class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" disabled="" type="button"><span aria-label="su-angle-right" class="su-angle-right button-icon--2zwDFL5-yo"></span></button></div>
                           </nav>
                        </section>
                     </div>
                  </div>
               </div>
               <div class="divider--32l6kUMZGL"></div>
               <div>
                  <div class="list-container--1KaAm9Rrfq">
                     <div class="toolbar--1g1N15_Ogd">
                        <label class="input-container dark--tc2vktcDJ7 left--3McDXiCrys collapsed--3cKiJ1rgll has-append-icon--pQms0sSnCj">
                           <div class="prepended-container--1HLUlo-uAQ dark--tc2vktcDJ7 collapsed--3cKiJ1rgll"><span aria-label="su-search" class="su-search clickable--2-TzL1jn1k icon--ytM2BXHUpA dark--tc2vktcDJ7 icon-clickable--2i8CXxR-rS collapsed--3cKiJ1rgll" role="button" tabindex="0"></span></div>
                           <input placeholder="Search…" type="text" value="">
                        </label>
                        <div class="field-filter--dZnFcTcVXE">
                           <div class="filter-button--1Wmp_CsCF-"><button class="button--319u6U1AIl icon--2SWnwI7jSC" type="button"><span aria-label="su-filter" class="su-filter button-icon--2zwDFL5-yo"></span><span aria-label="su-angle-down" class="su-angle-down dropdown-icon--1IfR6jDzfv"></span></button></div>
                        </div>
                     </div>
                     <div class="list--24qxBVT_IF">
                        <section>
                           <div>
                              <div class="masonry--2TwuuVPVpk" style="position: relative; height: 1458px;">

                              </div>
                           </div>
                           <div class="indicator--3u1fqyvXj1"></div>
                        </section>
                     </div>
                  </div>
               </div>
               <input multiple="" type="file" autocomplete="off" tabindex="-1" style="display: none;">
            </div>
         </div>
      </article>
      <footer>
         <button class="button--319u6U1AIl primary--1wekDI7P-q" type="button"><span class="text--3HNWf-tIc7">Confirm</span></button>
      </footer>
   </section>
</div>

              <form action="/edit-chapter/<?php echo e($chapterNumber); ?>" method="POST" enctype="multipart/form-data" style="display: none" id="postChapterForm">
                  <?php echo e(csrf_field()); ?>

                  <input type="text" name="text" id="xmlFileInput">
                  <input type="submit">
              </form>
    <script>
      let subChapterNumber = <?php echo e($subChapterNumber ?? "0"); ?>;

      $(document).ready(function() {
        requestXMLFile("/xml/chapters.xml");

        $('#postChapterForm').submit(function () {
            window.onbeforeunload = null;
        });

        $('select').niceSelect();

        $('#block-container').sortable({
          handle: '.handle',
          animation: 150
        });

        $("#add-block").click(function() {
          addBlock();
        });

        $("#description-input").change(function() {
          $("#description-error-label").text("");
        });

        $("#title-input").change(function() {
          $("#title-error-label").text("");
        });

        $("#icon-input").focusout(function() {
            loadIconThumbnail($(this));
        });

        $("#delete-chapter-icon").click(function() {
          removeChapterIconThumbnail();
        });

        $("#save-button").click(function() {
          saveChapterToXML(<?php echo e($chapterNumber); ?>, subChapterNumber, false);
        });
      });

    $(document).ready(function() {
        $("#deleteItem").click(function(e){
            showModal("Delete?","This operation will delete the chapter and cannot be undone. Do you wish to proceed?");
        });

        $('#cancel').click(function(e){
          $("#modal").css("display","none");
        });

        $('#ok').click(function(e){
            if(subChapterNumber !== 0) deleteChapter(subChapterNumber, <?php echo e($chapterNumber); ?>);
            else deleteChapter(<?php echo e($chapterNumber); ?>, 0);

            $("#xmlFileInput").val(html_beautify(chaptersXMLFile));
            $('#xmlFileInput').append('<input type="hidden" name="chapterNumber" value="' + <?php echo e($chapterNumber); ?> + '" />');
            $('#xmlFileInput').append('<input type="hidden" name="subChapterNumber" value="0"/>');
            $("#postChapterForm").submit();
        });

      });

    function onXMLFileReceived() {
      loadChapterFromXML(<?php echo e($chapterNumber); ?>, subChapterNumber);
    }

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\_\quantum-admin\resources\views/edit-chapter.blade.php ENDPATH**/ ?>