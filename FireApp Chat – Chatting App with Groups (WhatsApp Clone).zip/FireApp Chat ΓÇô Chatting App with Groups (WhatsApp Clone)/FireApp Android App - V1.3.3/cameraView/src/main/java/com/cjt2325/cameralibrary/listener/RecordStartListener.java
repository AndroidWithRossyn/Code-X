package com.cjt2325.cameralibrary.listener;

/**
 * Created by Devlomi on 31/10/2017.
 */

public interface RecordStartListener {
    void onStart();
    void onStop();
}
