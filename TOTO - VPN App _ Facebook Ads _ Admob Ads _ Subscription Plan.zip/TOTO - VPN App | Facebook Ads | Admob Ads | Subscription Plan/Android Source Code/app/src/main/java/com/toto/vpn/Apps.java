package com.toto.vpn;

import android.graphics.drawable.Drawable;

public class Apps {

    String size;
    Drawable image;

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }
}