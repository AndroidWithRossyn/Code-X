@extends('layouts.admin')

@section('content')


    <settings-component></settings-component>


@endsection
