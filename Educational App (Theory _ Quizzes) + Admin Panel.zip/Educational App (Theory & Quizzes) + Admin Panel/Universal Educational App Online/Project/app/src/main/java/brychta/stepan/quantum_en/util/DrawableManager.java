package brychta.stepan.quantum_en.util;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import brychta.stepan.quantum_en.R;


public class DrawableManager {
    private static DrawableManager INSTANCE = null;
    private GradientDrawable roundedSquareBackground;
    private GradientDrawable circleBackground;
    private GradientDrawable dashedLine;
    private RippleDrawable ripple;

    private static DisplayMetrics metrics;

    public DrawableManager(WindowManager manager, Context context, int defaultColor) {
        metrics = new DisplayMetrics();
        manager.getDefaultDisplay().getMetrics(metrics);

        circleBackground = new GradientDrawable();
        circleBackground.setShape(GradientDrawable.OVAL);

        ripple = (RippleDrawable) context.getDrawable(R.drawable.ripple1);

        roundedSquareBackground = new GradientDrawable();
        roundedSquareBackground.setShape(GradientDrawable.RECTANGLE);
        roundedSquareBackground.setCornerRadius(pxToDp(17));

        dashedLine = new GradientDrawable();
        dashedLine.setShape(GradientDrawable.LINE);

        INSTANCE = this;

        setColorOfDrawables(defaultColor);
    }

    // Never returns null
    public static DrawableManager getInstance(Activity activity) {
        if(INSTANCE == null) INSTANCE = new DrawableManager(activity.getWindowManager(), activity.getBaseContext(), ThemeManager.getInstance().getPrimaryColor(activity.getBaseContext()));
        return(INSTANCE);
    }

    // Can return null
    public static DrawableManager getInstance() {
        return(INSTANCE);
    }

    public void setColorOfDrawables(int color) {
        circleBackground.setColor(color);
        roundedSquareBackground.setColor(color);
        dashedLine.setStroke(pxToDp(2), color, pxToDp(16), pxToDp(8));
        ((GradientDrawable) ripple.findDrawableByLayerId(R.id.rippleshape)).setColor(color);
    }

    public void setColorOfBackground(GradientDrawable background, int color) {
        background.setColor(color);
    }

    public static int pxToDp(int px) {
        if(metrics != null) {
            return (int) Math.ceil(px * metrics.density);
        }
        return 0;
    }

    public GradientDrawable getDashedLine() {
        return dashedLine;
    }

    public RippleDrawable getRipple() {
        // Must return a copy, otherwise ripple can only be used once in a given activity
        return (RippleDrawable) ripple.getConstantState().newDrawable().mutate();
    }

    public GradientDrawable getRoundedSquareBackground() {
        return roundedSquareBackground;
    }

    public GradientDrawable getCircleBackground() {
        return circleBackground;
    }
}