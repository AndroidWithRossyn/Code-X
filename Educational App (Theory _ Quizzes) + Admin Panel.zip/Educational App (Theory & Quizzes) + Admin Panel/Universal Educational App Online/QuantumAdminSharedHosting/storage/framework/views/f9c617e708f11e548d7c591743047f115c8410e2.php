<?php $__env->startSection('content'); ?>
<div class="main-content">
                    <div class="backdrop--1NPZgaTLwy" role="button"></div>
                    <main class="main">
                        <header class="header--2MTvIGNc3d">
                            <div class="snackbar--3eko3atkJ5 error--1-4W5PV9sw" role="button">
                                <span aria-label="su-exclamation-triangle" class="su-exclamation-triangle icon--3hL7E25P-t"></span>
                                <div class="text--YXWqBt3seP"><strong>Error</strong> -</div>
                                <span aria-label="su-times" class="su-times clickable close-icon--2GVT-mVzOc" role="button" tabindex="0"></span>
                            </div>
                            <div class="snackbar--3eko3atkJ5 warning--1t9Esjcwiz" role="button">
                                <span aria-label="su-bell" class="su-bell icon--3hL7E25P-t"></span>
                                <div class="text--YXWqBt3seP"><strong>Warning</strong> -</div>
                            </div>
                            <nav class="toolbar--2aA3VIsptd light--oIqXlbEbXx">
                                <div class="controls--2YAMXys21b grow--2KB1wtNeK3">
                                    <div class="items-container--3v79arC6i5">
                                        <ul class="items--2UaqaDVVnV light--ZAKOwIF2HH">
                                            <li>
                                                <div class="dropdown">
                                                    <button class="button--Fry28Tt4id light--3tjxVCiYyF" id="save-button">
                                                        <span aria-label="su-save" class="su-save icon--2BbYiI_UQ5"></span><span class="label--36XumMAKrW">Save</span>
                                                    </button>
                                                </div>
                                            </li>
                                            <li>
                                                <button class="button--Fry28Tt4id light--3tjxVCiYyF"><span aria-label="su-trash-alt" class="su-trash-alt icon--2BbYiI_UQ5"></span><span class="label--36XumMAKrW">Delete</span></button>
                                            </li>
                                            <li>
                                                <div class="dropdown">
                                                    <button class="button--Fry28Tt4id light--3tjxVCiYyF">
                                                        <span aria-label="su-pen" class="su-pen icon--2BbYiI_UQ5"></span><span class="label--36XumMAKrW">Edit</span>
                                                    </button>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </header>
                        <div class="view-container-3">

                            <div class="new-chapter-form">
                                <div class="grid--370cPalb_8 grid--3IQZeqSYws">
                                  <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">

                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="title-input">Chapter Title *</label>
                                                <div class="field">
                                                    <label class="input left--3McDXiCrys headline"><input id="title-input" type="text" value="" /></label>
                                                </div>
                                            <label class="error-label" id="title-error-label"></label>
                                        </div>
                                      </div>

                                    <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="description-input">Chapter Description *</label>
                                            <div class="field-container">
                                                <div class="field">
                                                  <label class="input left--3McDXiCrys headline"><input id="description-input" type="text" value="" style="font-size: 15px"/></label>
                                                </div>
                                            </div>
                                            <label class="error-label" id="description-error-label"></label>
                                        </div>
                                    </div>
                                    <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="icon-input">Chapter Icon Link *</label>
                                            <div class="field-container" id="icon-input-container">
                                                <div class="field">
                                                  <label class="input left--3McDXiCrys headline"><input id="icon-input" type="text" value="" style="font-size: 15px"></label>
                                                </div>
                                            </div>
                                            <div id="chapter-icon-container" class="chapter-image-container" style="display: none; margin-bottom: 10px;">
                                              <div class="item-container--1oXQM4YWNF">
                                                <div class="item--91fU1JyQEP">
                                                  <div class="media-item--39GrC_T1V3">
                                                  <img class="thumbnail-image" src="" id="icon-image">
                                                  <div class="thumbnail-image-title" id="icon-image-text"></div>
                                                </div>
                                              </div>
                                              <span class="su-trash-alt clickable" role="button" tabindex="0" style="margin-right: 8px" id="delete-chapter-icon"></span>
                                            </div>
                                          </div>
                                            <label class="error-label" id="icon-error-label"></label>
                                        </div>
                                    </div>
                                    <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">
                                        <div class="field">
                                            <label class="label--2S0ZduPoBW" for="/blocks">Content</label>
                                            <div class="field-container">
                                                <div class="field" id="block-container">
                                                </div>
                                                <button id="add-block" class="button--319u6U1AIl secondary--1n10BKfoP3" type="button"><span aria-label="su-plus" class="su-plus button-icon--2zwDFL5-yo"></span><span class="text--3HNWf-tIc7">Add Element</span></button></section>
                                            </div>
                                            <label class="error-label"></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>

                <li id="block-template" style="display: none">
                <div class="block expanded" >
                  <div class="handle"><span aria-label="su-more" class="su-more sortableHandle--1ONRfVhCqo"></span></div>
                    <div class="content--Q--ddExW3x" >
                      <header class="selector-container">
                        <div class="types--3BMYLuVPAf"><div class="select--2Y_GcUrdzb">
                          <select class="ignore select-block" id="select-block-1">
                            <option value="Heading">Heading</option>
                            <option value="Paragraph">Paragraph</option>
                            <option value="Quote">Quote</option>
                            <option value="Image">Image</option>
                            <option value="Button">Button</option>
                            <option value="Separator">Separator</option>
                         </select>
                        </div></div>
                        <div class="icons--3gZEnEY5xT">
                          <span class="su-trash-alt clickable delete-block" role="button" tabindex="0"></span>
                          <span aria-label="su-angle-down" class="su-angle-up clickable"></span>
                        </div>
                      </header>
                        <br>
                        <div class="block-input">

                            <div class="block-input-heading">
                              <label for="chapter-heading" class="label--2S0ZduPoBW" style="display: block">Text</label>
                              <div class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-heading" class="heading-input" type="text" value="" /></div>
                            </div>

                            <div class="field block-input-text" style="display: none; margin-bottom: 15px">
                              <label for="button-radio-group" class="label--2S0ZduPoBW">Text</label>
                                <div class="ck ck-reset ck-editor ck-rounded-corners" role="application" dir="ltr" lang="en" aria-labelledby="ck-editor__aria-label_ecef60e79a8e492826fcde840adaa8a28">
                                    <textarea class="ck ck-content ck-editor__editable ck-rounded-corners ck-editor__editable_inline ck-blurred" style="font-family: Lato; width: 100%; resize: none"></textarea>
                                </div>
                           </div>

                           <div class="block-input-image" style="display: none; margin-bottom: 15px">
                             <label for="chapter-image" class="label--2S0ZduPoBW" style="display: block">Image Link</label>
                             <div class="image-link-input-container">
                               <div class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-image" type="text" class="image-link-input" value="" style="font-size: 15px"/></div>
                             </div>
                             <div class="chapter-image-container" style="display: none; margin-bottom: 15px">
                               <div class="item-container--1oXQM4YWNF">
                                 <div class="item--91fU1JyQEP">
                                   <div class="media-item--39GrC_T1V3">
                                     <img class="thumbnail-image" src="" id="icon-image">
                                     <div class="thumbnail-image-title chapter-image-title"></div>
                                   </div>
                                 </div>
                                 <span class="su-trash-alt clickable delete-chapter-image" role="button" tabindex="0" style="margin-right: 8px"></span>
                               </div>
                             </div>
                               <label for="chapter-image-width" class="label--2S0ZduPoBW" style="display: block">Image Width</label>
                             <div class="input left--3McDXiCrys" style="margin-bottom: 15px; align-items: center; width: 80px; height: 40px"><input id="chapter-image-width" class="image-width-input" type="number" value="" min="0"/></div>
                           </div>

                           <div class="block-input-button" style="display: none; margin-bottom: 15px">
                             <span class="button-radio-container">
                               <label for="button-radio-group" class="label--2S0ZduPoBW">Choose action</label>
                               <div>
                               <div class="radio-group" id="button-radio-group">
                                 <input type="radio" name="button-action" id="radio-open-link" checked="" value="Open Link"><label id="radio-open-link-label" for="radio-open-link" class="label">Open Link</label>
                                 <input type="radio" name="button-action" id="radio-open-quiz" value="Open Quiz"><label id="radio-open-quiz-label" for="radio-open-quiz" class="label">Open Quiz</label>
                                 <input type="radio" name="button-action" id="radio-email" value="Email"><label id="radio-email-label" for="radio-email" class="label">Email</label>
                               </div>
                               </div>
                             </span>
                             <label class="button-action-label label--2S0ZduPoBW" for="chapter-image" style="display: block">Link</label>
                             <div id="chapter-image" class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-button-action" class="button-action-input" type="text" value="" style="font-size: 15px"/></div>
                             <label for="chapter-image-width" class="label--2S0ZduPoBW" style="display: block">Button Text</label>
                             <div id="chapter-image-width" class="input left--3McDXiCrys headline" style="margin-bottom: 15px; align-items: center;"><input id="chapter-button-text" class="button-text-input" type="text" value="" style="font-size: 15px"/></div>
                           </div>

                       </div>
                    </div>
                </div>
              </li>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vomad\quantum-admin\resources\views/new-chapter.blade.php ENDPATH**/ ?>