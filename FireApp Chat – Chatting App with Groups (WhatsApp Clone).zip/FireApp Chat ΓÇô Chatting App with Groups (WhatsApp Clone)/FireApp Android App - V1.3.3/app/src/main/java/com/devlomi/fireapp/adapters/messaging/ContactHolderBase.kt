package com.devlomi.fireapp.adapters.messaging

interface ContactHolderBase {
    var contactHolderInteraction: ContactHolderInteraction?
}