package brychta.stepan.quantum_en.activities;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import brychta.stepan.quantum_en.activities.chapters.ContentParser;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.activities.tests.Test;
import brychta.stepan.quantum_en.util.Globals;

public class BaseActivity extends AppCompatActivity {
    public void openWebsite (String website) {

        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(website)));
    }

    public void openTest (View view, String nextChapterCode) {
        Globals.currQuestionNumber = 1;
        Globals.currTestPoints = 0;
        try {
            Globals.currTestNum = Integer.parseInt((String)view.getTag());
        }
        catch(Exception e) {
            Log.e("Error","Failed to open test, xml parameter in open-quiz must be a number.");
            return;
        }

        if(nextChapterCode != null) {
            Globals.testFromChapter = true;
            Globals.nextChapterCode = nextChapterCode;
        }
        else Globals.testFromChapter = false;

        Intent intent = new Intent(this, Test.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in, R.anim.noanim);
        finish();
    }

    public void sendEmailTo(String emailAddress) {
        if(emailAddress == null) return;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("message/rfc822");
        i.putExtra(Intent.EXTRA_EMAIL  , new String[]{emailAddress});
        i.putExtra(Intent.EXTRA_SUBJECT, "Quantum");
        i.putExtra(Intent.EXTRA_TEXT   , "");
        try {
            startActivity(Intent.createChooser(i, "Send email..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
        }
    }

    public void fillWithContentFromXML(LinearLayout container, String chapterCode, String nextChapterCode) {
        try {
            ContentParser contentParser = new ContentParser(getResources(),this,getLayoutInflater(), container);
            contentParser.processChapterContent(chapterCode,nextChapterCode, this);
        }
        catch(Exception e) { Log.e("Failed to add content", String.valueOf(e)); }
    }
}
