

<?php $__env->startSection('content'); ?>
<div class="main-content">
  <main class="main">
    <header>
      <div class="snackbar--3eko3atkJ5 error--1-4W5PV9sw" role="button">
        <span aria-label="su-exclamation-triangle" class="su-exclamation-triangle icon--3hL7E25P-t"></span>
        <div class="text--YXWqBt3seP"><strong>Error</strong> -</div>
        <span aria-label="su-times" class="su-times clickable--2-TzL1jn1k close-icon--2GVT-mVzOc" role="button" tabindex="0"></span>
      </div>
      <div class="snackbar--3eko3atkJ5 warning--1t9Esjcwiz" role="button">
        <span aria-label="su-bell" class="su-bell icon--3hL7E25P-t"></span>
        <div class="text--YXWqBt3seP"><strong>Warning</strong> -</div>
      </div>
      <nav class="toolbar--2aA3VIsptd light--oIqXlbEbXx">
        <div class="controls--2YAMXys21b grow--2KB1wtNeK3">

          <div class="items-container--3v79arC6i5">
            <ul class="items--2UaqaDVVnV light--ZAKOwIF2HH">
              <li>
                <form action="/media" method="POST" enctype="multipart/form-data" id="postMediaForm">
                    <?php echo e(csrf_field()); ?>

                    <input id="media-upload-input" type="file" name="images[]" multiple accept="image/*"style="display: none">
                    <button id="media-upload-button" class="button--Fry28Tt4id light--3tjxVCiYyF" type="button"> <span aria-label="su-upload" class="su-upload icon--2BbYiI_UQ5"></span><span class="top-button-label">Upload</span></button>
                </form>
              </li>
              <li>
                <button id="deleteItem" class="button--Fry28Tt4id light--3tjxVCiYyF" disabled="true"><span aria-label="su-trash-alt" class="su-trash-alt icon--2BbYiI_UQ5"></span><span class="top-button-label">Delete</span></button>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <div class="view-container-3">
      <div>
        <div tabindex="0" class="dropzone--KZJx-aaeEy">
          <div>
            <div class="collection-section--1__DHQagG0">
              <div class="left--3pbjiZ6m4G">
                <ul class="breadcrumb--3AnAv6bJcz">
                  <li><button class="item--3ZMpOg-5QU" disabled="">All media</button></li>
                </ul>
              </div>
            </div>

          </div>
          <div>
            <div class="list-container--1KaAm9Rrfq">

              <!-- TOOLBAR -->
              <div class="media-toolbar">
                 <div class="button-group--3ZXJDYPX-3">
                   <button id="image-view-button" class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" type="button">
                     <span class="text--3HNWf-tIc7"><span aria-label="su-th-large" class="su-th-large"></span></span>
                   </button>
                   <button id="list-view-button" class="button--319u6U1AIl icon--2SWnwI7jSC active--2PPd5kFWvV button--30g09RbEvQ" type="button">
                     <span class="text--3HNWf-tIc7"><span aria-label="su-align-justify" class="su-align-justify"></span></span>
                   </button>
                 </div>
               </div>

              <div id="media-list-view" class="list--24qxBVT_IF">
                <section>
                  <div class="dark--3w5GzWBb9F">
                    <table class="table--3OVMF8dOBt">
                      <thead class="header--18fHWvcEtu">
                        <tr>
                          <th class="header-button-cell--2jMdDWPow1 header-cell">
                            <span><span aria-label="su-pen" class="su-pen"></span></span>
                          </th>
                          <th class="header-cell">
                            <span>
                              <label class="label--22nuJrNdMC">
                                <span class="switch--52fMu6kGAZ checkbox--2Z3YMYLqUa light--29kb21gbll"><input id="selectAll" type="checkbox" /><span></span></span>
                              </label>
                            </span>
                          </th>
                          <th class="header-cell"><span>Thumbnail</span></th>
                          <th class="header-cell "><span>Name</span></th>
                          <th class="header-cell "><span></span></th>
                          <th class="header-cell "><span>Filesize</span></th>
                          <th class="header-cell "><span></span></th>
                          <th class="header-cell "><span></span></th>
                        </tr>
                      </thead>
                      <tbody id="media-table-body">

                        <!-- LOOP IMAGES IN LIST VIEW -->
                        <?php if (! (empty($files))): ?>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="row--16jZlysVSE image-list-template">
                          <td class="button-cell--15ZsRHax0E cell--3QhdjYDo1X">
                            <div class="cell-content--2c7QOZz1IK">
                              <button><span aria-label="su-pen" class="su-pen"></span></button>
                            </div>
                          </td>
                          <td class="cell--3QhdjYDo1X small--1KOK57-GZT">
                            <div class="cell-content--2c7QOZz1IK">
                              <label class="label--22nuJrNdMC">
                                <span class="switch--52fMu6kGAZ checkbox--2Z3YMYLqUa dark--1gdZ2dJMIJ"><input class="select-media" type="checkbox" /><span></span></span>
                              </label>
                            </div>
                          </td>
                          <td class="cell--3QhdjYDo1X">
                            <div class="cell-content--2c7QOZz1IK"><img class="media-thumbnail" src="<?php echo e(url('/media-uploader/'.$imageName.'')); ?>" /></div>
                          </td>
                          <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK image-name" ><?php echo e($imageName); ?></div></td>
                          <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK"></div></td>
                          <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK">76.09 KB</div></td>
                          <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK"></div></td>
                          <td class="cell--3QhdjYDo1X"><div class="cell-content--2c7QOZz1IK"></div></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                      </tbody>
                    </table>
                  </div>
                  <nav class="pagination--1eeM3Kvldi">
                    <span class="display--2vbfghRVvn">Items per page:</span>
                    <span>
                      <div id="make-me-nice-select">
                        <button class="displayValue--2O6vhDMKzo dark--kOMfdHyQbH" type="button">
                          <div aria-label="10" class="cropped-text--kjpmxHAsTL" title="10">
                            <div aria-hidden="true" class="front--3wwBW91aMg">1</div>
                            <div aria-hidden="true" class="back--2lOqwyu_8t"><span>0</span></div>
                            <div class="whole--3GXEeu7Wnq">10</div>
                          </div>
                          <span aria-label="su-angle-down" class="su-angle-down toggle--3gWiwmRHGz"></span>
                        </button>
                      </div>
                    </span>
                    <div class="loader--d5Z5tZSNVf"></div>
                    <div class="button-group--3ZXJDYPX-3">
                      <button id="backward-button" class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" disabled="" type="button"><span aria-label="su-angle-left" class="su-angle-left button-icon--2zwDFL5-yo"></span></button>
                      <button id="forward-button" class="button--319u6U1AIl icon--2SWnwI7jSC button--30g09RbEvQ" type="button"><span aria-label="su-angle-right" class="su-angle-right button-icon--2zwDFL5-yo"></span></button>
                    </div>
                  </nav>
                </section>
              </div>

              <!-- LOOP IMAGE IN IMAGE VIEW -->
              <div id="media-image-view" class="list--24qxBVT_IF">
                <div class="item--3RIViIi05o grid-item--3OxWG0xFvT colSpan--1-dAvrr6Hs colSpan-12--auvwGOVazL">

                  <?php if (! (empty($files))): ?>
                  <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="media-button-hide-me">
                      <div class="media-card--3zwVt4x9IY">
                        <div class="media-image-view-header">
                          <div class="description--KIscyejKfD" role="button">
                            <div class="title--2BoVb9Cwl9">
                              <label class="label--22nuJrNdMC">
                                <span class="switch--52fMu6kGAZ checkbox--2Z3YMYLqUa dark--1gdZ2dJMIJ "><input type="checkbox" /><span></span></span>
                                <div>
                                  <div class="title-text--1DQCap-AbL">
                                    <div aria-label="roadtrip.jpg" class="cropped-text--kjpmxHAsTL" title="roadtrip.jpg">
                                      <div aria-hidden="true" class="front--3wwBW91aMg" id=<?php echo e($imageName); ?> ><?php echo e($imageName); ?></div>
                                    </div>
                                  </div>
                                </div>
                              </label>
                            </div>
                            <div class="meta--Lq76ippoF_">
                              <div aria-label="image/jpeg 76.09 KB" class="cropped-text--kjpmxHAsTL" title="image/jpeg 76.09 KB">
                                <div aria-hidden="true" class="back--2lOqwyu_8t"><span> 76.09 KB</span></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="media--1-OiFQVLjc" role="button">
                          <img src="<?php echo e(url('/media-uploader/'.$imageName.'')); ?>" />
                        </div>
                      </div>
                    </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                  </div>
                </div>



            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>


<script>
  let pageSize = 5;
  let pageCounter = 1;

  $(document).ready(function(){
    // View the page with LIST VIEW active
    $('#media-image-view').css('display','none');

    // Checkbox triggerer when the image inside Image Viewer has been clicked
    $('.media--1-OiFQVLjc').click(function(){
      let checkbox = $(this).closest('.media-card--3zwVt4x9IY').find("input[type=checkbox]");
      if(checkbox.prop('checked')) {
        checkbox.prop('checked',false);
      }
      else {
        checkbox.prop('checked',true);
      }
    });

    // Check if any checbox has been triggered -> activate Delete Button
    $('.image-list-template').find(".select-media").each(function(){
        $(this).change(function(){
            checkboxClicked($(this));
        });
    });

    $("#media-upload-button").on("click", function() {
        $("input[type=file]").trigger("click");
      });

    $('#media-upload-input').change(function(){
      $('form').submit();
    });

    // Check all checkboxes
    $('#selectAll').change(function() {
    if($(this).prop('checked')) {
        $('.select-media').each(function(n) {
        if (n >= pageSize * (pageCounter - 1) && n < pageSize * pageCounter) {
          if(!$(this).prop("checked")) {
              $(this).prop('checked', true);
              numberOfClicked += 1;
          }
        }
        })
        $("#deleteItem").attr('disabled',false);
    }
    else {
        $('.select-media').prop('checked', false);
        $("#deleteItem").attr('disabled',true);
        numberOfClicked = 0;
    }
    });

    // Delete Images
    $("#deleteItem").click(function(e){
        showModal("Delete?","This operation will delete selected images and cannot be undone. Do you wish to proceed?");
    });

    $('#cancel').click(function(e){
    $("#modal").css("display","none");
    });

    $('#ok').click(function(e){
      $('#selectAll').prop('checked',false);
        // delete images
        $('#media-table-body').find("input[type=checkbox]").each(function(e){
            if($(this).prop('checked')){
              let parentImage = $(this).closest(".image-list-template");
              let imageName = parentImage.find('.image-name');
              console.log(imageName.text());
              // let id = parentImage.attr("id");
              // let idNum = id.substring(id.lastIndexOf("-")+1);
              // parentChapter.remove();
              // deleteChapter(idNum, 0);
              // numberOfClicked-=1;
            }
        });
        if(numberOfClicked < 1) $("#chapters-delete-button").attr('disabled',true);

        $("#modal").fadeOut("slow").css("display","none");
        // $("#xmlFileInput").val(html_beautify(chaptersXMLFile));
        // $('#xmlFileInput').append('<input type="hidden" name="subChapterNumber" value="0"/>');
        // $("#postChapterForm").submit();
    });
  });

  let numberOfImages = $(".image-list-template").length;

  function showPage(page) {
    $(".image-list-template").hide();
    $(".image-list-template").each(function(n) {
      if (n >= pageSize * (page - 1) && n < pageSize * page) {
        $(this).show();
      }
    });
  }

  showPage(1);
  let numberOfPages=Math.ceil(numberOfImages/pageSize);

  $('#forward-button').click(function() {
    pageCounter +=1;
    showPage(pageCounter);
    if(pageCounter >= numberOfPages) $('#forward-button').attr("disabled", true);
    $('#backward-button').attr("disabled", false);
  });

  $('#backward-button').click(function() {
    pageCounter -= 1;
    showPage(pageCounter);
    if(pageCounter <= 1) $('#backward-button').attr("disabled", true);
    $('#forward-button').attr("disabled", false);
  })

  // enable image view
  $('#image-view-button').click(function(){
    $(this).addClass('active--2PPd5kFWvV');
    $('#list-view-button').removeClass('active--2PPd5kFWvV');
    $('#media-image-view').css('display','block');
    $('#media-list-view').css('display','none');
  });

  // enable list view
  $('#list-view-button').click(function(){
    $(this).addClass('active--2PPd5kFWvV');
    $('#image-view-button').removeClass('active--2PPd5kFWvV');
    $('#media-list-view').css('display','block');
    $('#media-image-view').css('display','none');
  });


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\_\quantum-admin\resources\views/media.blade.php ENDPATH**/ ?>