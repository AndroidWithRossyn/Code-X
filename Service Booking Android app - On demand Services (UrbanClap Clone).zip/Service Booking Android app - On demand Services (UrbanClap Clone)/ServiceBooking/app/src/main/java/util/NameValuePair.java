package util;

/**
 * Created by Rajesh on 2017-09-20.
 */

public class NameValuePair {
    public String name, value;

    public NameValuePair(String _name, String _value) {
        name = _name;
        value = _value;
    }
}
