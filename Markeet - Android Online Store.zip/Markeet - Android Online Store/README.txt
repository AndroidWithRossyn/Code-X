FOLDER STRUCTURE :

 +--- admin_project/		# Upload all files to your hosting
 +--- android_project/
 +--- +--- Markeet/ 		# Open this folder from Android Studio
 
 +--- documentation.html	# Open this file using web browser
 
 +--- sql/					# SQL file for database
							  If your first time using Markeet you can import file database_markeet_demo.sql into your MySQL database
							  If you already using Markeet version 1.x, please execute query file patch_database_v2.0.sql
							  If you already using Markeet version less than 2.3, please execute query file patch_database_v2.4.sql
							  If you already using Markeet version less than equals 3.0, please execute query file patch_database_v4.0.sql
 
 
1. Please make sure you was READ doc_adroid and doc_admin before you ask or contact to me.

2. Request about modification (or customization) of the item is NOT available, but you can contact me if want a little change (like name, package, change some text, etc).

3. You can contact me on google hangout dev.dream.space@gmail.com

4. Or you can visit my profile page : http://codecanyon.net/user/dream_space


Thanks for purchasing my item :)