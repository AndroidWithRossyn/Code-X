package com.app.androidnewsapp.config;

public class AppConfig {

    //put your admin panel url here
    public static final String ADMIN_PANEL_URL = "http://10.0.2.2/android_news_app";

    //your api key which obtained from admin panel
    public static final String API_KEY = "cda11v2OkqSI1rhQm37PBXKnpisMtlaDzoc4w0U6uNATgZRbJG";

}
