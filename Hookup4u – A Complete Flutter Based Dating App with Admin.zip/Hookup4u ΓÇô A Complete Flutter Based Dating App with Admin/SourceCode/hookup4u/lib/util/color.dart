import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

Color primaryColor = Color(0xffff3a5a);
Color secondryColor = Colors.grey;
Color darkPrimaryColor = Color(0x22ff3a5a);
Color textColor = Colors.white;
