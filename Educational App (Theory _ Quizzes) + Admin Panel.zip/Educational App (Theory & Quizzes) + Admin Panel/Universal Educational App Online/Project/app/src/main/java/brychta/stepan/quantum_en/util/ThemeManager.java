package brychta.stepan.quantum_en.util;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.util.TypedValue;

import java.util.HashMap;

import brychta.stepan.quantum_en.R;

public class ThemeManager {
    public static final int DEFAULT_THEME =  R.style.Menu15;
    private static ThemeManager INSTANCE = null;
    private HashMap<String, Integer> testThemes;
    private HashMap<String, Integer> chapterThemes;

    public ThemeManager() {
        testThemes = new HashMap<>();
        chapterThemes = new HashMap<>();
        INSTANCE = this;
    }

    public static ThemeManager getInstance() {
        if(INSTANCE == null) INSTANCE = new ThemeManager();
        return(INSTANCE);
    }

    public int getPrimaryColor(Context context) {
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.colorPrimary, value, true);
        return value.data;
    }

    public int getPrimaryColorDark(Context context) {
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.colorPrimaryDark, value, true);
        return value.data;
    }

    public void addChapterTheme(String chapterCode, String themeName, Resources resources) {
        int theme = getThemeFromName(themeName, resources);
        if(theme != 0) chapterThemes.put(chapterCode, theme);
        else chapterThemes.put(chapterCode, DEFAULT_THEME);
    }

    public void addTestTheme(String testCode, String themeName, Resources resources) {
        int theme = getThemeFromName(themeName, resources);
        if(theme != 0) testThemes.put(testCode, theme);
        else testThemes.put(testCode, DEFAULT_THEME);
    }

    public int getChapterTheme(String chapterCode) {
        Integer theme = chapterThemes.get(chapterCode);
        if(theme != null) return theme;
        else return DEFAULT_THEME;
    }

    public int getTestTheme(String testCode) {
        Integer theme = testThemes.get(testCode);
        if(theme != null) return theme;
        else return DEFAULT_THEME;
    }


    public int getThemeFromName(String themeName, Resources resources) {
        return resources.getIdentifier(themeName,"style",Globals.PACKAGE_NAME);
    }
}
