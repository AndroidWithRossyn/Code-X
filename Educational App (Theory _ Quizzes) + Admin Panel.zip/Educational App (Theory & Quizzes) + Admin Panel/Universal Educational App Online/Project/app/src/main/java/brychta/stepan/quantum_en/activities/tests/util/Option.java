package brychta.stepan.quantum_en.activities.tests.util;

public enum Option {
    WRONG,
    CORRECT
}