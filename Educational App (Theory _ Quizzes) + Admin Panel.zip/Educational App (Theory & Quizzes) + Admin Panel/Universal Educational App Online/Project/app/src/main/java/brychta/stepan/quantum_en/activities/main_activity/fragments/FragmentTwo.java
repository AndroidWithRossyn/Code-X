package brychta.stepan.quantum_en.activities.main_activity.fragments;

import android.content.res.ColorStateList;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import brychta.stepan.quantum_en.activities.chapters.ContentParser;
import brychta.stepan.quantum_en.util.FileManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ThemeManager;
import brychta.stepan.quantum_en.activities.main_activity.MainActivity;

public class FragmentTwo extends BaseFragment {
    private List<CardView> testCards;
    private List<TextView> testNames;
    private List<TextView> testDescriptions;
    private List<ImageView> testIcons;

    public FragmentTwo() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_second, container, false);

        this.inflater = inflater;

        body = v.findViewById(R.id.body);
        waitingAnimationWrapper = v.findViewById(R.id.waitingAnimationWrapper);
        noInternetWrapper = v.findViewById(R.id.noInternetWrapper);

        scrollView = v.findViewById(R.id.scrollView);

        ((ProgressBar)waitingAnimationWrapper.findViewById(R.id.waitingAnimation)).setIndeterminateTintList(ColorStateList.valueOf(ThemeManager.getInstance().getPrimaryColor(getContext())));

        testDescriptions = new ArrayList<>();
        testNames = new ArrayList<>();
        testCards = new ArrayList<>();
        testIcons = new ArrayList<>();

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();

        updateLayout();

        downloadFile(FileManager.FileType.QUIZZES);

        for(int i=0; i < testIcons.size(); i++) {
            setTestIcon(testIcons.get(i),i+1);
        }
    }


    void updateLayout() {
        int color = getResources().getColor(R.color.white);
        int colorBG = getResources().getColor(R.color.dark2);

        if (Globals.colorTheme == 1) {
            color = getResources().getColor(R.color.dark);
            colorBG = getResources().getColor(R.color.white);
        }

        for(CardView card : testCards) {
            card.setCardBackgroundColor(colorBG);
        }
        for(TextView text : testNames) {
            text.setTextColor(color);
        }

        for(TextView text : testDescriptions) {
            Globals.changeTypefaceOfText(text);
        }
    }

    private void setTestIcon(ImageView test, int testCode) {
        int testResults = (Globals.sharedPreferences.getInt("testResults"+testCode, 0));

        if(testResults == 0) {
            test.setImageResource(R.drawable.testnone);
            return;
        }

        final float percentageCorrect = (float) testResults / Globals.sharedPreferences.getInt("Test"+testCode+"NumberOfQuestions",1) * 100;
        
        if(percentageCorrect > 94) {
            test.setImageResource(R.drawable.testaplus);
        }
        else if(percentageCorrect > 88) {
            test.setImageResource(R.drawable.testa);
        }
        else if(percentageCorrect > 82) {
            test.setImageResource(R.drawable.testaminus);
        }
        else if(percentageCorrect > 76) {
            test.setImageResource(R.drawable.testbplus);
        }
        else if(percentageCorrect > 70) {
            test.setImageResource(R.drawable.testb);
        }
        else if(percentageCorrect > 64) {
            test.setImageResource(R.drawable.testbminus);
        }
        else if(percentageCorrect > 58) {
            test.setImageResource(R.drawable.testcplus);
        }
        else if(percentageCorrect > 52) {
            test.setImageResource(R.drawable.testc);
        }
        else if(percentageCorrect > 46) {
            test.setImageResource(R.drawable.testcminus);
        }
        else if(percentageCorrect > 39) {
            test.setImageResource(R.drawable.testdplus);
        }
        else if(percentageCorrect > 33) {
            test.setImageResource(R.drawable.testd);
        }
        else if(percentageCorrect > 26) {
            test.setImageResource(R.drawable.testdminus);
        }
        else {
            test.setImageResource(R.drawable.testf);
        }
    }

    boolean addContent(File xmlQuizzes) throws XmlPullParserException, IOException {
        XmlPullParser xpp;

        if(xmlQuizzes == null || xmlQuizzes.length() == 0) return false;


        xpp = XmlPullParserFactory.newInstance().newPullParser();
        xpp.setInput(new FileInputStream(xmlQuizzes), null);

        ContentParser parser = new ContentParser(getResources(),getContext(),null,null);

        // Store values of the current test button in the following order: title, description
        String[] currCardValues = new String[2];

        boolean skipCurrentPremiumQuiz = false;

        int cardNum = 1;

        while (xpp.getEventType() != XmlPullParser.END_DOCUMENT) {
            if (xpp.getEventType() == XmlPullParser.START_TAG) {
                if(!skipCurrentPremiumQuiz) {
                    if (xpp.getName().equals(("quiz"))) {
                        if (parser.hidePremiumChapter(xpp)) {
                            skipCurrentPremiumQuiz = true;
                            continue;
                        }

                        String quizTheme = xpp.getAttributeValue(null, "theme");
                        if (quizTheme != null)
                            ThemeManager.getInstance().addTestTheme(String.valueOf(cardNum), quizTheme, getResources());
                    } else if (xpp.getName().equals("title")) {
                        String chapterTitle = parser.getTextFromTag(xpp);
                        currCardValues[0] = chapterTitle;
                    } else if (xpp.getName().equals("description")) {
                        String chapterDescription = parser.getTextFromTag(xpp);
                        currCardValues[1] = chapterDescription;
                    }
                }
            }
            if (xpp.getEventType() == XmlPullParser.END_TAG) {
                if(xpp.getName().equals("quiz")) {
                    if(skipCurrentPremiumQuiz) {
                        skipCurrentPremiumQuiz = false;
                        xpp.next();
                        continue;
                    }

                    // End of chapter tag reached, add the corresponding chapter card
                    createNewQuizCard(currCardValues, cardNum);
                    cardNum +=1;
                }
            }
            xpp.next();
        }
        return true;
    }

    private void createNewQuizCard(String[] chapterCardValues, int cardNum) {
        CardView currChapterButton;
        ImageView cardOpenImage;

        String cardCode = String.valueOf(cardNum);

        currChapterButton = (CardView) inflater.inflate(R.layout.chaptercard, body,false);
        testCards.add(currChapterButton);

        // Set tag of card icon to match chapter code
        cardOpenImage = currChapterButton.findViewById(R.id.chapteropenimage);
        cardOpenImage.setTag(cardCode);

        cardOpenImage.setTag(cardCode);
        cardOpenImage.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ((MainActivity)getActivity()).openTest(v);
            }
        });
        setTestIcon(cardOpenImage,cardNum);

        testIcons.add(cardOpenImage);

        addTextsToCard(currChapterButton, chapterCardValues[0], chapterCardValues[1]);

        // Add card to body
        body.addView(currChapterButton);
    }

    private void addTextsToCard(CardView card, String cardTitle, String cardDesciption) {
        TextView titleView = card.findViewById(R.id.cardname);
        TextView descriptionView = card.findViewById(R.id.cardsubname);
        testNames.add(titleView);
        testDescriptions.add(descriptionView);

        titleView.setText(cardTitle);
        descriptionView.setText(cardDesciption);
    }

    void startFileDownload() {
        downloadFile(FileManager.FileType.QUIZZES);
    }
}