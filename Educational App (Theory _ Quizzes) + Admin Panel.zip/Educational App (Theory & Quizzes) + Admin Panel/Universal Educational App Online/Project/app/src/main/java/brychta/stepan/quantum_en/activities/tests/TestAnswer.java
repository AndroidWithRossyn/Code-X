package brychta.stepan.quantum_en.activities.tests;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Html;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import brychta.stepan.quantum_en.activities.chapters.ContentParser;
import brychta.stepan.quantum_en.activities.tests.util.Question;
import brychta.stepan.quantum_en.util.CustomText;
import brychta.stepan.quantum_en.util.DrawableManager;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.util.ThemeManager;

public class TestAnswer extends AppCompatActivity {
    RelativeLayout crossTickContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTheme(ThemeManager.getInstance().getTestTheme(String.valueOf(Globals.currTestNum)));
        setContentView(R.layout.activity_testanswer);

        LinearLayout answerContainer = findViewById(R.id.answerContainer);
        CustomText explain = getAnswerExplanationText(answerContainer);
        answerContainer.addView(explain);

        View root = findViewById(R.id.root);
        if(Globals.colorTheme == 1) {
            root.setBackgroundColor(getResources().getColor(R.color.white));
            explain.setTextColor(getResources().getColor(R.color.dark));
        }

        setColorsAccordingToTheme();

        boolean prevAnswerTrue = getIntent().getBooleanExtra("correct",false);
        if (prevAnswerTrue) Globals.currTestPoints += 1;
        setCrossOrTick(prevAnswerTrue);

        setSizeOfCrossTickImage();

        Globals.changeAlignmentOfText(explain);
        Globals.changeTypefaceOfText(explain);
    }

    public void continue1(View view) {
        if (Question.getQuestions().size() >= Globals.currQuestionNumber + 1) {
            Globals.currQuestionNumber += 1;
            Intent intent = new Intent(this, Test.class);
            startActivity(intent);
            finish();
        }
        else {
            Globals.sharedPreferencesEditor.putInt("Test"+Globals.currTestNum +"NumberOfQuestions",Globals.currQuestionNumber);
            Globals.sharedPreferencesEditor.commit();
            Intent intent = new Intent(this, TestFinished.class);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.noanim, R.anim.slide_out);
    }

    private void setColorsAccordingToTheme() {
        ImageView lineTop = findViewById(R.id.linetop);
        ImageView lineBottom = findViewById(R.id.linebottom);
        ImageView nextButton = findViewById(R.id.nextbutton);

        nextButton.setBackground(DrawableManager.getInstance(this).getRipple());
        lineTop.setImageDrawable(DrawableManager.getInstance(this).getDashedLine());
        lineBottom.setImageDrawable(DrawableManager.getInstance(this).getDashedLine());
    }

    private CustomText getAnswerExplanationText(LinearLayout answerContainer) {
        CustomText explain = (CustomText) getLayoutInflater().inflate(R.layout.documentview, answerContainer,false);
        ContentParser.loadTextFromHTML(explain, Question.getQuestions().get(Globals.currQuestionNumber-1).getAnswer());

        return explain;
    }

    private void setCrossOrTick(boolean prevAnswerTrue) {
        // Set main image to either cross or tick based on whether previous answer correct
        ImageView mainImg = findViewById(R.id.mainimg);
        if(prevAnswerTrue) mainImg.setImageDrawable(getDrawable(R.drawable.tick));
        else mainImg.setImageDrawable(getDrawable(R.drawable.cross));
        mainImg.setBackground(DrawableManager.getInstance(this).getCircleBackground());
    }

    private void setSizeOfCrossTickImage() {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int height = displaymetrics.heightPixels;

        crossTickContainer = findViewById(R.id.crosstick);
        ViewGroup.LayoutParams params = crossTickContainer.getLayoutParams();
        params.width = height / 2;
        params.height = height / 2;

    }
}
