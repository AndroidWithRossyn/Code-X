<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>SULU</title>
        <link rel="stylesheet" href="/style.css" />
        <script src="/js/jquery.js"></script>

        <script src="/js/jquery.nice-select.min.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-sortablejs@latest/jquery-sortable.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/js-beautify/1.11.0/beautify-html.min.js"></script>

        <link rel="stylesheet" href="/nice-select.css">

        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body>
<div id="application">
            <div class="root visible--2-6zspTYQo navigation-visible--2Y0-ThvmLG">
              <nav class="navigation">
                    <div class="navigation--1TPKGVcdtJ">
                        <div class="header--1yYASq55gP">
                            <div class="header-content--3q2ACaykun"><span aria-label="su-sulu" class="su-sulu header-icon--3slb78kEn1"></span><span class="header-title--3llLneBogU">Quantum</span></div>
                        </div>
                        <div class="user--1yh8_EoOW4">
                            <div class="user-content--1HWDvaZ5qI">
                                <button class="no-user-image--2r0uxVSaEY"><span aria-label="fa-user" class="fa fa-user"></span></button>
                                <div class="user-profile--3h8wK9aFMr">
                                    <button class="username--1iD-BWgeXO">Administrator</button><button class="logout--3rYtUBtY-s"><span aria-label="su-exit" class="su-exit"></span>Log out</button>
                                </div>
                            </div>
                        </div>
                        <div class="items--23JrT1L7Qn">
                            <div class="item--2MP4_Vp3Oe">
                                <div class="title--QVStj55_lI" role="button"><span aria-label="su-search" class="su-search"></span>Search</div>
                            </div>
                            <div class="item--2MP4_Vp3Oe active--2cQkrWKevT">
                                <div class="title--QVStj55_lI" role="button"><span aria-label="su-newspaper" class="su-newspaper"></span>Chapters</div>
                            </div>
                            <div class="item--2MP4_Vp3Oe">
                                <div class="title--QVStj55_lI" role="button"><span aria-label="su-image" class="su-image"></span>Media</div>
                            </div>
                            <div class="item--2MP4_Vp3Oe">
                                <div class="title--QVStj55_lI" role="button"><span aria-label="su-cog" class="su-cog"></span>Settings</div>
                                <span aria-label="su-angle-right" class="su-angle-right clickable children-indicator--1u36bqdpDU" role="button" tabindex="0"></span>
                            </div>
                        </div>

                    </div>
                </nav>
                <?php echo $__env->yieldContent('content'); ?>

            </div>
    </div>
    <div id="app" style="display: none">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</body>
</html>
<?php /**PATH C:\Users\vomad\quantum-admin\resources\views/layouts/app.blade.php ENDPATH**/ ?>