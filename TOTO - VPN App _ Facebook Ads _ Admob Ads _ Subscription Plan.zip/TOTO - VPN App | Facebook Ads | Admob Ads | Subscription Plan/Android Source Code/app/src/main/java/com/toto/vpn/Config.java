package com.toto.vpn;

public class Config {

    public static final String IAP_LISENCE_KEY = "";

    //ads subscription id


    //Put Your Subscription ID Here
    public static final String all_month_id = "";
    public static final String all_threemonths_id = "";
    public static final String all_sixmonths_id = "";
    public static final String all_yearly_id = "";

    /*settings parameters (don't change them these are auto controlled by application flow)*/
    public static boolean ads_subscription = false;
    public static boolean vip_subscription = false;
    public static boolean all_subscription = false;
}
