package brychta.stepan.quantum_en.activities.main_activity.fragments;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import androidx.fragment.app.Fragment;

import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.IOException;

import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.activities.main_activity.MainActivity;
import brychta.stepan.quantum_en.util.Animator;
import brychta.stepan.quantum_en.util.FileManager;

public abstract class BaseFragment extends Fragment {
    private boolean contentAdded = false;
    private Context mContext;

    ScrollView scrollView;
    LinearLayout waitingAnimationWrapper;
    LinearLayout noInternetWrapper;
    LinearLayout body;
    LayoutInflater inflater;

    private boolean refreshActivityOnceConnected = false;

    private boolean downloadingFile = false;

    abstract void updateLayout();
    abstract void startFileDownload();
    abstract boolean addContent(File file) throws XmlPullParserException, IOException;

    public void onViewCreated(View view, Bundle savedInstanceState) {
        mContext = getContext();
    }

    void downloadFile(final FileManager.FileType fileType) {
        if(!downloadingFile) {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    downloadingFile = true;
                    FileManager.FileChangedPair fileChangedPair = FileManager.getInstance().loadXMLFile(getString(R.string.hostname),fileType, mContext);
                    if(fileChangedPair.file == null) updateContent(null);
                    else if(!contentAdded || fileChangedPair.changed) {
                        updateContent(fileChangedPair.file);
                    }
                    downloadingFile = false;
                }});
            t.start();
        }
    }

    private void updateContent(final File chaptersFile) {
        ((MainActivity)mContext).runOnUiThread(new Runnable() {
            @Override
            public void run() {

                // Recovering from a state with no internet connection - activity should be restarted and options from admin panel loaded
                if(refreshActivityOnceConnected) {
                    refreshActivityOnceConnected = false;
                    ((MainActivity) getActivity()).fragmentContentUpdated();
                }

                if(body.getChildCount() > 0) body.removeAllViews();

                boolean successfullyAddedContent = false;
                try { successfullyAddedContent = addContent(chaptersFile); }
                catch(Exception e) { Log.e("Failed to add content", String.valueOf(e)); }

                if(!successfullyAddedContent) {
                    noInternetConnection();
                    return;
                }

                waitingAnimationWrapper.setVisibility(View.GONE);
                noInternetWrapper.setVisibility(View.GONE);

                contentAdded = true;

                updateLayout();
                scrollView.setVisibility(View.VISIBLE);
                for(int i=0; i< body.getChildCount(); i++) {
                    Animator.fadeIn(body.getChildAt(i), 50*i);
                }
            }
        });
    }

    void retryDownload() {
        contentAdded = false;

        Log.e("BBB", "Retrying");

        noInternetWrapper.setVisibility(View.GONE);
        waitingAnimationWrapper.setVisibility(View.VISIBLE);

        startFileDownload();
    }

    void noInternetConnection() {
        refreshActivityOnceConnected = true;
        waitingAnimationWrapper.setVisibility(View.GONE);
        noInternetWrapper.setVisibility(View.VISIBLE);
        noInternetWrapper.findViewById(R.id.retrydownload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retryDownload();
            }
        });
    }
}
