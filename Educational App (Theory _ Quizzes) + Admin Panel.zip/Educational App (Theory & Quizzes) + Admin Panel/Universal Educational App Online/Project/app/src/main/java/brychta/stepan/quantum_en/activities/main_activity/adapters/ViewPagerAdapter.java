package brychta.stepan.quantum_en.activities.main_activity.adapters;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.ArrayList;

import brychta.stepan.quantum_en.R;
import brychta.stepan.quantum_en.activities.main_activity.fragments.FragmentOne;
import brychta.stepan.quantum_en.activities.main_activity.fragments.FragmentThree;
import brychta.stepan.quantum_en.activities.main_activity.fragments.FragmentTwo;
import brychta.stepan.quantum_en.util.Globals;
import brychta.stepan.quantum_en.util.OptionsManager;

public class ViewPagerAdapter extends FragmentPagerAdapter {
    private ArrayList<Fragment> fragments = new ArrayList<>();

    private Resources resources;

    private boolean firstFragmentEnabled;
    private boolean secondFragmentEnabled;
    private boolean thirdFragmentEnabled;

    public ViewPagerAdapter(FragmentManager fm, Resources resources, Context context) {
     super(fm, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);

     this.resources = resources;

     firstFragmentEnabled = OptionsManager.getInstance(context).theoryEnabled();
     secondFragmentEnabled = OptionsManager.getInstance(context).testsEnabled();
     thirdFragmentEnabled = OptionsManager.getInstance(context).supportEnabled();
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;

        if(position == 0) {
            if(firstFragmentEnabled) fragment = new FragmentOne();
            else if(secondFragmentEnabled) fragment = new FragmentTwo();
            else fragment = new FragmentThree();
        }
        else if(position == 1) {
            if(secondFragmentEnabled && firstFragmentEnabled) fragment = new FragmentTwo();
            else fragment = new FragmentThree();
        }
        else if(position == 2) fragment = new FragmentThree();


        try {
            fragments.add(position, fragment);
        }
        catch(Exception e) {
            Log.e("Cannot add fragment", position + " " + e.toString());
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return (firstFragmentEnabled ? 1 : 0) + (secondFragmentEnabled ? 1 : 0) + (thirdFragmentEnabled ? 1 : 0);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        CharSequence title = null;

        if(position == 0) {
            if(firstFragmentEnabled) title = resources.getString(R.string.theory);
            else if(secondFragmentEnabled) title = resources.getString(R.string.tests);
            else title = resources.getString(R.string.support);
        }
        else if(position == 1) {
            if(secondFragmentEnabled && firstFragmentEnabled) title = resources.getString(R.string.tests);
            else title = resources.getString(R.string.support);
        }
        else if(position == 2) title = resources.getString(R.string.support);

        return title;
    }

    public FragmentOne getFragmentOne() {
        if(fragments.size() > 0 && fragments.get(0) instanceof FragmentOne && firstFragmentEnabled) return (FragmentOne)fragments.get(0);
        return null;
    }

    public FragmentTwo getFragmentTwo() {
        if(fragments.size() > 1 && fragments.get(1) instanceof FragmentTwo && secondFragmentEnabled) return (FragmentTwo)fragments.get(1);
        else if(fragments.size() > 0 && fragments.get(0) instanceof FragmentTwo && secondFragmentEnabled) return (FragmentTwo)fragments.get(0);
        return null;
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }
}
