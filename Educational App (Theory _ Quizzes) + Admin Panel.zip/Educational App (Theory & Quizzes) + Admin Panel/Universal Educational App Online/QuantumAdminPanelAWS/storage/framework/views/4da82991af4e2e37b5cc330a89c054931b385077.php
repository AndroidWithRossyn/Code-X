
<?php $__env->startSection('body'); ?>
<div id="application">
   <div class="login--1dPKvzoqvx">
      <div class="login-container--3KCmvHyz7g">
         <div class="form-container--1a48M_vk4X">
            <div class="logo-container--3Rnp2jIalL">
               <img src="/img/profile.png" height="60">
            </div>
            <div class="card-header">Welcome</div>
            <form method="POST" action="<?php echo e(route('login')); ?>" class="form--1pNyeHZ_J6">
               <fieldset>
                  <?php echo csrf_field(); ?>
                  <label class="input-field--31TEuk-dv0">
                     <div class="label-text--2dcgberBAk"><?php echo e(__('Email')); ?></div>
                  <label class="input-container left--3McDXiCrys">
                     <div class="prepended-container--1HLUlo-uAQ"><span aria-label="fas fa-user" class="fas fa-user input-icon"></span></div>
                     <input id="email" type="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> user-info-input" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                  </label>
                  </label>
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <br>
                  <label class="input-field--31TEuk-dv0">
                     <div class="label-text--2dcgberBAk"><?php echo e(__('Password')); ?></div>
                  <label class="input-container left--3McDXiCrys">
                     <div class="prepended-container--1HLUlo-uAQ"><span aria-label="fas fa-lock" class="fas fa-lock input-icon"></span></div>
                     <input id="password" type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> user-info-input" name="password" required autocomplete="current-password">
                  </label>
                  </label>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <br>
                  <div class="buttons--2B7RG6G7uu">
                     <div style="display: flex">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> style="width: 18px; height: 18px">
                        <label class="form-check-label" for="remember" style="padding-left: 8px; font-size: 14px">
                        <?php echo e(__('Remember Me')); ?>

                        </label>
                     </div>
                     <button class="button--319u6U1AIl primary--1wekDI7P-q" type="submit" style="margin-top: 0"><span class="text--3HNWf-tIc7"><?php echo e(__('Login')); ?></span></button>
                  </div>
               </fieldset>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vomad\quantum-admin\Quantum-Admin\resources\views/auth/login.blade.php ENDPATH**/ ?>