interface HTMLElement extends HTMLElement {
  srcObject: MediaStream
}
