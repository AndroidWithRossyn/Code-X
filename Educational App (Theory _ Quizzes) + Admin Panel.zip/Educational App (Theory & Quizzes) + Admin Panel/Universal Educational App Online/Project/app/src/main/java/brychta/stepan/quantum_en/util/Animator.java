package brychta.stepan.quantum_en.util;

import android.view.View;
import android.view.animation.AlphaAnimation;

public class Animator {
    public static void fadeIn(View view, int offset) {
        AlphaAnimation anim = new AlphaAnimation(0f, 1f);
        anim.setDuration(500);
        anim.setStartOffset(offset);
        view.startAnimation(anim);
    }
}
